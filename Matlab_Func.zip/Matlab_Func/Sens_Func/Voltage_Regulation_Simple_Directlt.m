function [Data_Record] = Voltage_Regulation_Simple_Directlt(Data_Record,M,M_Sens_DDGS,AdjIndex,DLR_Parameter,Parameters_Index)
% Use the Senstive Matrix to know how much to solve the adjustment in Voltage Regulation
% ZYX 20220531

DLR_Parameter_PF=DLR_Parameter.PF;
DLR_Parameter_Sens=DLR_Parameter.Sen;

OUTPUT_Record=Data_Record.Output;
INPUT_Record=Data_Record.Input;
Adj_Input=Data_Record.Input(:,end);
% M_V_Rank=Senstive_M;
numof_PV_inventor=[1,1,1];

switch AdjIndex.Mode  % 'Variable_SensMatrix'
    case 'Fix_SensMatrix'
        M_V_Rank=M_Sens_DDGS.Direct_Linear_Sens;
    case 'Variable_SensMatrix'
        Adj_Input_temp=Data_Record.Input(1:64,:)-Data_Record.Input(66:129,:);
        M_V_Rank = Cal_Sens_DDGS(Adj_Input_temp,M_Sens_DDGS.M_BZ,M_Sens_DDGS.Direct_Linear_Sens,DLR_Parameter_Sens,M_Sens_DDGS.Num);
end

%%
Over_Voltage=find(Data_Record.Output(:,end)>AdjIndex.Voltage.max);

All_PV_ID=1:length(Parameters_Index.Pos_Q_in_Inventer);
All_PV_ID=All_PV_ID';

while (length(Over_Voltage)>0)
    
    P_exhausted=[];
    Q_exhausted=[];
    [Q_Avaliable,~,~,~] = Logic_cal_2Vector(All_PV_ID,Q_exhausted);

    Voltage_Target_temp=OUTPUT_Record(:,end);
    Voltage_Target_temp(Over_Voltage)=AdjIndex.Voltage.max;
    以电压为目标的调节手段本身不成立，因为必然会涉及到有的电压抬升，有的电压下降。
    然而在某节点的无功资源用尽时，如何赋值，如何能达到预期目的，用简单的逻辑求解是不现实的！


    Q_Delta_temp=zeros(length(All_PV_ID),1);

    temp_OKinS=10;
    while sum(temp_OKinS)

        Q_ALL_of_Exhausted=-sqrt(Parameters_Index.INclude_PV_S(Q_exhausted).^2-Adj_Input(Parameters_Index.Pos_P_in_Inventer(Q_exhausted),1).^2);
        

        V_Delta_temp=Voltage_Target_temp-OUTPUT_Record(:,end);
        if isempty(Q_exhausted)
            Q_Delta_temp(Q_Avaliable)=pinv(M_V_Rank(:,Parameters_Index.Pos_Q_in_SensMatrix(Q_Avaliable)))*V_Delta_temp;
        else
            Q_Delta_temp(Q_exhausted)=-sqrt(Parameters_Index.INclude_PV_S(Q_exhausted).^2-Adj_Input(Parameters_Index.Pos_P_in_Inventer(Q_exhausted),1).^2)-Adj_Input(Parameters_Index.Pos_Q_in_Inventer(Q_exhausted),1);
            V_adjed_by_Q_exhausted=M_V_Rank(:,Parameters_Index.Pos_Q_in_SensMatrix(Q_exhausted))*Q_Delta_temp(Q_exhausted);

            Q_Delta_temp(Q_Avaliable)=pinv(M_V_Rank(:,Parameters_Index.Pos_Q_in_SensMatrix(Q_Avaliable)))*(V_Delta_temp-V_adjed_by_Q_exhausted);
        end


        temp_OKinS=Adj_Input(Parameters_Index.Pos_P_in_Inventer,1).^2+(Adj_Input(Parameters_Index.Pos_Q_in_Inventer,1)+Q_Delta_temp).^2>Parameters_Index.INclude_PV_S.^2;
        if sum(temp_OKinS)
            pos_PVnumber_ViolateV=find(temp_OKinS==1);
            [Q_exhausted,~,~,~] = Logic_cal_2Vector(Q_exhausted,pos_PVnumber_ViolateV);
            [~,~,Q_Avaliable,~] = Logic_cal_2Vector(All_PV_ID,Q_exhausted);

        end
        
    end

    Adj_Input(Parameters_Index.Pos_Q_in_Inventer)=Adj_Input(Parameters_Index.Pos_Q_in_Inventer)+Q_Delta_temp;


    KPM_Output=Cal_DLR(Adj_Input,M,DLR_Parameter_PF);

    OUTPUT_Record=[OUTPUT_Record,KPM_Output];
    INPUT_Record=[INPUT_Record,Adj_Input];
    Over_Voltage=find(KPM_Output>AdjIndex.Voltage.max);

    %% Update the Sensitive 【test】

    Adj_Input_temp=Adj_Input(1:64,:)-Adj_Input(66:129,:);
    switch AdjIndex.Mode  % 'Variable_SensMatrix'
        case 'Fix_SensMatrix'
            M_V_Rank;  %Not Updated
        case 'Variable_SensMatrix'
            M_V_Rank = Cal_Sens_DDGS(Adj_Input_temp,M_Sens_DDGS.M_BZ,M_Sens_DDGS.Direct_Linear_Sens,DLR_Parameter_Sens,M_Sens_DDGS.Num);
    end
end

end