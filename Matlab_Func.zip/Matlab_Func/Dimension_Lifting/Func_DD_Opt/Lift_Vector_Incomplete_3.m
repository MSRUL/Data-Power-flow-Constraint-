function [Lifted_Vector] = Lift_Vector_Incomplete_3(inputArg1,rbf_type,cent,RisePos)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
FUN_select = Defined_Lift_FuncType(rbf_type);

Un_RisePos=Find_Wihtout_Which([1:size(inputArg1,1)],RisePos);
lift_inpuit=inputArg1(RisePos,:);
% lifted_inpuit=( [lift_inpuit;rbf_self_use(lift_inpuit,cent,rbf_type)] );
switch FUN_select
    case 1
        lifted_inpuit = Lift_Dem_Fun_Tradi(lift_inpuit,rbf_type,cent);
    case 2% 3N+1 
        lifted_inpuit = Lift_Dem_Fun_3NP1(lift_inpuit);
    case 3% 瀹屾暣鐨勪簩娆″瀷绌洪棿
        lifted_inpuit = Lift_Func(lift_inpuit);
    case 4
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',cent);
        lifted_inpuit2 =  Lift_Dem_Fun_3NP1(lift_inpuit);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 5
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 6
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 7
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 8
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent3);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:);lifted_inpuit3(size(lift_inpuit,1)+1:end,:)];
    case 9 % polyharmonic+invquad+invmultquad+3np1,!!!DIMENSION DOUBLE!!!!
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent3);
        lifted_inpuit4 =  Lift_Dem_Fun_3NP1(lift_inpuit);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:);lifted_inpuit3(size(lift_inpuit,1)+1:end,:);lifted_inpuit4(size(lift_inpuit,1)+1:end,:)];
        
end
%%
Input_2NP1= [ inputArg1(Un_RisePos,:) ; ones(1,size(inputArg1(Un_RisePos,:),2)) ; inputArg1(Un_RisePos,:).*inputArg1(Un_RisePos,:) ]  ;
% Lifted_Vector=[inputArg1(Un_RisePos,:);inputArg1(RisePos,:);lifted_inpuit];
Lifted_Vector=[Input_2NP1;lifted_inpuit];
end

