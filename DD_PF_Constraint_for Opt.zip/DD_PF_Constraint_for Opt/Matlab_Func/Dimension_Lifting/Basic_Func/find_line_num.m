function [output_linenum] = find_line_num(case_name,line_active,node1,node2)
%find_line_num Use case file and 2node ID to get branch ID
%   �˴���ʾ��ϸ˵��
line_node=case_name.branch(line_active,[1,2]);
gotW=1;
for i=1:size(line_node,1)
    if (line_node(i,1)==node1 && line_node(i,2)==node2)||(line_node(i,1)==node2 && line_node(i,2)==node1)
        output_linenum=i;
        gotW=0;
    end
end
if gotW
    output_linenum=0;
end
end

