function [E_dis] = dist_E(inputArg1,inputArg2)
%UNTITLED3 此处显示有关此函数的摘要
%   此处显示详细说明
E_dis=sqrt(sum((inputArg1-inputArg2).*(inputArg1-inputArg2)));
end

