function [Result_CPLEX] = CPLEX_Optimization_Distflow_Dispatch(casename_NR,Constraint_fix,Objective_Info)
% Build_Constraint Build_Constraint for CPLEX & Solve the optimization Problem
% SOCP in Disflow ZYX 20201224
%%
INclude_PV_node=Constraint_fix.INclude_PV_node;

PVinverter_P=Constraint_fix.PVinverter_P;
PVinverter_Q=Constraint_fix.PVinverter_Q;
P_Load=Constraint_fix.P_Load;
Q_Load=Constraint_fix.Q_Load;
INclude_PV_S=Constraint_fix.INclude_PV_S;

Voltage=Constraint_fix.Voltage;
%% Init Case information
[ref,pv, pq] = bustypes(casename_NR.bus, casename_NR.gen);
line_active=find(casename_NR.branch(:,11)==1);
Branch_Num=size(line_active,1);
Bus_Num=size(casename_NR.bus,1);

[Ybus] = makeYbus(casename_NR.baseMVA, casename_NR.bus, casename_NR.branch);
% progeny_Matric to find the downstream node ID and the reverse one;
[progeny_Matric] = Search_Praents_Node(Ybus,ref);

%% Init the Variable
PV_P= sdpvar(size(INclude_PV_node,2),1);
PV_Q = sdpvar(size(INclude_PV_node,2),1);
v_square = sdpvar(size(casename_NR.bus,1),1); %square of Node Voltage
i_square = sdpvar(size(line_active,1),1); %square of branch I
Pline = sdpvar(size(line_active,1),1); %Active power flow in barnch
Qline = sdpvar(size(line_active,1),1); %Reactive power flow in barnch

%% Change the Format of Data
casename=Trans_Standard_to_Real_Value(casename_NR);
R_ij=zeros(size(casename.bus,1),size(casename.bus,1));
X_ij=R_ij;
for i=1:size(casename.branch,1)
    R_ij(casename.branch(i,1),casename.branch(i,2))=casename.branch(i,3);
    R_ij(casename.branch(i,2),casename.branch(i,1))=casename.branch(i,3);
    X_ij(casename.branch(i,1),casename.branch(i,2))=casename.branch(i,4);
    X_ij(casename.branch(i,2),casename.branch(i,1))=casename.branch(i,4);
end
Rline=zeros(size(Pline)); %To record the Branch resistance in the Branch Number
%% Build the Constraint
Constraint=[];
%% (1)PV Inverter Output Constraint
PV_Q_Limit_Rate=1;
for i=1:size(PV_P,1)
    %     Constraint=[Constraint; 0<=PV_P(i,1)<=PVinverter_P(i,1)];  %PV inverter Active Power Up limint
    Constraint=[Constraint; PV_P(i,1)==PVinverter_P(i,1)];  %PV inverter Active Power Up limint
    Constraint=[Constraint; norm([PV_P(i,1);PV_Q(i,1)])<=INclude_PV_S(i,1)];  %PV inverter Active Power Up limint
    Constraint=[Constraint; abs(PV_Q(i,1))<=INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Active Power Up limint
%     Constraint=[Constraint; PV_Q(i,1)==PVinverter_Q(i,1)];  %PV inverter Active Power Up limint 
end
%% (2)Voltage Constraint (%!!!! No Transformer is considerd in the Branch ,so the Voltage)
for i=1:Bus_Num
    if i~=ref
        Constraint=[Constraint;(Voltage.min*casename_NR.bus(1,10))^2<=v_square(i,1)<=(Voltage.max*casename_NR.bus(1,10))^2];
    else % reference bus voltage init
        Constraint=[Constraint;v_square(i,1)==(1.00*casename_NR.bus(1,10))^2];
    end
end
%% (3)Distflow Constraint
for i=1:Bus_Num
    if i~=ref
        temp_progeny_node=find(progeny_Matric(i,:)==1);
        Down_stream_line_ID=zeros(size(temp_progeny_node));
        node_now=i;
        for j=1:size(temp_progeny_node,2)
            node_down=temp_progeny_node(1,j);
            Down_stream_line_ID(1,j) = find_line_num(casename_NR,line_active,node_now,node_down);
        end
        node_up=find(progeny_Matric(:,i)==1);
        Up_stream_line_ID= find_line_num(casename_NR,line_active,node_up,node_now);
        %% Branch Flow Constraint
        if ismember(node_now,INclude_PV_node)
            pos_PV_num=find(INclude_PV_node==node_now);
            Constraint=[Constraint;sum(Pline(Down_stream_line_ID,1))==...
                Pline(Up_stream_line_ID,1)-R_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-(P_Load(node_now,1)-PV_P(pos_PV_num,1))];  
            Constraint=[Constraint;sum(Qline(Down_stream_line_ID,1))==...
                Qline(Up_stream_line_ID,1)-X_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-(Q_Load(node_now,1)-PV_Q(pos_PV_num,1))];
        else
            Constraint=[Constraint;sum(Pline(Down_stream_line_ID,1))==...
                Pline(Up_stream_line_ID,1)-R_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-P_Load(node_now,1)];
            Constraint=[Constraint;sum(Qline(Down_stream_line_ID,1))==...
                Qline(Up_stream_line_ID,1)-X_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-Q_Load(node_now,1)];
        end
        %% SOCP Current-Voltage_Power Constraint
        Constraint=[Constraint;norm([2*Pline(Up_stream_line_ID,1);2*Qline(Up_stream_line_ID,1);(v_square(node_up,1)-i_square(Up_stream_line_ID,1))],2)...
            <= i_square(Up_stream_line_ID,1)+v_square(node_up,1)];
        %% Branch Voltage Constraint
        Constraint=[Constraint;v_square(node_now,1)==v_square(node_up,1)-2*(R_ij(node_up,node_now)*Pline(Up_stream_line_ID,1)+X_ij(node_up,node_now)*Qline(Up_stream_line_ID,1))...
            +(R_ij(node_up,node_now)^2+X_ij(node_up,node_now)^2)*i_square(Up_stream_line_ID,1)];
        %% Branch Current Square Constraint
        Constraint=[Constraint;i_square(Up_stream_line_ID,1)>=0];
        
        Rline(Up_stream_line_ID)=R_ij(node_up,node_now);
    end
end

%% CPLEX Optimization & Objective inside
%% Second-order cone relaxation: Here Must Containing the item "i_square"
% options = sdpsettings('solver','cplex','verbose',1);

switch Objective_Info.type
    case 'Min Loss'
        objective=sum(Rline.*i_square);
    case 'Hybrid'
        objective=Objective_Info.Hybrid_Index(1)*sum(Rline.*i_square)+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q-PVinverter_Q));
end

varargout=optimize(Constraint,objective);
varargout.info

%% Test the Satisfacation of Constraint 
% Test_The_Constraint_Satisfacation(node_test,progeny_Matric);  % Don't run the function here, go inside and run it by hand
%% Output Structure
Result_CPLEX.Pline=value(Pline);        Result_CPLEX.Qline=value(Qline);
Result_CPLEX.v_square=value(v_square);  Result_CPLEX.i_square=value(i_square);
Result_CPLEX.Voltage=sqrt(value(v_square))/casename_NR.bus(1,10);
Result_CPLEX.i_m=sqrt(value(i_square)); Result_CPLEX.v_m=sqrt(value(v_square));
Result_CPLEX.PV_P=value(PV_P);          Result_CPLEX.PV_Q=value(PV_Q);
Result_CPLEX.objective=value(objective);
Result_CPLEX.Ploss=sum(Rline.*value(i_square));
Result_CPLEX.PV_Q_Adj=value(PV_Q)-PVinverter_Q;
Result_CPLEX.Opt_Info=varargout.info;
Result_CPLEX.Vm_PQ=Result_CPLEX.Voltage(pq);

end


