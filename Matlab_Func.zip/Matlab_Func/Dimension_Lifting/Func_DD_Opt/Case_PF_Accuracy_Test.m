function [Output_Test_Standard] = Case_PF_Accuracy_Test(IDL_Peremeters,M_Incompelet,M_Struct,input)
%ZYX202203 此处提供此函数的摘要
%   此处提供详细说明
RisePos=IDL_Peremeters.RisePos;
Un_RisePos=Find_Wihtout_Which([1:size(input,1)],RisePos);

cent=IDL_Peremeters.cent;
rbf_type=IDL_Peremeters.rbf_type;
switch IDL_Peremeters.type	% 1:the basic incomplete dimension lifting; 2: The incomplete dimensiong lifting with senstive variable
    case 'IDL'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Output_Test_Standard=M_Incompelet*Lifted_Vector.Input_Lifted;
    case 'IDL_withSM'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Output_Test_Standard=M_Struct.MS*Lifted_Vector.XS*input(Un_RisePos,:)+M_Struct.M1*Lift_Dem_Fun_Tradi(input(RisePos,:),rbf_type,cent.Part2);
    case 'IDL_QuaModified'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Output_Test_Standard=M_Incompelet*Lifted_Vector.Input_Lifted;
    case 'IDL_QuaModified_withSM'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Input_2NP1= Lift_Dem_Fun_2NP1(input(Un_RisePos,:));
        Output_Test_Standard=M_Struct.MS*Lifted_Vector.XS*Input_2NP1+M_Struct.M1*Lift_Dem_Fun_Tradi(input(RisePos,:),rbf_type,cent.Part2);
    case 'IDL_QuaModified_withSM_3Np1'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Output_Test_Standard=M_Incompelet*Lifted_Vector.Input_Lifted;
    case 'IDLSM2'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Output_Test_Standard=M_Incompelet*Lifted_Vector.Input_Lifted;
    case 'IDLSM3'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Output_Test_Standard=M_Incompelet*Lifted_Vector.Input_Lifted;
    case 'IDL_CubicSpace'
        Lifted_Vector = Lift_Vector_Incomplete_Total(input,IDL_Peremeters);
        Output_Test_Standard=M_Incompelet*Lifted_Vector.Input_Lifted;
        
end
end