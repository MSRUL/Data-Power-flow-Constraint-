function [Alpha] = SVR_Rge_Mul(X,Y,kernel_type,maxItr)
%SVR_Rge_Mul SVR�ع������������
%   �˴���ʾ��ϸ˵��
% Kernel Adatron using Gaussain Kernel Dataset:data1
% Initailization
% maxItr=10e2;
Alpha=zeros(size(X,1),size(Y,2));
N=size(X,1);
for i_in_Y=1:size(Y,2)
    x=X;
    y=Y(:,i_in_Y);
    % Number of data points
    
    alpha=zeros(N,1);
    % Tolerence value
    norm1=10e2; tol=0.2;
    % Maximum number of iterations
    itr=0; 
    eps=0.1;
    % Algorithm
    while (norm1>tol && itr<maxItr)
        alpha_old=alpha;
        alpha_=alpha;
        for i=1:N
            alpha(i)=alpha(i) + y(i) -eps*sign(alpha(i))...
                -alpha'*kernel(x,x(i,:),kernel_type)';
            
            if alpha_(i)*alpha(i)<0
                alpha(i)=0;
            end
            
        end
        norm1=norm(alpha_old-alpha);
        itr=itr+1;
    end
     fprintf('\n[SVR regression process]Total number of iteration: %d',itr)
%     % Weights
%     w=sum(alpha.*x)
%     % Bias
%     b=mean(y-(w*x')' -eps*ones(N,1))

    Alpha(:,i_in_Y)=alpha;
end
%%
% Predicted values
% for j=1:N
%     fx1(j,:)=alpha(j)*kernel(x,x(j,:),kernel_type)';
% end
% fx=sum(fx1)';
% disp('[Actual Values  Predicted Values]')
% disp([y(1:10) ,fx(1:10)])
% % Mean Square error (Gaussian Kernel)
% mse=norm(y-fx)^2/N
% % Plotting
% figure
% hold on
% scatter3(x(:,1),x(:,2),y)
% scatter3(x(:,1),x(:,2),fx,'*')
% hold off
% xlabel({'X_1'});
% ylabel({'X_2'});
% view([-46.4 -0.40]);
% legend1 = legend('Actual Values','Predicted Values');

% Bhartendu, Machine Learning & computing
end

