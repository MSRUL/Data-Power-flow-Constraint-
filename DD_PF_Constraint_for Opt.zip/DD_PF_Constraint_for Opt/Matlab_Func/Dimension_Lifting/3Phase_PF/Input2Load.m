function [Load] = Input2Load(input,A_data,B_data,C_data)

Length=length(A_data)+length(B_data)+length(C_data);

Load=zeros(max([max(A_data),max(B_data),max(C_data)]),6);

Load(A_data,1)=input(1:length(A_data));
Load(B_data,3)=input(1+length(A_data):length(A_data)+length(B_data));
Load(C_data,5)=input(1+length(A_data)+length(B_data):length(A_data)+length(B_data)+length(C_data));

Load(A_data,2)=input(Length+1:Length+length(A_data));
Load(B_data,4)=input(Length+1+length(A_data):Length+length(A_data)+length(B_data));
Load(C_data,6)=input(Length+1+length(A_data)+length(B_data):Length+length(A_data)+length(B_data)+length(C_data));
end