function [X_LM] = Lagrangian_Median_Value_Test(X1,X2,Alfa)
%Fourth-order Lagrangian median theorem
%  四阶拉格朗日中值定理,求取切点位置

        X_LM = Alfa*X1+(1-Alfa)*X2;
   
end

