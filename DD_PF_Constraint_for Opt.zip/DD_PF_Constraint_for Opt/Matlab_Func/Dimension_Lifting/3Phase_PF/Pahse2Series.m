function [outputArg1,outputArg2] = Pahse2Series(Voltage)
%UNTITLED2 此处提供此函数的摘要
%   此处提供详细说明
for i=1:size(Voltage,1)
    Ua=Voltage(1,1);
    Ub=Voltage(1,3);
    Uc=Voltage(1,5);
    fai_a=Voltage(1,2);
    fai_b=Voltage(1,4);
    fai_c=Voltage(1,6);

    Ua_comp=complex(Ua*cos(fai_a),Ua*sin(fai_a));
    Ub_comp=complex(Ub*cos(fai_b),Ub*sin(fai_b));
    Uc_comp=complex(Uc*cos(fai_c),Uc*sin(fai_c));

    UABC=[Ua_comp;Ub_comp;Uc_comp];


    a=complex(-1/2,sqrt(3)/2);
    aa=complex(-1/2,-sqrt(3)/2);

    A_Trans=[   1   a   aa
        1   aa  a
        1   1   1   ];
    A_Trans=A_Trans*1/3;

    U120=A_Trans*[Ua_comp;Ub_comp;Uc_comp];

    A_Trans_Inv=[   1   1    1
        aa  a    1
        a   aa   1   ];

    UABC_Check=A_Trans_Inv*U120;

end

end