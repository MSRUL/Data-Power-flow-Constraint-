function [Output,Input,case_name,result] = NR_PF_Cal_NetLoad(case_name,Input,Device_Info)
%UNTITLED13 此处显示有关此函数的摘要
%   此处显示详细说明
%%
INclude_PV_node_Pos=Device_Info.INclude_PV_node_Pos;
INclude_PV_S=Device_Info.INclude_PV_S;
test_input_num=Device_Info.Input_Num;
%%
num=size(Input,2);

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);
pos_num_pq_pq=3:4;
line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);


SS=[];
for i=1:num
    %     temp_iptpq_p=Input(1:length(pq),i);
    %     temp_iptpq_p(INclude_PV_node_Pos)=temp_iptpq_p(INclude_PV_node_Pos)-Input(2*length(pq)+length(pv)+1+1+1:2*length(pq)+length(pv)+1+1+length(INclude_PV_S),i);
    %     temp_iptpq_q=Input(length(pq)+1:2*length(pq),i);
    %     temp_iptpq_q(INclude_PV_node_Pos)=temp_iptpq_q(INclude_PV_node_Pos)-Input(2*length(pq)+length(pv)+1+1+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+1+length(INclude_PV_S)*2,i);
    %     temp_iptpv_p=Input(2*length(pq)+1:2*length(pq)+length(pv),i);
    %     temp_iptpv_v=Input(2*length(pq)+length(pv)+1:2*length(pq)+2*length(pv),i);
    %     temp_iptref_v=Input(2*length(pq)+2*length(pv)+1,i);
    %     temp_C_bank=Input(2*length(pq)+2*length(pv)+1+1,i);
    %     temp_TranTab=Input(2*length(pq)+length(pv)+1+1+length(INclude_PV_S)*2+1,i);
    %%
    temp_iptpq_p=Input(1:length(pq),i);
    temp_iptpq_q=Input(length(pq)+1:2*length(pq),i);
    
    temp_iptpv_p=Input(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input(2*length(pq)+length(pv)+1:2*length(pq)+2*length(pv),i);
    temp_iptref_v=Input(2*length(pq)+2*length(pv)+1,i);
    
    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,6)=temp_iptref_v;
    
    if Device_Info.input_Cbank_state
        temp_C_bank=Input(2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state,i);
        case_name.bus(ref,4)=temp_C_bank;
    end
    if Device_Info.Transformer_Tab_state
        temp_TranTab=Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+Device_Info.Transformer_Tab_state,i);
        case_name.branch(1,9)=temp_TranTab;
    end
    
    %%
    [result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    output1=result.bus(pq,8);
    output2=result.branch(line_active,14);
    output3=result.branch(line_active,15);
    output4=result.bus(pq,9);
    output5=result.bus(pv,9);
    
    output_PLOSS=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));
    
    %     Output(:,i)=[output1;output2;output3;output4;output5;output_PLOSS];
    PQ_Vm(:,i)=[output1];
    PL(:,i)=[output2];
    QL(:,i)=[output3];
    PQ_sita(:,i)=[output4];
    PV_sita(:,i)=[output5];
    PLOSS(:,i)=output_PLOSS;
end

Input=Input(:,SS);

Output.Vm=PQ_Vm(:,SS);
Output.PL=PL(:,SS);
Output.QL=QL(:,SS);
Output.PQ_sita=PQ_sita(:,SS);
Output.PV_sita=PV_sita(:,SS);
Output.PLOSS=PLOSS(:,SS);
end

