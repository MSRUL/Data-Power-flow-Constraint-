function [Tranning_Range,Testing_Range] = Init_Training_Data_Range(Range)
%Init_Data_KPM_Dispatch Koopman_Dispatch函数参数初始化
%   此处显示详细说明
% Range=5;
%

switch Range
   
    case 3.2 % No Vbus Change
        Q_Load_Mode='fai';% The Q of PQ bus;  'fai'means the fai is rand(P determined);  'Q'means the Q is directly generated
        PQ_P_M=2;  % 基准值的选择范围
        PQ_P_B=0;
        PQ_Q_M=0.4;  % 基准值的选择范围
        PQ_Q_B=0;
        PQ_Q_Direc_M=0;
        PQ_Q_Direc_B=1;
        PV_P_M=1;  % 基准值的选择范围
        PV_P_B=0.5;
        PV_V_M=0;  % 基准值的选择范围
        PV_V_B=1;
        REF_V_M=0;  % 基准值的选择范围
        REF_V_B=1;
        PhotoVoltake_P_M=1;  % 含有光伏的节点的功率波动范围
        PhotoVoltake_P_B=0;
        PhotoVoltake_Q_M=2;  % 含有光伏的节点的功率波动范围
        PhotoVoltake_Q_B=-1;
    
end

%% Tranning_Range
Tranning_Range.PQ_P_M=PQ_P_M;  % 基准值的选择范围
Tranning_Range.PQ_P_B=PQ_P_B;
Tranning_Range.PQ_Q_M=PQ_Q_M;  % 基准值的选择范围
Tranning_Range.PQ_Q_B=PQ_Q_B;
Tranning_Range.PQ_Q_Direc_M=PQ_Q_Direc_M;
Tranning_Range.PQ_Q_Direc_B=PQ_Q_Direc_B;
Tranning_Range.PV_P_M=PV_P_M;  % 基准值的选择范围
Tranning_Range.PV_P_B=PV_P_B;
Tranning_Range.PV_V_M=PV_V_M;  % 基准值的选择范围
Tranning_Range.PV_V_B=PV_V_B;
Tranning_Range.REF_V_M=REF_V_M;  % 基准值的选择范围
Tranning_Range.REF_V_B=REF_V_B;
Tranning_Range.Q_Load_Mode=Q_Load_Mode; % The Q of PQ bus;  'fai'means the fai is rand(P determined);  'Q'means the Q is directly generated

Tranning_Range.PhotoVoltake_P_M=PhotoVoltake_P_M;  % 含有光伏的节点的功率波动范围
Tranning_Range.PhotoVoltake_P_B=PhotoVoltake_P_B;
Tranning_Range.PhotoVoltake_Q_M=PhotoVoltake_Q_M;  % 含有光伏的节点的功率波动范围
Tranning_Range.PhotoVoltake_Q_B=PhotoVoltake_Q_B;

%% Testing_Range
switch Range
    case 0
        Testing_Range.PQ_P_M=0;  % 基准值的选择范围
        Testing_Range.PQ_P_B=1;
        Testing_Range.PQ_Q_M=0;  % 基准值的选择范围
        Testing_Range.PQ_Q_B=1;
        Testing_Range.PV_P_M=0;  % 基准值的选择范围
        Testing_Range.PV_P_B=1;
        Testing_Range.PV_V_M=0;  % 基准值的选择范围
        Testing_Range.PV_V_B=1;
        Testing_Range.REF_V_M=0;  % 基准值的选择范围
        Testing_Range.REF_V_B=1;
    otherwise
        Testing_Range.PQ_P_M=PQ_P_M;
        Testing_Range.PQ_P_M=PQ_P_M;  % 基准值的选择范围
        Testing_Range.PQ_P_B=PQ_P_B;
        Testing_Range.PQ_Q_M=PQ_Q_M;  % 基准值的选择范围
        Testing_Range.PQ_Q_B=PQ_Q_B;
        Testing_Range.PQ_Q_Direc_M=PQ_Q_Direc_M;
        Testing_Range.PQ_Q_Direc_B=PQ_Q_Direc_B;
        Testing_Range.PV_P_M=PV_P_M;  % 基准值的选择范围
        Testing_Range.PV_P_B=PV_P_B;
        Testing_Range.PV_V_M=PV_V_M;  % 基准值的选择范围
        Testing_Range.PV_V_B=PV_V_B;
        Testing_Range.REF_V_M=REF_V_M;  % 基准值的选择范围
        Testing_Range.REF_V_B=REF_V_B;
        Testing_Range.Q_Load_Mode=Q_Load_Mode; % The Q of PQ bus;  'fai'means the fai is rand(P determined);  'Q'means the Q is directly generated

        Testing_Range.PhotoVoltake_P_M=PhotoVoltake_P_M;  % 含有光伏的节点的功率波动范围
        Testing_Range.PhotoVoltake_P_B=PhotoVoltake_P_B;
        Testing_Range.PhotoVoltake_Q_M=PhotoVoltake_Q_M;  % 含有光伏的节点的功率波动范围
        Testing_Range.PhotoVoltake_Q_B=PhotoVoltake_Q_B;

end
end

