function [pos] = find_node_num_in_PQ_of_PV(inputArg1,case_name)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);

pos=zeros(size(inputArg1,1),2);
for i=1:size(inputArg1,1)
    
    
    if sum(ismember(pq,inputArg1(i,1)))
        pos(i,1)=3; %PQ 
        pos(i,2)=find(ismember(pq,inputArg1(i,1))==1);
    end
    if sum(ismember(pv,inputArg1(i,1)))
        pos(i,1)=2; %PV 
        pos(i,2)=find(ismember(pv,inputArg1(i,1))==1);
    end
    if sum(ismember(ref,inputArg1(i,1)))
        pos(i,1)=1; %PQ 
        pos(i,2)=find(ismember(ref,inputArg1(i,1))==1);
    end
    

end
end

