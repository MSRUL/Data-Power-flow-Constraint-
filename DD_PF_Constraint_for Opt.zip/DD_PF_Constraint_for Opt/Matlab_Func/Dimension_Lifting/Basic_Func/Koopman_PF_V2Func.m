function [e_a_mean, e_a_max,emean,emax,e_a_mean2, e_a_max2,emean2,emax2,Cal_Result_Reshaped,Cal_Result_OR] = Koopman_PF_V2Func(casename_input,Using_M_input,FUN_select_input,TEST_input,TEST_OPtion_input,Range_Input,Range_Input_T,num_inpuit,num_test_input, Nrbf_input,PicPut,puton_measure_error,measure_reeor,rbf_type,weather_pu,pu_type)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%Koopman_PF_V1
% �����޸���ά������ѡ������
% ����ѡ��������ݷ�Χ
% ��������PQ�ڵ��PQ��PV�ڵ��PV
% �������PQ�ڵ��V,��֧·�׶˵��й����ʡ��޹�����

%Koopman_PF_V1_ad
% �������Ƚϴ�ĵ�



% 
% clear,clc
% close all;
%case24_ieee_rts
%case5
%case118
%case30
%case33bw
%case57
% case6515rte
% case_ieee123
case_name_or=casename_input;
case_name=Transfer_node_num_to_consecutive(case_name_or);  % �������нڵ��ţ�ʹ�������
Branch_Num=size(case_name.branch,1);
Bus_Num=size(case_name.bus,1);

A_result=runpf(case_name);

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);

pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;
pos_num_pv_p=[3,8];
pos_gen_pq=2:3;
pos_gen_p=2;
pos_gen_v=6;

P_rate=50;
Q_rate=P_rate/3;
PV_P_rate=50;
PV_V_rate=0;

PQ_1=case_name.bus(pq,[3,4]);
for i=1:size(PQ_1,1)
    if PQ_1(i,1)
        PQ_1(i,1)=PQ_1(i,1)/PQ_1(i,1);
    end
    if PQ_1(i,2)
        PQ_1(i,2)=PQ_1(i,2)/PQ_1(i,2);
    end
end
input_num=size(pq,1)*2+size(pv,1)*2+1;
output_num=size(pv,1)+2*length(pq)+2*size(case_name_or.branch,1);
case_name.bus(pq,pos_num_pq_pq)=0;
case_name.gen([pv_total;ref_pos],[pos_gen_p,pos_gen_v])=0;

% case_name.bus([pv;pq],pos_num_pq_pq)=0; %����matpowe�е�PV�ڵ����Դ�һ��
% PQ���ɣ�����������ڳ�����������ʵ�ǲ�������̼���ģ�����PQ���ɵ�P���ڼ���ǰ��PV�ڵ��P���PQ���ɵ�Q���ڳ����������PQ�ڵ��Q����
% �����ϣ�PV�ڵ��ϵ�PQ���ɣ���Ȼ����PV�ڵ��ṩ�ġ�
% ���������ļ����У�������ɿ���������һ���̶�ֵ�����ǲ�������Ϊ����������㣬��Ϊ������������������Ա������������ĳ������̽���������⡣
% ��Ȼ�������в�����Koopman��ʽʱ�������������������������Ͽ��Բ�һ�£������ۺϿ��ǵ��ڳ����ξ����α���������⣬���Ǻܿ�ȡ���п�����ɽϴ����


%% **********************��ά������ѡȡ*******
Using_M=Using_M_input;
FUN_select=FUN_select_input;
TEST=TEST_input;  %��һ�汾��TEST1��û���޸ĵ�λ
TEST_OPtion=TEST_OPtion_input;   %1:ʹ�ñ�׼���ݼ���  2��ʹ��ͬ����Χ�����������

Range_Input;

temp_range_input_p=Range_Input(1,1);  % ��׼ֵ��ѡ��Χ
temp_range1_input_p=Range_Input(1,2);
temp_range_input_q=Range_Input(2,1);  % ��׼ֵ��ѡ��Χ
temp_range1_input_q=Range_Input(2,2);
temp_range_input_pv_p=Range_Input(3,1);  % ��׼ֵ��ѡ��Χ
temp_range1_input_pv_p=Range_Input(3,2);
temp_range_input_pv_v=Range_Input(4,1);  % ��׼ֵ��ѡ��Χ
temp_range1_input_pv_v=Range_Input(4,2);
temp_range_input_ref_v=Range_Input(5,1);  % ��׼ֵ��ѡ��Χ
temp_range1_input_ref_v=Range_Input(5,2);


temp_range_test_input_p=Range_Input_T(1,1);%  % ������ʱ��ѡ��Χ
temp_range1_test_input_p=Range_Input_T(1,2);% ������ʱ��ѡ��Χ
temp_range_test_input_q=Range_Input_T(2,1);%  % ������ʱ��ѡ��Χ
temp_range1_test_input_q=Range_Input_T(2,2);% ������ʱ��ѡ��Χ
temp_range_test_input_pv_p=Range_Input_T(3,1);%  % ������ʱ��ѡ��Χ
temp_range1_test_input_pv_p=Range_Input_T(3,2);% ������ʱ��ѡ��Χ
temp_range_test_input_pv_v=Range_Input_T(4,1);%  % ������ʱ��ѡ��Χ
temp_range1_test_input_pv_v=Range_Input_T(4,2);% ������ʱ��ѡ��Χ
temp_range_test_input_ref_v=Range_Input_T(5,1);%  % ������ʱ��ѡ��Χ
temp_range1_test_input_ref_v=Range_Input_T(5,2);% ������ʱ��ѡ��Χ

% num_inpuit=500;   %
% num_test_input=num_inpuit+1000;

test_type=400;   %3����·�޹��������ϴ��������� 4��PQ�ڵ���ǲ�ϴ�������

Rise_Output=1;   %ѡ���Ƿ��������������ά   1����ά��  2������ά��
% puton_measure_error=0;
% measure_reeor=0.01*2;
%%
S_Input_temp_P=zeros(length(pv),1);
S_Input_temp_V=S_Input_temp_P;
for i=1:length(pv)
    S_Input_temp_P(i,:)=sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
    S_Input_temp_V(i,:)=case_name_or.gen( pv_pos(i,1),6);
end

% Standard_Input=[case_name_or.bus(pq,3);case_name_or.bus(pq,4);S_Input_temp_P;S_Input_temp_V;case_name_or.gen( ref_pos,6)];
Standard_Input=[case_name_or.bus(pq,3);case_name_or.bus(pq,3)*(temp_range_input_q+temp_range1_input_q*2)/2;S_Input_temp_P;S_Input_temp_V;case_name_or.gen( ref_pos,6)];
Standard_Input1=Standard_Input;
Standard_Input1(find(Standard_Input==0))=1;
%% **********************��ά������ѡȡ*******
%**************************************************
if FUN_select==1
    basisFunction = 'rbf';
    % RBF centers
    Nrbf = Nrbf_input;
    cent = rand(input_num,Nrbf);
    cent(1:length(pq),:)=cent(1:length(pq),:).*PQ_1(:,1)*P_rate;
    cent(length(pq)+1:2*length(pq),:)=cent(length(pq)+1:2*length(pq),:).*PQ_1(:,2)*Q_rate;
    cent(2*length(pq)+1:2*length(pq)+length(pv),:)=cent(2*length(pq)+1:2*length(pq)+length(pv),:)*PV_P_rate;
    cent(2*length(pq)+length(pv)+1:input_num,:)=cent(2*length(pq)+length(pv)+1:input_num,:)*PV_V_rate+1;
%     rbf_type = 'thinplate'; % 'thinplate' 'invquad'  'invmultquad'  'polyharmonic' 'gauss'
    % Lifting mapping - RBFs + the state itself
    liftFun = @(xx)( [xx;rbf_self_use(xx,cent,rbf_type)] );
    cent2 = rand(output_num,Nrbf);
    cent2(1:length(pq),:)=cent(1:length(pq),:).*A_result.bus(pq,8);
    cent2(length(pq)+1:2*length(pq),:)=cent(length(pq)+1:2*length(pq),:).*A_result.bus(pq,9);
    cent2(2*length(pq)+1:2*length(pq)+length(pv),:)=cent(2*length(pq)+1:2*length(pq)+length(pv),:).*A_result.bus(pv,9);
    % Lifting mapping - RBFs + the state itself
    liftFun2 = @(xx)( [xx;rbf_self_use(xx,cent2,rbf_type)] );
    Nlift = Nrbf + input_num;
end
if FUN_select==2
    liftFun = @(x)( [ x ; ones(1,size(x,2)) ; x(1:end-1,:).*(x(2:end,:)) ; x(1,:).*x(end,:) ; x.*x ]  ) ;
end
if FUN_select==3
    liftFun = @(x)( Lift_Func(x) );
end
%**************************************************
%% ***************�����������ݵ�ѡȡ***********
%**************************************************
if TEST==1
    num=num_inpuit;
    Input=zeros(input_num,num);
    Input(1:length(pq),:)=rand(length(pq),num).*PQ_1(:,1)*P_rate;% -P_rate/2;
    Input(length(pq)+1:2*length(pq),:)=rand(length(pq),num).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
    Input(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),num)*PV_P_rate;
    Input(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),num)*PV_V_rate+1;
    
end
%**************************************************
if TEST==2
    Input=zeros(input_num,num_inpuit);
    num=num_inpuit;
    %     Input(1:length(pq),:)=rand(length(pq),num).*case_name_or.bus(pq,3)*2;
    %     Input(length(pq)+1:2*length(pq),:)=rand(length(pq),num).*case_name_or.bus(pq,4)*2;
    %     for i=1:length(pv)
    %         Input(2*length(pq)+i,:)=rand(1,num)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2))*2;  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
    % %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
    %         Input(2*length(pq)+length(pv)+i,:)=case_name_or.gen( pv_pos(i,1),6);
    %     end
    
    temp_range=temp_range_input_p;
    temp_range1=temp_range1_input_p; %1-temp_range/2;
    if puton_measure_error
    Input(1:length(pq),:)=(rand(length(pq),num)*temp_range_input_p+temp_range1_input_p).*case_name_or.bus(pq,3).*(rand(length(pq),num)*(measure_reeor)+1-measure_reeor/2);
    Input(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*temp_range_input_q+temp_range1_input_q).*Input(1:length(pq),:).*(rand(length(pq),num)*(measure_reeor)+1-measure_reeor/2);
    for i=1:length(pv)
        Input(2*length(pq)+i,:)=((rand(1,num)*temp_range_input_pv_p+temp_range1_input_pv_p)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2))).*(rand(1,num)*(measure_reeor)+1-measure_reeor/2);  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,:)=(case_name_or.gen( pv_pos(i,1),6)*(rand(1,num)*temp_range_input_pv_v+temp_range1_input_pv_v)).*(rand(1,num)*(measure_reeor)+1-measure_reeor/2);
    end
    Input(2*length(pq)+2*length(pv)+1,:)=case_name_or.gen( ref_pos,6)*(rand(1,num)*temp_range_input_ref_v+temp_range1_input_ref_v).*(rand(1,num)*(measure_reeor)+1-measure_reeor/2);
    else
    Input(1:length(pq),:)=(rand(length(pq),num)*temp_range_input_p+temp_range1_input_p).*case_name_or.bus(pq,3);
    Input(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*temp_range_input_q+temp_range1_input_q).*Input(1:length(pq),:);
    for i=1:length(pv)
        Input(2*length(pq)+i,:)=(rand(1,num)*temp_range_input_pv_p+temp_range1_input_pv_p)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,:)=case_name_or.gen( pv_pos(i,1),6)*(rand(1,num)*temp_range_input_pv_v+temp_range1_input_pv_v);
    end
    Input(2*length(pq)+2*length(pv)+1,:)=case_name_or.gen( ref_pos,6)*(rand(1,num)*temp_range_input_ref_v+temp_range1_input_ref_v);
        
    end
end
%**************************************************
if TEST==3
    num1=num_inpuit;
    num2=num_inpuit;
    num=num1+num2;
    Input=zeros(input_num,num);
    Input(1:length(pq),1:num1)=rand(length(pq),num1).*PQ_1(:,1)*P_rate;% -P_rate/2;
    Input(length(pq)+1:2*length(pq),1:num1)=rand(length(pq),num1).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
    Input(2*length(pq)+1:2*length(pq)+length(pv),1:num1)=rand(length(pv),num1)*PV_P_rate;
    Input(2*length(pq)+length(pv)+1:input_num,1:num1)=rand(length(pv),num1)*PV_V_rate+1;
    
    temp_range=0.5;
    temp_range1=temp_range1_input_p; %1-temp_range/2;
    Input(1:length(pq),(num1+1):num)=(rand(length(pq),num2)*temp_range+temp_range1).*case_name_or.bus(pq,3);
    Input(length(pq)+1:2*length(pq),(num1+1):num)=(rand(length(pq),num2)*temp_range+temp_range1).*case_name_or.bus(pq,4);
    for i=1:length(pv)
        Input(2*length(pq)+i,(num1+1):num)=(rand(1,num2)*temp_range+temp_range1)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,(num1+1+1):num)=case_name_or.gen( pv_pos(i,1),6);
    end
    
    
end
%**************************************************

%% %*********�����������*********************

Output=zeros(output_num,num);
SS=[];
tic

for i=1:num
    temp_iptpq_p=Input(1:length(pq),i);
    temp_iptpq_q=Input(length(pq)+1:2*length(pq),i);
    temp_iptpv_p=Input(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input(2*length(pq)+length(pv)+1:input_num,i);
    temp_iptref_v=Input(2*length(pq)+2*length(pv)+1,i);
    
    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,6)=temp_iptref_v;
    
    
    [result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    output1=result.bus(pq,8);
    output2=result.branch(:,14);
    output3=result.branch(:,15);
    output4=result.bus(pq,9);
    output5=result.bus(pv,9);
    
    
    
    Output(:,i)=[output1;output2;output3;output4;output5];
end
toc
Input=Input(:,SS);
Output=Output(:,SS);


if weather_pu
    if ~pu_type
        Input=Input./Standard_Input1;
    end
end
Standard_Input_lift=liftFun(Standard_Input1);


if FUN_select==1
    Xp = liftFun(Input);
    if Rise_Output
        Yp = liftFun2(Output);
    else
        Yp = Output;
    end
end
if FUN_select==2||FUN_select==3
    Xp = liftFun(Input);
    if Rise_Output
        Yp = liftFun(Output);
    else 
        Yp = Output;
    end
end

if weather_pu
    if pu_type
        Xp=Xp./Standard_Input_lift;
    end
end

if Using_M==1
    W = Xp*Xp';
    V = Output*Xp';
    M = V*pinv(W);
    
    W = Input*Input';
    V = Yp*Input';
    M2 = V*pinv(W);
else
    M=Output*pinv(Xp);
    M2=Yp*pinv(Input);
end


% ---------С����-----------

% tic
% for i=1:1000
% IPT1=liftFun(Input(:,i));
% TPY=M*IPT1;
% end
% toc

%% *************��֤��������************

if TEST==1||TEST==3
    num_test=num_test_input;
    OPT_PF=zeros(num_test,output_num);
    OPT_kpm=zeros(num_test,output_num);
    
    SCU=[];
    
    for i=1:num_test
        
        Input_test=zeros(input_num,1);
        Input_test(1:length(pq),:)=rand(length(pq),1).*PQ_1(:,1)*P_rate; %-P_rate/2;
        Input_test(length(pq)+1:2*length(pq),:)=rand(length(pq),1).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
        Input_test(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),1)*PV_P_rate;
        Input_test(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),1)*PV_V_rate+1;
        
        temp_iptpq_p=Input_test(1:length(pq),1);
        temp_iptpq_q=Input_test(length(pq)+1:2*length(pq),1);
        temp_iptpv_p=Input_test(2*length(pq)+1:2*length(pq)+length(pv),1);
        temp_iptpv_v=Input_test(2*length(pq)+length(pv)+1:input_num,1);
        case_name1=case_name;
        
        case_name1.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
        %     case_name1.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
        for j=1:length(pv)
            case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
            case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
        end
        
        [result_test,scuess]=runpf(case_name1);
        
        if  scuess
           SCU=[SCU;i]; 
        end
        
        output_testPF=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15);result_test.bus(pq,9);result_test.bus(pv,9)];
        
        
        
        OPT_PF(i,:)=output_testPF';
        
        IPT_test=liftFun(Input_test);
        if Using_M==1
            TPY=M*(IPT_test*IPT_test');
            OPT1=TPY(:,1)/IPT_test(1,1);
        else
            OPT1=M*IPT_test;
        end
        opt1=OPT1(1:output_num,1);
        OPT_kpm(i,:)=opt1';
        
    end
    
    OPT_PF_pq_Va=OPT_PF(SCU,1:length(pq));
    OPT_kpm_pq_Va=OPT_kpm(SCU,1:length(pq));
    
    OPT_PF_branch_p=OPT_PF(SCU,length(pq)+1:length(pq)+length(case_name.branch));
    OPT_kpm_branch_p=OPT_kpm(SCU,length(pq)+1:length(pq)+length(case_name.branch));
    %
    OPT_PF_branch_q=OPT_PF(SCU,length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    OPT_kpm_branch_q=OPT_kpm(SCU,length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    
    
    
    
    OPT_PF_pq_Va=reshape(OPT_PF_pq_Va,size(SCU,1)*length(pq),1);
    OPT_kpm_pq_Va=reshape(OPT_kpm_pq_Va,size(SCU,1)*length(pq),1);
    
    OPT_PF_branch_p=reshape(OPT_PF_branch_p,size(SCU,1)*length(case_name.branch),1);
    OPT_kpm_branch_p=reshape(OPT_kpm_branch_p,size(SCU,1)*length(case_name.branch),1);
    
    OPT_PF_branch_q=reshape(OPT_PF_branch_q,size(SCU,1)*length(case_name.branch),1);
    OPT_kpm_branch_q=reshape(OPT_kpm_branch_q,size(SCU,1)*length(case_name.branch),1);
    
    
    
    figure;
    subplot(3,1,1)
    plot(OPT_PF_pq_Va);
    hold on;
    plot(OPT_kpm_pq_Va);
    legend('����������','Koopman')
    title('PQ�ڵ��ѹ��ֵ')
    subplot(3,1,2)
    plot(OPT_PF_branch_p);
    hold on;
    plot(OPT_kpm_branch_p);
    legend('����������','Koopman')
    title('֧·�й�����')
    subplot(3,1,3)
    plot(OPT_PF_branch_q);
    hold on;
    plot(OPT_kpm_branch_q);
    legend('����������','Koopman')
    title('֧·�޹�����')
    
    
    'ƽ���������';
    e_pq_p=mean(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)));
    e_pq_q=mean(abs((OPT_PF_branch_p-OPT_kpm_branch_p)));
    e_pv_sita=mean(abs((OPT_PF_branch_q-OPT_kpm_branch_q)));
    e_a_mean=[e_pq_p,e_pq_q,e_pv_sita];
    
    '���������';
    e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)));
    e_pq_q=max(abs((OPT_PF_branch_p-OPT_kpm_branch_p)));
    e_pv_sita=max(abs((OPT_PF_branch_q-OPT_kpm_branch_q)));
    e_a_max=[e_pq_p,e_pq_q,e_pv_sita];
    '�������'
    [e_a_mean,e_a_max]
    
    'ƽ��������';
    e_pq_p=mean(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
    e_pq_q=mean(abs((OPT_PF_branch_p-OPT_kpm_branch_p)./OPT_PF_branch_p));
    e_pv_sita=mean(abs((OPT_PF_branch_q-OPT_kpm_branch_q)./OPT_PF_branch_q));
    e=[e_pq_p,e_pq_q,e_pv_sita];
    emean=e*100;
    
    '���������';
    e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
    e_pq_q=max(abs((OPT_PF_branch_p-OPT_kpm_branch_p)./OPT_PF_branch_p));
    e_pv_sita=max(abs((OPT_PF_branch_q-OPT_kpm_branch_q)./OPT_PF_branch_q));
    e=[e_pq_p,e_pq_q,e_pv_sita];
    emax=e*100;
    '������'
    [emean,emax]
end
%% ԭʼ���ݼ���
if TEST==2||TEST==3
    
    if TEST_OPtion==1
        case_name_or1=Transfer_node_num_to_consecutive(case_name_or);
        [ref,pv, pq] = bustypes(case_name_or1.bus, case_name_or1.gen);
        
        
        Input_test=zeros(input_num,1);
        Input_test(1:length(pq),:)=case_name_or1.bus(pq,3);
        Input_test(length(pq)+1:2*length(pq),:)=case_name_or1.bus(pq,4);
        for i=1:length(pv)
            Input_test(2*length(pq)+i,1)=sum(case_name_or1.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
            Input_test(2*length(pq)+length(pv)+i,1)=case_name_or1.gen( pv_pos(i,1),6);
        end
        
        IPT_test=liftFun(Input_test);
        if Using_M==1
            TPY=M*(IPT_test*IPT_test');
            OPT1=TPY(:,1)/IPT_test(1,1);
        else
            OPT1= M*IPT_test;
        end
        opt1=OPT1(1:output_num,1);
        
        result_test=runpf(case_name_or);
        output_testPF=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15);result_test.bus(pq,9);result_test.bus(pv,9)];
        
        
        figure
        subplot(3,1,1)
        range=1:length(pq);
        plot(output_testPF(range),'--+')
        hold on;
        plot(opt1(range));
        xlabel('PQ�ڵ���')
        ylabel('��ѹ����ֵ')
        legend('ϵͳ��׼���','���᷽��������');
        
        subplot(3,1,2)
        range=length(pq)+1:length(pq)+length(result_test.branch);
        plot(output_testPF(range),'--+')
        hold on;
        plot(opt1(range));
        xlabel('֧·���')
        ylabel('��·�׶��й�����/MW')
        legend('ϵͳ��׼���','���᷽��������');
        
        subplot(3,1,3)
        range=length(pq)+length(result_test.branch)+1:length(pq)+2*length(result_test.branch);
        plot(output_testPF(range),'--+')
        hold on;
        plot(opt1(range));
        xlabel('֧·���')
        ylabel('��·ĩ���й�����/MVAR')
        legend('ϵͳ��׼���','���᷽��������');
        
        k_r1=opt1(1:length(pq));
        k_r2=opt1(length(pq)+1:length(pq)+length(case_name.branch));
        k_r3=opt1(length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
        
        
        e1=mean(abs((k_r1-result_test.bus(pq,8))));
        e2=mean(abs((k_r2-result_test.branch(:,14)) ));
        e3=mean(abs((k_r3-result_test.branch(:,15)) ));
        e_a_mean=[e1,e2,e3];
        
        e1=max(abs((k_r1-result_test.bus(pq,8))));
        e2=max(abs((k_r2-result_test.branch(:,14)) ));
        e3=max(abs((k_r3-result_test.branch(:,15)) ));
        e_a_max=[e1,e2,e3];
        '�������'
        [e_a_mean,e_a_max]
        
        
        E_P_stemp=abs((k_r2-result_test.branch(:,14)) );
        E_P_stemp=abs((k_r3-result_test.branch(:,15)) );
        x_pos=find(E_P_stemp==max(E_P_stemp));
        E_P_stemp(x_pos,1)
        k_r2(x_pos,1)
        result_test.branch(x_pos,14)
        
        
        e1=mean(abs((k_r1-result_test.bus(pq,8))./result_test.bus(pq,8)));
        e2=mean(abs((k_r2-result_test.branch(:,14))./result_test.branch(:,14) ));
        e3=mean(abs((k_r3-result_test.branch(:,15))./result_test.branch(:,15) ));
        e=[e1,e2,e3];
        emean=e*100;
        
        e1=max(abs((k_r1-result_test.bus(pq,8))./result_test.bus(pq,8)));
        e2=max(abs((k_r2-result_test.branch(:,14))./result_test.branch(:,14) ));
        e3=max(abs((k_r3-result_test.branch(:,15))./result_test.branch(:,15) ));
        e=[e1,e2,e3];
        emax=e*100;
        '������'
        [emean,emax]
    end
    if TEST_OPtion==2
        num_test=num_test_input;
        OPT_PF=zeros(num_test,output_num);
        OPT_kpm=zeros(num_test,output_num);
        OPT_kpm2=zeros(num_test,output_num);
        SCU=[];
        temp_range=temp_range_test_input_p;
        temp_range1=temp_range1_test_input_p; %1-temp_range/2;
        
    
        Input_test=zeros(input_num,num_test);
        Input_test(1:length(pq),1:num_test)=(rand(length(pq),num_test)*temp_range_test_input_p+temp_range1_test_input_p).*case_name_or.bus(pq,3);
        Input_test(length(pq)+1:2*length(pq),1:num_test)=(rand(length(pq),num_test)*temp_range_test_input_q+temp_range1_test_input_q).*case_name_or.bus(pq,4);
        for j=1:length(pv)
            Input_test(2*length(pq)+j,1:num_test)=(rand(1,num_test)*temp_range_test_input_pv_p+temp_range1_test_input_pv_p)*sum(case_name_or.gen( pv_pos(j,1): pv_pos(j,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
            %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
            Input_test(2*length(pq)+length(pv)+j,1:num_test)=case_name_or.gen( pv_pos(j,1),6)*(rand(1,num_test)*temp_range_test_input_pv_v+temp_range1_test_input_pv_v);
        end
        Input_test(2*length(pq)+2*length(pv)+1,:)=case_name_or.gen( ref_pos,6)*(rand(1,num_test)*temp_range_test_input_ref_v+temp_range1_test_input_ref_v);

        
        t_temp=0;
        
        if test_type==3
            Branch_error_p=zeros(Branch_Num,num_test);
            
            R_bus_Vm=[];
            R_bus_Vm2=[];
            RRRR2=[];
            Line_Q=[];
            Line_Q_erroe=[];
            
           
        end
         if test_type==4
             Branch_error_pq_sita=zeros(size(pq,1),num_test);
             RR_PQ_V=[];
         end
         Branch_error_pv_sita=zeros(size(pv,1),num_test);
             
          ERROR_happen=[];
        for i=1:num_test
            
            
            
%             Input_test(1:length(pq),:)=rand(length(pq),1).*PQ_1(:,1)*P_rate; %-P_rate/2;
%             Input_test(length(pq)+1:2*length(pq),:)=rand(length(pq),1).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
%             Input_test(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),1)*PV_P_rate;
%             Input_test(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),1)*PV_V_rate+1;
            
            temp_iptpq_p=Input_test(1:length(pq),i);
            temp_iptpq_q=Input_test(length(pq)+1:2*length(pq),i);
            temp_iptpv_p=Input_test(2*length(pq)+1:2*length(pq)+length(pv),i);
            temp_iptpv_v=Input_test(2*length(pq)+length(pv)+1:input_num,i);
            temp_iptref_v=Input_test(2*length(pq)+2*length(pv)+1,i);
            case_name1=case_name;
            
            case_name1.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
            %     case_name1.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
            for j=1:length(pv)
                case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
                case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
            end
            case_name1.gen(ref_pos,pos_gen_v)=temp_iptref_v;
            [result_test,scuess]=runpf(case_name1);
            
            output_testPF=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15);result_test.bus(pq,9);result_test.bus(pv,9)];
            OPT_PF(i,:)=output_testPF';
            
            if scuess
                t_temp=t_temp+1;
                SCU=[SCU;i];
                
                %                 IPT_test=liftFun(Input_test(:,i));
                if weather_pu
                    
                    if pu_type
                        IPT_test=liftFun(Input_test(:,i));
                        IPT_test=IPT_test./Standard_Input_lift;
                    else
                        Input_test_PU=Input_test(:,i)./Standard_Input1; %��������ı��ۻ�
                        IPT_test=liftFun(Input_test_PU);
                    end
                else
                    IPT_test=liftFun(Input_test(:,i));
                end
                if Using_M==1
                    TPY=M*(IPT_test*IPT_test');
                    OPT1=TPY(:,1)/IPT_test(1,1);
                    
                    TPY=(M2)*Input_test(:,i)*Input_test(:,i)';
                    OPT2=TPY(:,1)/Input_test(1,1);
                else
                    OPT1=M*IPT_test;
                    OPT2=(M2)*Input_test(:,i);
                end
                opt1=OPT1(1:output_num,1);
                OPT_kpm(i,:)=opt1';
                opt2=OPT2(1:output_num,1);
                OPT_kpm2(i,:)=opt2';
            end
            
%             if scuess
%                 if test_type==3
%                     [pos_temp,temp_error] = Find_Max_Erroe_In_1moment(output_testPF,opt1,5,test_type,case_name);
%                     Branch_error_p(:,i)=temp_error;
%                     if ~isempty(pos_temp)
%                         ERROR_happen=[ERROR_happen;i];
%                         stophere=1;
%                         RRR_bus1=result_test.bus(case_name.branch(pos_temp,1),8);
%                         RRR_bus2=result_test.bus(case_name.branch(pos_temp,2),8);
%                         RRR2=result_test.bus(case_name.branch(pos_temp,1),9)-result_test.bus(case_name.branch(pos_temp,2),9);
%                         
%                         R_bus_Vm=[R_bus_Vm;RRR_bus1,RRR_bus2];
%                         
%                         Line_Q_temp=result_test.branch(pos_temp,15);
%                         Line_Q_erroe_temp=abs(result_test.branch(pos_temp,15)-opt1(size(pq,1)+Branch_Num+pos_temp));
%                         Line_Q=[Line_Q;Line_Q_temp];
%                         Line_Q_erroe=[Line_Q_erroe;Line_Q_erroe_temp];
%                         RRRR2=[RRRR2;RRR2];
%                     end
%                 end
%                  if test_type==4
%                      [pos_temp,temp_error] = Find_Max_Erroe_In_1moment(output_testPF,opt1,1.0,test_type,case_name);
%                      Branch_error_pq_sita(:,i)=temp_error;
%                      if ~isempty(pos_temp)
%                          ERROR_happen=[ERROR_happen;i];
%                          RR_PQ_V_temp=result_test.bus(pq(pos_temp),8);
%                          RR_PQ_V=[RR_PQ_V;RR_PQ_V_temp];
%                      end
%                  end
%                  [pos_temp,temp_error] = Find_Max_Erroe_In_1moment(output_testPF,opt1,1.0,5,case_name);
%                  Branch_error_pv_sita(:,i)=temp_error;
%             end
        end
        
        
        Branch_error_pv_sita=Branch_error_pv_sita(:,SCU);
        if PicPut
        if size(pv,1)
            figure;
            plot(Branch_error_pv_sita);
            xlabel('�ڵ���');ylabel('��ѹ���/�Ƕ�');
            title('PV�ڵ��ѹ������')
        end
        end
        
       OPT_PF_pq_Va=OPT_PF(SCU,1:length(pq));
        OPT_kpm_pq_Va=OPT_kpm(SCU,1:length(pq));
        OPT_kpm_pq_Va2=OPT_kpm2(SCU,1:length(pq));
        
        OPT_PF_branch_p=OPT_PF(SCU,length(pq)+1:length(pq)+size(case_name.branch,1));
        OPT_kpm_branch_p=OPT_kpm(SCU,length(pq)+1:length(pq)+size(case_name.branch,1));
        OPT_kpm_branch_p2=OPT_kpm2(SCU,length(pq)+1:length(pq)+size(case_name.branch,1));
        %
        OPT_PF_branch_q=OPT_PF(SCU,length(pq)+size(case_name.branch,1)+1:length(pq)+2*size(case_name.branch,1));
        OPT_kpm_branch_q=OPT_kpm(SCU,length(pq)+size(case_name.branch,1)+1:length(pq)+2*size(case_name.branch,1));
        OPT_kpm_branch_q2=OPT_kpm2(SCU,length(pq)+size(case_name.branch,1)+1:length(pq)+2*size(case_name.branch,1));
        
        OPT_PF_pq_Vang=OPT_PF(SCU,length(pq)+2*size(case_name.branch,1)+1:2*length(pq)+2*size(case_name.branch,1));
        OPT_kpm_pq_Vang=OPT_kpm(SCU,length(pq)+2*size(case_name.branch,1)+1:2*length(pq)+2*size(case_name.branch,1));
        OPT_kpm_pq_Vang2=OPT_kpm2(SCU,length(pq)+2*size(case_name.branch,1)+1:2*length(pq)+2*size(case_name.branch,1));
        
        OPT_PF_pv_Vang=OPT_PF(SCU,2*length(pq)+2*size(case_name.branch,1)+1:length(pv)+2*length(pq)+2*size(case_name.branch,1));
        OPT_kpm_pv_Vang=OPT_kpm(SCU,2*length(pq)+2*size(case_name.branch,1)+1:length(pv)+2*length(pq)+2*size(case_name.branch,1));
        OPT_kpm_pv_Vang2=OPT_kpm2(SCU,2*length(pq)+2*size(case_name.branch,1)+1:length(pv)+2*length(pq)+2*size(case_name.branch,1));
        
        
        Cal_Result_OR.NR_PQ_Vm=OPT_PF_pq_Va;
        Cal_Result_OR.NR_PQ_Va=OPT_PF_pq_Vang;
        Cal_Result_OR.NR_PV_Va=OPT_PF_pv_Vang;
        Cal_Result_OR.NR_PL=OPT_PF_branch_p;
        Cal_Result_OR.NR_QL=OPT_PF_branch_q;
        
        Cal_Result_OR.KMP_PQ_Vm=OPT_kpm_pq_Va;
        Cal_Result_OR.KMP_PQ_Va=OPT_kpm_pq_Vang;
        Cal_Result_OR.KMP_PV_Va=OPT_kpm_pv_Vang;
        Cal_Result_OR.KMP_PL=OPT_kpm_branch_p;
        Cal_Result_OR.KMP_QL=OPT_kpm_branch_q;
        
        Cal_Result_OR.KMP_PQ_Vm2=OPT_kpm_pq_Va2;
        Cal_Result_OR.KMP_PQ_Va2=OPT_kpm_pq_Vang2;
        Cal_Result_OR.KMP_PV_Va2=OPT_kpm_pv_Vang2;
        Cal_Result_OR.KMP_PL2=OPT_kpm_branch_p2;
        Cal_Result_OR.KMP_QL2=OPT_kpm_branch_q2;
        
        
        OPT_PF_pq_Va=reshape(OPT_PF_pq_Va,size(SCU,1)*length(pq),1);
        OPT_kpm_pq_Va=reshape(OPT_kpm_pq_Va,size(SCU,1)*length(pq),1);
        OPT_kpm_pq_Va2=reshape(OPT_kpm_pq_Va2,size(SCU,1)*length(pq),1);
        
        OPT_PF_branch_p=reshape(OPT_PF_branch_p,size(SCU,1)*size(case_name.branch,1),1);
        OPT_kpm_branch_p=reshape(OPT_kpm_branch_p,size(SCU,1)*size(case_name.branch,1),1);
        OPT_kpm_branch_p2=reshape(OPT_kpm_branch_p2,size(SCU,1)*size(case_name.branch,1),1);
        
        OPT_PF_branch_q=reshape(OPT_PF_branch_q,size(SCU,1)*size(case_name.branch,1),1);
        OPT_kpm_branch_q=reshape(OPT_kpm_branch_q,size(SCU,1)*size(case_name.branch,1),1);
         OPT_kpm_branch_q2=reshape(OPT_kpm_branch_q2,size(SCU,1)*size(case_name.branch,1),1);
        
        OPT_PF_pq_Vang=reshape(OPT_PF_pq_Vang,size(SCU,1)*length(pq),1);
        OPT_kpm_pq_Vang=reshape(OPT_kpm_pq_Vang,size(SCU,1)*length(pq),1);
        OPT_kpm_pq_Vang2=reshape(OPT_kpm_pq_Vang2,size(SCU,1)*length(pq),1);
        
        OPT_PF_pv_Vang=reshape(OPT_PF_pv_Vang,size(SCU,1)*length(pv),1);
        OPT_kpm_pv_Vang=reshape(OPT_kpm_pv_Vang,size(SCU,1)*length(pv),1);
        OPT_kpm_pv_Vang2=reshape(OPT_kpm_pv_Vang2,size(SCU,1)*length(pv),1);
        
        Cal_Result_Reshaped.NR_PQ_Vm=OPT_PF_pq_Va;
        Cal_Result_Reshaped.NR_PQ_Va=OPT_PF_pq_Vang;
        Cal_Result_Reshaped.NR_PV_Va=OPT_PF_pv_Vang;
        Cal_Result_Reshaped.NR_PL=OPT_PF_branch_p;
        Cal_Result_Reshaped.NR_QL=OPT_PF_branch_q;
        
        Cal_Result_Reshaped.KMP_PQ_Vm=OPT_kpm_pq_Va;
        Cal_Result_Reshaped.KMP_PQ_Va=OPT_kpm_pq_Vang;
        Cal_Result_Reshaped.KMP_PV_Va=OPT_kpm_pv_Vang;
        Cal_Result_Reshaped.KMP_PL=OPT_kpm_branch_p;
        Cal_Result_Reshaped.KMP_QL=OPT_kpm_branch_q;
        
        Cal_Result_Reshaped.KMP_PQ_Vm2=OPT_kpm_pq_Va2;
        Cal_Result_Reshaped.KMP_PQ_Va2=OPT_kpm_pq_Vang2;
        Cal_Result_Reshaped.KMP_PV_Va2=OPT_kpm_pv_Vang2;
        Cal_Result_Reshaped.KMP_PL2=OPT_kpm_branch_p2;
        Cal_Result_Reshaped.KMP_QL2=OPT_kpm_branch_q2;
        
        
        
        if size(pv,1)
            pic_num=5;
        else 
            pic_num=4;
        end
        
        if PicPut
        figure;
        subplot(pic_num,1,1)
        plot(OPT_PF_pq_Va);
        hold on;
        plot(OPT_kpm_pq_Va);
        legend('����������','Koopman')
        title('PQ�ڵ��ѹ��ֵ')
        subplot(pic_num,1,2)
        plot(OPT_PF_branch_p);
        hold on;
        plot(OPT_kpm_branch_p);
        legend('����������','Koopman')
        title('֧·�й�����')
        subplot(pic_num,1,3)
        plot(OPT_PF_branch_q);
        hold on;
        plot(OPT_kpm_branch_q);
        legend('����������','Koopman')
        title('֧·�޹�����')
        subplot(pic_num,1,4)
        plot(OPT_PF_pq_Vang);
        hold on;
        plot(OPT_kpm_pq_Vang);
        legend('����������','Koopman')
        title('PQ�ڵ����')
        if size(pv,1)
            subplot(pic_num,1,5)
            plot(OPT_PF_pv_Vang);
            hold on;
            plot(OPT_kpm_pv_Vang);
            legend('����������','Koopman')
            title('PV�ڵ����')
        end
        end
        
        'ƽ���������';
        OPT_abs_p=abs((OPT_PF_pq_Va-OPT_kpm_pq_Va));
        OPT_abs_l_p=(abs((OPT_PF_branch_p-OPT_kpm_branch_p)));
        OPT_abs_l_q=(abs((OPT_PF_branch_q-OPT_kpm_branch_q)));
        OPT_abs_pq_sita=(abs((OPT_PF_pq_Vang-OPT_kpm_pq_Vang)));
        OPT_abs_pv_sita=(abs((OPT_PF_pv_Vang-OPT_kpm_pv_Vang)));
        
        OPT_abs_p2=abs((OPT_PF_pq_Va-OPT_kpm_pq_Va2));
        OPT_abs_l_p2=(abs((OPT_PF_branch_p-OPT_kpm_branch_p2)));
        OPT_abs_l_q2=(abs((OPT_PF_branch_q-OPT_kpm_branch_q2)));
        OPT_abs_pq_sita2=(abs((OPT_PF_pq_Vang-OPT_kpm_pq_Vang2)));
        OPT_abs_pv_sita2=(abs((OPT_PF_pv_Vang-OPT_kpm_pv_Vang2)));
        
        
        if size(pv,1)
            e_a_mean=[mean(OPT_abs_p),mean(OPT_abs_l_p),mean(OPT_abs_l_q),mean(OPT_abs_pq_sita),mean(OPT_abs_pv_sita)];
            e_a_mean2=[mean(OPT_abs_p2),mean(OPT_abs_l_p2),mean(OPT_abs_l_q2),mean(OPT_abs_pq_sita2),mean(OPT_abs_pv_sita2)];
        else
            e_a_mean=[mean(OPT_abs_p),mean(OPT_abs_l_p),mean(OPT_abs_l_q),mean(OPT_abs_pq_sita)];
            e_a_mean2=[mean(OPT_abs_p2),mean(OPT_abs_l_p2),mean(OPT_abs_l_q2),mean(OPT_abs_pq_sita2)];
        end
        
%         '��ѹ��ֵƽ���������'
%         mean(OPT_abs_p)
%         mean(OPT_abs_p2)
%         '��ѹ���ƽ���������'
%         if size(pv,1)
%             ( mean(OPT_abs_pq_sita)*size(pq,1)+mean(OPT_abs_pv_sita)*size(pv,1))/( size(pq,1)+size(pv,1))
%             ( mean(OPT_abs_pq_sita2)*size(pq,1)+mean(OPT_abs_pv_sita2)*size(pv,1))/( size(pq,1)+size(pv,1))
%         else
%             mean(OPT_abs_pq_sita)
%             mean(OPT_abs_pq_sita2)
%         end
        
        '���������';

        if size(pv,1)
            e_a_max=[max(OPT_abs_p),max(OPT_abs_l_p),max(OPT_abs_l_q),max(OPT_abs_pq_sita),max(OPT_abs_pv_sita)];
            e_a_max2=[max(OPT_abs_p2),max(OPT_abs_l_p2),max(OPT_abs_l_q2),max(OPT_abs_pq_sita2),max(OPT_abs_pv_sita2)];
        else
            e_a_max=[max(OPT_abs_p),max(OPT_abs_l_p),max(OPT_abs_l_q),max(OPT_abs_pq_sita)];
            e_a_max2=[max(OPT_abs_p2),max(OPT_abs_l_p2),max(OPT_abs_l_q2),max(OPT_abs_pq_sita2)];
        end
%         '�������   mean;max'
%         e_a_mean
%         e_a_mean2
%         e_a_max
%         e_a_max2
        [e_a_mean;e_a_max];
    
                
       %-----------------------������----------------------------------
        e_pq_p_b=abs(OPT_abs_p./OPT_PF_pq_Va);
        e_l_p_b=abs(OPT_abs_l_p./OPT_PF_branch_p);
        e_l_q_b=abs(OPT_abs_l_q./OPT_PF_branch_q);
        e_pq_sita_b=abs(OPT_abs_pq_sita./OPT_PF_pq_Vang);
        e_pv_sita_b=abs(OPT_abs_pv_sita./OPT_PF_pv_Vang);
        
        aa1=e_l_p_b;
        pos_temp=isinf(e_l_p_b);
        pos_temp2=isnan(e_l_p_b);
        pos_temp=pos_temp|pos_temp2;
        aa1(pos_temp)=[];
        aa2=e_l_q_b;
        pos_temp=isinf(e_l_q_b);
        pos_temp2=isnan(e_l_q_b);
        pos_temp=pos_temp|pos_temp2;
        aa2(pos_temp)=[];
        
        e_pq_p_b2=abs(OPT_abs_p2./OPT_PF_pq_Va);
        e_l_p_b2=abs(OPT_abs_l_p2./OPT_PF_branch_p);
        e_l_q_b2=abs(OPT_abs_l_q2./OPT_PF_branch_q);
        e_pq_sita_b2=abs(OPT_abs_pq_sita2./OPT_PF_pq_Vang);
        e_pv_sita_b2=abs(OPT_abs_pv_sita2./OPT_PF_pv_Vang);
        
        aab1=e_l_p_b2;
        pos_temp=isinf(e_l_p_b2);
        pos_temp2=isnan(e_l_p_b2);
        pos_temp=pos_temp|pos_temp2;
        aab1(pos_temp)=[];
        aab2=e_l_q_b2;
        pos_temp=isinf(e_l_q_b2);
        pos_temp2=isnan(e_l_q_b2);
        pos_temp=pos_temp|pos_temp2;
        aab2(pos_temp)=[];
        
         'ƽ��������';
        if size(pv,1)
            e=[mean(e_pq_p_b),mean(aa1),mean(aa2),mean(e_pq_sita_b),mean(e_pv_sita_b)];
            e2=[mean(e_pq_p_b2),mean(aab1),mean(aab2),mean(e_pq_sita_b2),mean(e_pv_sita_b2)];
        
        else
            e=[mean(e_pq_p_b),mean(aa1),mean(aa2),mean(e_pq_sita_b)];
            e2=[mean(e_pq_p_b2),mean(aab1),mean(aab2),mean(e_pq_sita_b2)];
        
        end
        emean=e*100;
        emean2=e2*100;
        
        '���������';
        if size(pv,1)
            e=[max(e_pq_p_b),max(aa1),max(aa2),max(e_pq_sita_b),max(e_pv_sita_b)];
            e2=[max(e_pq_p_b2),max(aab1),max(aab2),max(e_pq_sita_b2),max(e_pv_sita_b2)];
        else
            e=[max(e_pq_p_b),max(aa1),max(aa2),max(e_pq_sita_b)];
            e2=[max(e_pq_p_b2),max(aab1),max(aab2),max(e_pq_sita_b2)];
        end
        emax=e*100;
        emax2=e2*100;
%         '������ (%)  mean; max'
%         emean
%         emean2
%         emax
%         emax2
        [emean;emax];
        
        
         %-----------------------�������ʼ����----------------------------------
       if PicPut
        figure;
        subplot(2,1,1);
        plot(OPT_PF_branch_p)
        hold on;
        plot((OPT_PF_branch_p-OPT_kpm_branch_p))
        xlabel('��·���')
        ylabel('�й�����/MW')
        legend('NR�������','�������');
        title('��·�й����ʾ���������ֵ');
        
        subplot(2,1,2);
        plot(OPT_PF_branch_q)
        hold on;
        plot((OPT_PF_branch_q-OPT_kpm_branch_q))
        xlabel('��·���')
        ylabel('�޹�����/MVAR')
        legend('NR�������','�������');
        title('��·�޹����ʾ���������ֵ');
       end
    end

    
end

end

