function [Input_Lagrangian_Median,Output_Slope_Diff,Dirrection] = Generate_Tranning_OR_Testing_SensMatrixData(Input,Output)
%UNTITLED5 此处显示有关此函数的摘要
%   Input_Lagrangian_Median  新定义拉格朗日中点
%   Output_Slope_Diff   通过拉格朗日中点公式定义斜率（采样点的函数值差）
%   Dirrection 两个输入采样点的标准化向量差（即增量方向）
%% Select the data squence
data_squence='OR';   %'OR'(Default) 'Closest'
switch data_squence
    case 'OR' %origenal data
        Input_Diff=Input(:,2:end)-Input(:,1:end-1);
        Output_Diff=Output(:,2:end)-Output(:,1:end-1);
    case 'Closest' %Modified Closest data
        Input_Diff=Input(:,2:end);
        Output_Diff=Output(:,2:end);
        for i =1:size(Input_Diff,2)
            temp=1;
            Min_L=1000000;
            for j=1:size(Input_Diff,2)
                if i~=j
                    temp_L=sqrt(norm(Input(:,i)-Input(:,j)));
                    if temp_L<Min_L
                        Min_L=temp_L;
                        temp=j;
                    end
                end
            end
            Input_Diff(:,i)=Input(:,temp)-Input(:,i);
            Output_Diff(:,i)=Output(:,temp)-Output(:,i);
        end
end
%%

Output_Slope_Diff=Output_Diff;
Dirrection=Input_Diff;
Dirrection_Magnifi=1;
for i =1:size(Input_Diff,2)    
    Dirrection(:,i)=Input_Diff(:,i)/norm(Input_Diff(:,i))*Dirrection_Magnifi;
    Output_Slope_Diff(:,i)=Output_Diff(:,i)/norm(Input_Diff(:,i));
end
%%
Order=2; % 2: geometric midpoint 
[Input_Lagrangian_Median] = Lagrangian_Median_Value(Input(:,1:end-1),Input(:,2:end),Order);


end

