function [Result_CPLEX] = Build_Constraint(casename_NR,line_active,FixVar,progeny_Matric,Ybus,Zbus,Bus_Num,Branch_Num,INclude_PV_node,ref,Voltage)
% Build_Constraint Build_Constraint for CPLEX & Solve the optimization Problem
% ZYX 20201224
%% Init the Variable
PV_P= sdpvar(size(INclude_PV_node,2),1);
PV_Q = sdpvar(size(INclude_PV_node,2),1);
v_square = sdpvar(size(casename_NR.bus,1),1); %square of Node Voltage
i_square = sdpvar(size(line_active,1),1); %square of branch I
Pline = sdpvar(size(line_active,1),1); %Active power flow in barnch
Qline = sdpvar(size(line_active,1),1); %Reactive power flow in barnch

PVinverter_P=FixVar.PVinverter_P;
P_Load=FixVar.P_Load;
Q_Load=FixVar.Q_Load;
INclude_PV_S=FixVar.INclude_PV_S;
%% Change the Format of Data
G_ij=real(Ybus);
B_ij=imag(Ybus);
R_ij=real(Zbus);
X_ij=imag(Zbus);
Rline=zeros(size(Pline)); %To record the Branch resistance in the Branch Number
%% Build the Constraint
Constraint=[];
%% (1)PV Inverter Output Constraint
for i=1:size(PV_P,1)
%     Constraint=[Constraint; 0<=PV_P(i,1)<=PVinverter_P(i,1)];  %PV inverter Active Power Up limint
    Constraint=[Constraint; PV_P(i,1)==PVinverter_P(i,1)];  %PV inverter Active Power Up limint
    Constraint=[Constraint; norm([PV_P(i,1);PV_Q(i,1)])<=INclude_PV_S(i,1)];  %PV inverter Active Power Up limint
end
%% (2)Voltage Constraint (%!!!! No Transformer is considerd in the Branch ,so the Voltage)
for i=1:Bus_Num
    if i~=ref
        Constraint=[Constraint;(Voltage.min*casename_NR.bus(1,10))^2<=v_square(i,1)<=(Voltage.max*casename_NR.bus(1,10))^2];
    else % reference bus voltage init
        Constraint=[Constraint;v_square(i,1)==(1.00*casename_NR.bus(1,10))^2];
    end
end
%% (3)Distflow Constraint
for i=1:Bus_Num
    if i~=ref
        temp_progeny_node=find(progeny_Matric(i,:)==1);
        Down_stream_line_ID=zeros(size(temp_progeny_node));
        node_now=i;
        for j=1:size(temp_progeny_node,2)
            node_down=temp_progeny_node(1,j);
            Down_stream_line_ID(1,j) = find_line_num(casename_NR,line_active,node_now,node_down);
        end
        node_up=find(progeny_Matric(:,i)==1);
        Up_stream_line_ID= find_line_num(casename_NR,line_active,node_up,node_now);
        %% Branch Flow Constraint
        if ismember(node_now,INclude_PV_node)
            pos_PV_num=find(INclude_PV_node==node_now);
            Constraint=[Constraint;sum(Pline(Down_stream_line_ID,1))==...
                Pline(Up_stream_line_ID,1)-R_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-(P_Load(node_now,1)-PV_P(pos_PV_num,1))];  %PV_P(pos_PV_num,1)
            Constraint=[Constraint;sum(Qline(Down_stream_line_ID,1))==...
                Qline(Up_stream_line_ID,1)-X_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-(Q_Load(node_now,1)-PV_Q(pos_PV_num,1))];
        else
            Constraint=[Constraint;sum(Pline(Down_stream_line_ID,1))==...
                Pline(Up_stream_line_ID,1)-R_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-P_Load(node_now,1)];
            Constraint=[Constraint;sum(Qline(Down_stream_line_ID,1))==...
                Qline(Up_stream_line_ID,1)-X_ij(node_up,node_now)*i_square(Up_stream_line_ID,1)-Q_Load(node_now,1)];
        end
        %% SOCP Current-Voltage_Power Constraint
        Constraint=[Constraint;norm([2*Pline(Up_stream_line_ID,1);2*Qline(Up_stream_line_ID,1);(v_square(node_up,1)-i_square(Up_stream_line_ID,1))],2)...
            <= i_square(Up_stream_line_ID,1)+v_square(node_up,1)];
        %% Voltage Constraint
        Constraint=[Constraint;v_square(node_now,1)==v_square(node_up,1)-2*(R_ij(node_up,node_now)*Pline(Up_stream_line_ID,1)+X_ij(node_up,node_now)*Qline(Up_stream_line_ID,1))...
            +(R_ij(node_up,node_now)^2+X_ij(node_up,node_now)^2)*i_square(Up_stream_line_ID,1)];
        %% Branch Current Square Constraint
        Constraint=[Constraint;i_square(Up_stream_line_ID,1)>=0];
        
        Rline(Up_stream_line_ID)=R_ij(node_up,node_now);
    end
end

%% CPLEX Optimization & Objective inside
% options = sdpsettings('solver','cplex','verbose',1);
objective=sum(Rline.*i_square);
% objective=sum(abs(PV_Q));
varargout=optimize(Constraint,objective);
varargout.info
%% Test the Satisfacation of Constraint 
node_test=5;
% Test_The_Constraint_Satisfacation(node_test);
%% Output Structure
Result_CPLEX.Pline=value(Pline);        Result_CPLEX.Qline=value(Qline);
Result_CPLEX.v_square=value(v_square);  Result_CPLEX.i_square=value(i_square);
Result_CPLEX.i_m=sqrt(value(i_square)); Result_CPLEX.v_m=sqrt(value(v_square));
Result_CPLEX.PV_P=value(PV_P);          Result_CPLEX.PV_Q=value(PV_Q);

end

