function [CPLEX_Results] = Loaded_Data_Preprocess(temp_load_data,case_name,Input_Standard,Pos_In_OutPut,Device_Info)
%Loaded_Data_Preprocess Data Transfer & NR Check

%% Data Transfer
    load_data=temp_load_data;
    CPLEX_Results.PQ_Vm_Result=load_data.Result_CPLEX.Voltage(Pos_In_OutPut.pq,1);
    CPLEX_Results.PV_Q=load_data.Result_CPLEX.PV_Q;
    CPLEX_Results.PV_P=load_data.Result_CPLEX.PV_P;
    CPLEX_Results.objective=load_data.Result_CPLEX.objective;
    CPLEX_Results.Ploss=load_data.Result_CPLEX.Ploss;
    CPLEX_Results.PV_Q_Adj=load_data.Result_CPLEX.PV_Q_Adj;
    CPLEX_Results.PV_P_Adj=load_data.Result_CPLEX.PV_P_Adj;
%% NR Check
    input_temp=Input_Standard;
    input_temp([Pos_In_OutPut.Pos_P_in_Inventer,Pos_In_OutPut.Pos_Q_in_Inventer],1)=[CPLEX_Results.PV_P;CPLEX_Results.PV_Q];
    [~,~,~,results_NR_temp]=NR_PF_Cal(case_name,input_temp,Device_Info);
    CPLEX_Results.Vm_PQ_NRCheck=results_NR_temp.bus(Pos_In_OutPut.pq,8);
    CPLEX_Results.PLoss_NRCheck=sum(abs(results_NR_temp.branch(:,14)+results_NR_temp.branch(:,16)));
end