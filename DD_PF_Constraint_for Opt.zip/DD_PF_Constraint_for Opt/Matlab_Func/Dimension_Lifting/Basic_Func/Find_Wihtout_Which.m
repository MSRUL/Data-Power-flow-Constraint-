function [Complementary_Variable] = Find_Wihtout_Which(Total,Holden)
%UNTITLED3 Find the Complementary Variable Ѱ�һ�������
%   �˴���ʾ��ϸ˵��
totalnum=size(Total,2);
holdennum=size(Holden,2);

Complementary_Variable=[];
for i=1:totalnum
    pos_temp=find(Holden==Total(1,i));
    if length(pos_temp)
        already_hold=1;
    else
        Complementary_Variable=[Complementary_Variable,Total(1,i)];
    end
end
if length(Complementary_Variable)~=totalnum-holdennum
   stophere=1;
end
end

