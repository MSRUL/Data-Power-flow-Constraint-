function [x_CS,y_CS] = Find_Pos_in_Line(x1,y1,x6,y6,length)
%UNTITLED 此处提供此函数的摘要
%   此处提供详细说明
x_CS=x1+(x6-x1)/(norm([abs(x6-x1);abs(y6-y1)]))*length;
y_CS=y1+(y6-y1)/(norm([abs(x6-x1);abs(y6-y1)]))*length;
end