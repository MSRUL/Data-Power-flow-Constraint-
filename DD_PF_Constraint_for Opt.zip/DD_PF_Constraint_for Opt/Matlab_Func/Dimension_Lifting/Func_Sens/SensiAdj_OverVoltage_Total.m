function [Record] = SensiAdj_OverVoltage_Total(case_name,Input_Standard,Device_Info,Pos_In_OutPut,AdjStep,Voltage,SenAdj_Index)
%function [Record] = Adj_OverVoltage_Trand_Sensi(Sensi_M,INclude_PV_S,casename_NR,results_NR,INclude_PV_node,Input_Standard,Pos_In_OutPut,Over_Voltage,TransTab_step,adjust_Q_step,adjust_P_step,Voltage)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
SenAdj_Index;


%% Basic Case Data
[~,pv, ~] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
end
Bus_Num=size(case_name.bus,1);

%% Sensitivity Matrix Calculation of Traditional NR Method
[~,~,casename_NR,results_NR]=NR_PF_Cal(case_name,Input_Standard,Device_Info); %NR_PF_Cal(case_name,Input_Standard,INclude_PV_node_Pos,INclude_PV_S,test_input_num);

Over_Voltage=find(results_NR.bus(:,8)>Voltage.max);
Below_Voltage=find(results_NR.bus(:,8)<Voltage.min);

[J,~,~]=makeJac_20200713(results_NR.baseMVA, results_NR.bus, results_NR.branch, results_NR.gen, 1);
Sensi_M=J\eye(size(J));  %Vdeta=S1*PQdeta; MUST USE p.u. !!!
Sensi_M=Sensi_M(Bus_Num+1:2*Bus_Num,:);
figure;surf(Sensi_M);xlabel('PQ Injection');ylabel('Bus Voltage Magnitude');
%%
INclude_PV_S=Device_Info.INclude_PV_S;
INclude_PV_node=Device_Info.INclude_PV_node;
TransTab_step=AdjStep.TransTab_step;

adjust_P_step=AdjStep.adjust_P_step;
adjust_Q_step=AdjStep.adjust_Q_step;


%%
%------- Output of PV Inverter & PQ Load (In IEEE 33 Only PQ type of Bus is Considered)------------------------
PV_out_P=Input_Standard(Pos_In_OutPut.Pos_P_in_Inventer,:);
PV_out_Q=Input_Standard(Pos_In_OutPut.Pos_Q_in_Inventer,:);
P_Load=Input_Standard(Pos_In_OutPut.Pos_P_Load);
Q_Load=Input_Standard(Pos_In_OutPut.Pos_Q_Load);

Base_Input=[0;P_Load;0;Q_Load]; % the 0 is the reference bus power injection
Adj_Input=[PV_out_P,PV_out_Q];

casename_NR_controled=casename_NR;

Pos_Q_of_PV=size(casename_NR.bus,1)+INclude_PV_node;  %Position of Q output in PV
Pos_P_of_PV=size(casename_NR.bus,1)+INclude_PV_node;  %Position of Q output in PV
%-----------------------------------------
temp_adj=zeros(size(casename_NR.bus,1)*2,1);
temp_adj(INclude_PV_node,1)=temp_adj(INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),1);
temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)=temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),2);
INPUT_Record=Base_Input-temp_adj;
Control_Record=[Adj_Input(:,1);Adj_Input(:,2)];
OUTPUT_Record=results_NR.bus(:,8);


Adj_Q=1; % Weather to adjust the Q of PV
Adj_P=0; % Weather to adjust the P of PV
numof_PV_inventor=[1,1,1]; %Init the max sensitive index
%% Below Voltage
S1_Rank=Sensi_M;
while(length(Below_Voltage)>0)
%     for i=1:length(Below_Voltage)
         temp_i=find(OUTPUT_Record(:,end)==min(OUTPUT_Record(:,end)));
         i=find(Below_Voltage==temp_i(1,1));
        
        if Adj_Q
            [numof_PV_inventor]=find(  abs(S1_Rank(Below_Voltage(i),Pos_Q_of_PV))==max(abs(S1_Rank(Below_Voltage(i),Pos_Q_of_PV))) );  %
        end
        if length(numof_PV_inventor)>1  %
            stophere=1;
        end
        
        if ~Adj_P
            if S1_Rank(Below_Voltage(i),size(casename_NR.bus,1)+INclude_PV_node(numof_PV_inventor))>=0  %
                B_direction=1;
            else
                B_direction=-1;
            end
            %                 B_direction=-1;
            PV_Q_Limit_Rate=AdjStep.PV_Q_Limit_Rate;
            if (Adj_Input(numof_PV_inventor,1)^2+Adj_Input(numof_PV_inventor,2)^2)<INclude_PV_S(numof_PV_inventor)^2 && abs(Adj_Input(numof_PV_inventor,2))<INclude_PV_S(numof_PV_inventor)*PV_Q_Limit_Rate
                Adj_Input(numof_PV_inventor,2)=Adj_Input(numof_PV_inventor,2)+B_direction*adjust_Q_step;
            else
                S1_Rank(:,size(casename_NR.bus,1)+INclude_PV_node(numof_PV_inventor))=0;
                fprintf('\tThe %d th PV inverter total output power Limit has been meet\n',Device_Info.INclude_PV_node_Pos(numof_PV_inventor));
            end
        end
%     end
    temp_adj=zeros(size(casename_NR.bus,1)*2,1);
    temp_adj(INclude_PV_node,1)=temp_adj(INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),1);
    temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)=temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),2);
    temp_controled_input=Base_Input-temp_adj;
    casename_NR_controled.bus(:,[3,4])=[temp_controled_input(1:size(casename_NR.bus,1),1),temp_controled_input(1+size(casename_NR.bus,1):2*size(casename_NR.bus,1),1)];
    result_controled_temp=runpf(casename_NR_controled);
    result_controled=result_controled_temp.bus(:,8);
    %%
    OUTPUT_Record=[OUTPUT_Record,result_controled];
    INPUT_Record=[INPUT_Record,[casename_NR_controled.bus(:,3);casename_NR_controled.bus(:,4)]];
    Control_Record=[Control_Record,[Adj_Input(:,1);Adj_Input(:,2)]];
    Below_Voltage=find(result_controled<Voltage.min);
    %% Updata the Sensitive Matrix
    [J,~,~]=makeJac_20200713(casename_NR_controled.baseMVA, casename_NR_controled.bus, casename_NR_controled.branch, casename_NR_controled.gen, 1);
    Sensi_M=J\eye(size(J));  %Vdeta=S1*PQdeta; MUST USE p.u. !!!
    Sensi_M=Sensi_M(Bus_Num+1:2*Bus_Num,:);
    for j=1:size(Sensi_M,2)
        if sum(S1_Rank(:,j))==0
            Sensi_M(:,j)=0;
        end
    end
    S1_Rank=Sensi_M;
end
%% Over Voltage
S1_Rank=Sensi_M;
while(length(Over_Voltage)>0)
    for i=1:length(Over_Voltage)
        temp_i=find(OUTPUT_Record(:,end)==max(OUTPUT_Record(:,end)));
         i=find(Over_Voltage==temp_i(1,1));
        Over_Voltage(i);
        Over_Voltage(i);
        if Adj_Q
            [numof_PV_inventor]=find(  abs(S1_Rank(Over_Voltage(i),Pos_Q_of_PV))==max(abs(S1_Rank(Over_Voltage(i),Pos_Q_of_PV))) );  %瀵绘壘鏃犲姛鍔熺巼璋冭妭鐏垫晱搴︽渶楂樼殑鐐?
        end
        if length(numof_PV_inventor)>1  %鏃犳硶鎵惧埌鐏垫晱搴︽渶澶х殑鐐癸紝琛ㄦ槑姝ゆ椂绯荤粺涓凡缁忔病鏈夊厜浼忕殑鏃犲姛鍔熺巼鍙互鍙備笌璋冭妭浜嗐??
            stophere=1;
            
        end
        
        if ~Adj_P
            if S1_Rank(Over_Voltage(i),size(casename_NR.bus,1)+INclude_PV_node(numof_PV_inventor))>=0  %鍒ゆ柇鏈?澶у奖鍝嶇偣鏄杩樻槸璐?,浣滀负姝ｈ礋绯绘暟鍔犲叆璋冭妭閲忎腑
                B_direction=-1;
            else
                B_direction=1;
            end
            %                 B_direction=-1;
            PV_Q_Limit_Rate=AdjStep.PV_Q_Limit_Rate;
            if (Adj_Input(numof_PV_inventor,1)^2+Adj_Input(numof_PV_inventor,2)^2)<INclude_PV_S(numof_PV_inventor)^2 && abs(Adj_Input(numof_PV_inventor,2))<INclude_PV_S(numof_PV_inventor)*PV_Q_Limit_Rate
                Adj_Input(numof_PV_inventor,2)=Adj_Input(numof_PV_inventor,2)+B_direction*adjust_Q_step;
            else
                S1_Rank(:,size(casename_NR.bus,1)+INclude_PV_node(numof_PV_inventor))=0;
                fprintf('\tThe %d th PV inverter total output power Limit has been meet\n',Device_Info.INclude_PV_node_Pos(numof_PV_inventor));
            end
        end
    end
    temp_adj=zeros(size(casename_NR.bus,1)*2,1);
    temp_adj(INclude_PV_node,1)=temp_adj(INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),1);
    temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)=temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),2);
    temp_controled_input=Base_Input-temp_adj;
    casename_NR_controled.bus(:,[3,4])=[temp_controled_input(1:size(casename_NR.bus,1),1),temp_controled_input(1+size(casename_NR.bus,1):2*size(casename_NR.bus,1),1)];
    result_controled_temp=runpf(casename_NR_controled);
    result_controled=result_controled_temp.bus(:,8);
    %%
    OUTPUT_Record=[OUTPUT_Record,result_controled];
    INPUT_Record=[INPUT_Record,[casename_NR_controled.bus(:,3);casename_NR_controled.bus(:,4)]];
    Control_Record=[Control_Record,[Adj_Input(:,1);Adj_Input(:,2)]];
    Over_Voltage=find(result_controled>Voltage.max);
    %% Updata the Sensitive Matrix
    [J,~,~]=makeJac_20200713(casename_NR_controled.baseMVA, casename_NR_controled.bus, casename_NR_controled.branch, casename_NR_controled.gen, 1);
    Sensi_M=J\eye(size(J));  %Vdeta=S1*PQdeta; MUST USE p.u. !!!
    Sensi_M=Sensi_M(Bus_Num+1:2*Bus_Num,:);
    for j=1:size(Sensi_M,2)
        if sum(S1_Rank(:,j))==0
            Sensi_M(:,j)=0;
        end
    end
    S1_Rank=Sensi_M;
end
%%
Record.OUTPUT_Record=OUTPUT_Record;
Record.INPUT_Record=INPUT_Record;
Record.Control_Record=Control_Record;
%     Record.PLoss_Record=[sum(results_NR.branch(:,14)+results_NR.branch(:,16));sum(result_controled_temp.branch(:,14)+result_controled_temp.branch(:,16))];

%%
temp_adj_node=find((Record.INPUT_Record(:,end)-Record.INPUT_Record(:,1))~=0);
temp_adj_power=Record.INPUT_Record(temp_adj_node,end)-Record.INPUT_Record(temp_adj_node,1);
temp_adj_node=temp_adj_node-size(results_NR.bus,1);
fprintf('\tAdjust PV Node:');
for i=1:length(temp_adj_node)
    fprintf(' %d ,',temp_adj_node(i,1));
end
fprintf('\n\tAdjust PV Reactive Power:');
for i=1:length(temp_adj_node)
    fprintf(' %f kVar, ',temp_adj_power(i,1));
end
fprintf('\n');
end


