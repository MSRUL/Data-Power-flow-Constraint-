function [M_Sens_Output] = Cal_Sen_Single(M_BZ,Direct_Linear_Sens,Input,DLR_Parameterx)
%ZYX20220503 Use the Defference Method cal the Senstive Matrix of the single case
%%
X_lifted = Lift_Vector_Complete_Total(Input,DLR_Parameterx);

n_Lifted=size(X_lifted,1);
nx=size(Input,1);

%%
B_sen=zeros(nx,n_Lifted,size(M_BZ,1));
for i=1:size(M_BZ,1)
    B_sen(:,:,i)=reshape(M_BZ(i,:),n_Lifted,nx)';
end

Temp_X_Laga_lifted = Lift_Vector_Complete_Total(Input,DLR_Parameterx);

Sens_Dif_3=zeros(size(Direct_Linear_Sens));
for i =1:size(M_BZ,1)
    Sens_Dif_3(i,:,1)=B_sen(:,:,i)*Temp_X_Laga_lifted;
end
M_Sens_Output=Direct_Linear_Sens-Sens_Dif_3;

end