function [Input_Standard] = Loadin_Cases(path_last,LoadinCase_Info)
%%   case_type='Massive';  %'Single'  'Massive'
% case_chose='case116';   %'case116'  'case109' % Different DG and Load Power;
% Generate Data Function: 'J:\科研\Koopman_PF_Dispatch\Generate_TestCases.m'
%%

Case_Name=LoadinCase_Info.Case_Name;
case_type=LoadinCase_Info.case_type;
case_chose=LoadinCase_Info.case_chose;
number=LoadinCase_Info.number;

% LoadinCase_Info.case_type='ALL_Voltage';  %  'OverVoltage'  'ALL_Voltage'(both below & over voltage)
switch LoadinCase_Info.case_S_type
    case 'OverVoltage'
        case_title='OverVoltageCaseInput';
    case 'ALL_Voltage'
        case_title='ALLCaseInput';
end

%%
switch Case_Name
    case 'IEEE33'
        switch case_type
              case 'Massive'
                %% Massive case (New)  (Generation Function  F:\科研\Koopman_PF_Dispatch\Generate_TestCases.m)
                temp=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\',Case_Name,'\',case_title,'_No',num2str(number),'.mat'));
                Input_Standard=temp.Input_Standard;
        end
end
end

