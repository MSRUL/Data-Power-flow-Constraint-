function [Record] = Adj_OverVoltage_Trand_Sensi(Sensi_M,INclude_PV_S,casename_NR,results_NR,INclude_PV_node,Input_Standard,Pos_In_OutPut,Over_Voltage,TransTab_step,adjust_Q_step,adjust_P_step,Voltage)
%UNTITLED4 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%------- Output of PV Inverter & PQ Load (In IEEE 33 Only PQ type of Bus is Considered)------------------------
PV_out_P=Input_Standard(Pos_In_OutPut.Pos_P_in_Inventer,:);
PV_out_Q=Input_Standard(Pos_In_OutPut.Pos_Q_in_Inventer,:);
P_Load=Input_Standard(Pos_In_OutPut.Pos_P_Load);
Q_Load=Input_Standard(Pos_In_OutPut.Pos_Q_Load);

[ref,pv, pq] = bustypes(casename_NR.bus, casename_NR.gen);
%------------------Step controled-------------------
adjust_P_step=adjust_P_step/100;%0;
adjust_Q_step=adjust_Q_step/100;%0;

Base_Input=[0;P_Load;0;Q_Load]; % the 0 is the reference bus power injection
Adj_Input=[PV_out_P,PV_out_Q];
% Adj_Input=Adj_Input/casename_NR.baseMVA;

casename_NR_controled=casename_NR;

Pos_Q_of_PV=size(casename_NR.bus,1)+INclude_PV_node;  %Position of Q output in PV
Pos_P_of_PV=size(casename_NR.bus,1)+INclude_PV_node;  %Position of Q output in PV
%-----------------------------------------
temp_adj=zeros(size(casename_NR.bus,1)*2,1);
temp_adj(INclude_PV_node,1)=temp_adj(INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),1);
temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)=temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),2);
INPUT_Record=Base_Input-temp_adj;
Control_Record=Adj_Input;
OUTPUT_Record=results_NR.bus(:,8);


Adj_Q=1; % Weather to adjust the Q of PV
Adj_P=0; % Weather to adjust the P of PV
numof_PV_inventor=[1,1,1]; %Init the max sensitive index 
S1_Rank=Sensi_M;
while(length(Over_Voltage)>0) 
    
    for i=1:length(Over_Voltage)
        Over_Voltage(i);
        Over_Voltage(i);
        if Adj_Q
            [numof_PV_inventor]=find(  abs(S1_Rank(Over_Voltage(i),Pos_Q_of_PV))==max(abs(S1_Rank(Over_Voltage(i),Pos_Q_of_PV))) );  %寻找无功功率调节灵敏度最高的�?
        end
        if length(numof_PV_inventor)>1  %无法找到灵敏度最大的点，表明此时系统中已经没有光伏的无功功率可以参与调节了�??
            stophere=1;
            %                 if Adj_Input(Pos_TransTab,1)+TransTab_step.step<=TransTab_step.max %判断分接头是否还有调节的余地
            %                     Adj_Input(Pos_TransTab,1)=Adj_Input(Pos_TransTab,1)+TransTab_step.step; %向下调节�?个步长的分接�?
            %                     Adj_Input(1:Pos_TransTab-1,1)=Input_Standard(1:Pos_TransTab-1,1); % 调节完分接头后，将重置所有其他的输入变量
            %                     M_V_Rank=Senstive_M;
            %                     break
            %                 else
            %                     Adj_P=1; %�?要进行有功功率调�?
            %                     Adj_Q=0;
            %                     break
            %                 end
        end
        %         if max(abs(M_V_Rank(Below_Voltage(i),size(pq,1)+1:size(pq,1)*2)))>abs(M_V_Rank(Below_Voltage(i),size(pq,1)*2+2))  %是否�?要调节电容器   %这里暂时不�?�虑成本，只从�?�辑顺序上调�?
        %             Adj_CB=0;
        %         else
        %             Adj_CB=1;
        %             temp_pos_q=size(pq,1)+2;
        %         end
        
        if ~Adj_P
            if S1_Rank(Over_Voltage(i),size(casename_NR.bus,1)+INclude_PV_node(numof_PV_inventor))>=0  %判断�?大影响点是正还是�?,作为正负系数加入调节量中
                B_direction=-1;
            else
                B_direction=1;
            end
            %                 B_direction=-1;
            PV_Q_Limit_Rate=0.5;
            if (Adj_Input(numof_PV_inventor,1)^2+Adj_Input(numof_PV_inventor,2)^2)<INclude_PV_S(numof_PV_inventor)^2 && abs(Adj_Input(numof_PV_inventor,2))<INclude_PV_S(numof_PV_inventor)*PV_Q_Limit_Rate
                Adj_Input(numof_PV_inventor,2)=Adj_Input(numof_PV_inventor,2)+B_direction*adjust_Q_step;
                % abs(M_V_Rank(Over_Voltage(i),Pos_PV_Q_Inventer_Start+numof_PV_inventor))/max(max(abs(M_V_Rank(Over_Voltage,Pos_Q_in_Input))));
            else
                S1_Rank(:,size(casename_NR.bus,1)+INclude_PV_node(numof_PV_inventor))=0;
                'The ith PV inverter total output power Limit has been meet'
            end
        end
    end
    temp_adj=zeros(size(casename_NR.bus,1)*2,1);
    temp_adj(INclude_PV_node,1)=temp_adj(INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),1);
    temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)=temp_adj(size(casename_NR.bus,1)+INclude_PV_node,1)+Adj_Input(1:size(INclude_PV_node,2),2);
    temp_controled_input=Base_Input-temp_adj;
    casename_NR_controled.bus(:,[3,4])=[temp_controled_input(1:size(casename_NR.bus,1),1),temp_controled_input(1+size(casename_NR.bus,1):2*size(casename_NR.bus,1),1)];
    result_controled_temp=runpf(casename_NR_controled);
    result_controled=result_controled_temp.bus(:,8);

%     hold on;plot(result_controled); Weather to draw the Voltage figure(The Change Process)
    OUTPUT_Record=[OUTPUT_Record,result_controled];
    INPUT_Record=[INPUT_Record,[casename_NR_controled.bus(:,3);casename_NR_controled.bus(:,4)]];
    Control_Record=[Control_Record,Adj_Input];
    Record.OUTPUT_Record=OUTPUT_Record;
    Record.INPUT_Record=INPUT_Record;
    Record.Control_Record=Control_Record;
    Record.PLoss_Record=[sum(results_NR.branch(:,14)+results_NR.branch(:,16));sum(result_controled_temp.branch(:,14)+result_controled_temp.branch(:,16))];
    Over_Voltage=find(result_controled>Voltage.max);
    
    %%
    
    
end
    temp_adj_node=find((Record.INPUT_Record(:,end)-Record.INPUT_Record(:,1))~=0);
    temp_adj_power=Record.INPUT_Record(temp_adj_node,end)-Record.INPUT_Record(temp_adj_node,1);
    temp_adj_node=temp_adj_node-size(results_NR.bus,1);
    fprintf('Adjust PV Node:');
    for i=1:length(temp_adj_node)
        fprintf(' %d ,',temp_adj_node(i,1));
    end
    fprintf('\nAdjust PV Reactive Power:');
    for i=1:length(temp_adj_node)
        fprintf(' %f ',temp_adj_power(i,1));fprintf('kVar ,');
    end
end

