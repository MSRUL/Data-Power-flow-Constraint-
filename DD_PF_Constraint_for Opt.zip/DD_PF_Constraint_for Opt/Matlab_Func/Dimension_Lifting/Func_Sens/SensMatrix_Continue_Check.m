function [Record] = SensMatrix_Continue_Check(Input_Standard,rbf_type,cent_input_compelete,M_Vm,InputCheck,OutputCheck,Input1)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明

temp=min(Input1(InputCheck,:)):...
    (max(Input1(InputCheck,:))-min(Input1(InputCheck,:)))/size(Input1,2)*10:...
    max(Input1(InputCheck,:));
Record=zeros(size(temp));
for i=1:length(temp)
    Input_Standard(InputCheck)=temp(i);
    [Senstive_M] = Koopman_Senstive_Matric(Input_Standard,rbf_type,cent_input_compelete,M_Vm);
    Record(i)=Senstive_M(OutputCheck,InputCheck);
end


end

