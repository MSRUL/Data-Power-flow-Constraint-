function [Data] = Data_Column_vector_standardization(inputData,standard_way)
% Data_Column_vector_standardization   Use with [fuction]: Data_Column_vector_standardization
% ZYX_20200301

Data.standard_way=standard_way;
switch standard_way
    case 'meanvalue'
        Data.Mean=mean(inputData')';
        Data.Standarded=inputData;
        for i =size(inputData,2)
            Data.Standarded(:,i)=Data.Standarded(:,i)./Data.Mean;
        end
    case '0-1lize'
        Data.Min=min(inputData')';
        Data.Max=max(inputData')';
        for i =size(inputData,2)
            Data.Standarded(:,i)=(Data.Standarded(:,i)-Data_Min)./(Data.Max-Data.Min);
        end
end
end