function [progeny_Matric,progeny_Matric_ALL] = Search_Praents_Node(Y1,ref)
%Search_Praents_Node Find the relationship with node connection
% ͨ���ڵ㵼�ɾ��󣬼���õ�
%д�ĺ�һ�㣬ֻ����ʵ�ֹ��ܡ�������ӽڵ���󣬺����Ǹ������������Ӵ�
connection=zeros(size(Y1));
for i=1:size(Y1,1)
    for j=1:size(Y1,2)
        if Y1(i,j)~=0&&i~=j
            connection(i,j)=1;
        end
    end
end
all_ready_searched=[];
all_ready_searched=[all_ready_searched,ref];
progeny_Matric=zeros(size(connection)); %line:parent    column:progeny

node_find=find(connection(ref,:)~=0);
progeny_Matric(ref,node_find)=1;
Newfind=node_find;
all_ready_searched=[all_ready_searched,node_find];
while ~isempty(Newfind) %size(all_ready_searched,2)<size(Y1,1)
    node_find=Newfind;
    Newfind=[];
    for i=1:length(node_find)
        temp_node_find=find(connection(node_find(1,i),:)~=0);
        for j=1:length(temp_node_find)
            if ~ismember(temp_node_find(1,j),all_ready_searched)
                all_ready_searched=[all_ready_searched,temp_node_find(1,j)];
                Newfind=[Newfind,temp_node_find(1,j)];
                progeny_Matric(node_find(1,i),temp_node_find(1,j))=1;
            end
        end
    end
end

%% progeny_Matric_ALL, where contains all the downstream bus.
progeny_Matric_ALL=zeros(size(progeny_Matric));

for i=1:size(progeny_Matric_ALL,1)
    temp_bus=[];

    temp_progeny_node=find(progeny_Matric(i,:)==1);
    temp_bus=[temp_bus;temp_progeny_node'];

    Newfind=temp_progeny_node;
    while ~isempty(Newfind)
        node_find=Newfind;
        Newfind=[];
        for i_temp=1:length(node_find)
            temp_node_find=find(progeny_Matric(node_find(1,i_temp),:)~=0);
            for j=1:length(temp_node_find)
                    temp_bus=[temp_bus;temp_node_find(1,j)];
                    Newfind=[Newfind,temp_node_find(1,j)];

            end
        end
    end
    progeny_Matric_ALL(i,temp_bus)=1;

end


end

