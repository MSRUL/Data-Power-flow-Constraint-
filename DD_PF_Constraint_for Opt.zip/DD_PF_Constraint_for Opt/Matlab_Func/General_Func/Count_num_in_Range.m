function [Count_Num] = Count_num_in_Range(Inputdata,Range)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
Count_Num=zeros(size(Range));
for i=2:length(Range)
    temppos=find(Inputdata<Range(i));
    temp_In=Inputdata(temppos);
    temppos=find(temp_In>=Range(i-1));
    num=length(temppos);
    Count_Num(1,i-1)=num;
end
end

