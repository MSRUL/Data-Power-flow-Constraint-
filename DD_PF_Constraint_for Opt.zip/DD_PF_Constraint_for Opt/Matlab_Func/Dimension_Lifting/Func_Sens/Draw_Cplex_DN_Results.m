function [] = Draw_Cplex_DN_Results(PowerflowWay,casename_NR,Input_Standard,Input_temp,Pos_In_OutPut,Result_CPLEX,results_NR,results_NRCheck)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
[ref,pv, pq] = bustypes(casename_NR.bus, casename_NR.gen);
line_active=find(casename_NR.branch(:,11)==1);
switch PowerflowWay
    case 'Distflow'
        figure;
        Rows=6;
        colnum=1;
        pos_temp=1;
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.v_m/casename_NR.bus(1,10));hold on;
        plot(results_NR.bus(:,8));
        plot(results_NRCheck.bus(:,8));
        legend('Distflow Optimazition','Original Value','NR Check');title('Photovoltaic Active Power');title('Bus Vlotage');
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.i_m);hold on;
        i_line_OR=(results_NR.branch(line_active,14).^2+results_NR.branch(line_active,15).^2)./(results_NR.bus(results_NR.branch(line_active,1),8)*casename_NR.bus(ref,10)/1000).^2;
        plot(sqrt(i_line_OR));
        i_line_OR=(results_NRCheck.branch(line_active,14).^2+results_NRCheck.branch(line_active,15).^2)./(results_NRCheck.bus(results_NRCheck.branch(line_active,1),8)*casename_NR.bus(ref,10)/1000).^2;
        plot(sqrt(i_line_OR));
        legend('Distflow Optimazition','Original Value','NR Check');title('Photovoltaic Active Power');title('Branch Current')
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.Pline);hold on;
        plot(results_NR.branch(line_active,14));
        plot(results_NRCheck.branch(line_active,14));
        legend('Distflow Optimazition','Original Value','NR Check');title('Photovoltaic Active Power');title('Branch Active Power Flow')
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.Qline);hold on;
        plot(results_NR.branch(line_active,15));
        plot(results_NRCheck.branch(line_active,15));
        legend('Distflow Optimazition','Original Value','NR Check');title('Photovoltaic Active Power');title('Branch Reactive Power Flow')
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.PV_P);hold on;
        plot(Input_Standard(Pos_In_OutPut.Pos_P_in_Inventer,:));
        plot(Input_temp(Pos_In_OutPut.Pos_P_in_Inventer,:));
        legend('Distflow Optimazition','Original Value','NR Check');title('Photovoltaic Active Power');title(' Photovoltaic Active Power')
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.PV_Q);hold on;
        plot(Input_Standard(Pos_In_OutPut.Pos_Q_in_Inventer,:));
        plot(Input_temp(Pos_In_OutPut.Pos_Q_in_Inventer,:));
        legend('Distflow Optimazition','Original Value','NR Check');title('Photovoltaic Active Power');    title(' Photovoltaic Reactive Power')

        set(gcf,'unit','centimeters','position',[1,1,14,35]);
        
        fprintf('Original Power Loss: %f MW\n',sum(abs(results_NR.branch(line_active,14)+results_NR.branch(line_active,16))));
        fprintf('Optimization Power Loss: %f MW\n',Result_CPLEX.objective);
        fprintf('Optimization Power Loss(NR Check): %f MW\n',sum(abs(results_NR.branch(line_active,14)+results_NR.branch(line_active,16))));
        
    case 'DLPF'
        figure;
        Rows=5;
        colnum=1;
        pos_temp=1;
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.Voltage,'o-');hold on;
        plot(results_NR.bus(:,8),'+-');
        plot(results_NRCheck.bus(:,8),'*-');
        legend('DLPF Optimazition','Original Value','NR Check');title('Bus Vlotage');
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(sqrt(Result_CPLEX.BranchFlow_DLPF_Active.^2+Result_CPLEX.BranchFlow_DLPF_Reactive.^2),'o-');hold on;
        plot(sqrt(results_NR.branch(line_active,14).^2+results_NR.branch(line_active,15).^2),'+-');
        plot(sqrt(results_NRCheck.branch(line_active,14).^2+results_NRCheck.branch(line_active,15).^2),'*-')
        legend('DLPF Optimazition','Original Value','NR Check');title('Branch Power Flow');    
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.BranchFlow_DLPF_Loss,'o-');hold on;
        plot(abs(results_NR.branch(:,14)+results_NR.branch(:,16)),'+-');
        plot(abs(results_NRCheck.branch(:,14)+results_NRCheck.branch(:,16)),'*-');
        legend('DLPF Optimazition','Original Value','NR Check');title('Branch Power Loss');    
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.PV_P,'o-');hold on;
        plot(Input_Standard(Pos_In_OutPut.Pos_P_in_Inventer,:),'+-');
        plot(Input_temp(Pos_In_OutPut.Pos_P_in_Inventer,:),'*-');
        legend('DLPF Optimazition','Original Value','NR Check');title('Photovoltaic Active Power');    
        
        
        subplot(Rows,colnum,pos_temp);pos_temp=pos_temp+1;
        plot(Result_CPLEX.PV_Q,'o-');hold on;
        plot(Input_Standard(Pos_In_OutPut.Pos_Q_in_Inventer,:),'+-');
        plot(Input_temp(Pos_In_OutPut.Pos_Q_in_Inventer,:),'*-');
        legend('DLPF Optimazition','Original Value','NR Check');title('Photovoltaic Reactive Power');    

        set(gcf,'unit','centimeters','position',[1,2,14,30])
end
end

