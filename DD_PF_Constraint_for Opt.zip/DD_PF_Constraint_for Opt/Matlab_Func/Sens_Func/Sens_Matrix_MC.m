function [Sens] = Sens_Matrix_MC(results_NR,Step)
% ZYX 20220420 Calculate the senstive matrix by power flow calculation.
% Add the power injection by step and record the voltage difference
% 20200420 Only the PQ Type Bus
% The Unit of input variable of "Step" is MVA

% Not Support the PV Type Bus
%%
[~, ~, pq] = bustypes(results_NR.bus, results_NR.gen);
%% Init
Sens.P2V=zeros(length(pq),length(pq));
Sens.Q2V=zeros(length(pq),length(pq));
Sens.P2sita=zeros(length(pq),length(pq));
Sens.Q2sita=zeros(length(pq),length(pq));
Sens.P2Ploss=zeros(1,length(pq));
Sens.Q2Ploss=zeros(1,length(pq));
Sens.P2PL=zeros(sum(results_NR.branch(:,11)),length(pq));
Sens.Q2PL=zeros(sum(results_NR.branch(:,11)),length(pq));
Sens.P2QL=zeros(sum(results_NR.branch(:,11)),length(pq));
Sens.Q2QL=zeros(sum(results_NR.branch(:,11)),length(pq));
Sens.P2SL=zeros(sum(results_NR.branch(:,11)),length(pq));
Sens.Q2SL=zeros(sum(results_NR.branch(:,11)),length(pq));

Pos_Active_line=find(results_NR.branch(:,11)==1);
%% Active Power Injection to Voltage
for i=1:length(pq)
    case_name_temp=results_NR;
    case_name_temp.bus(pq(i),3)=case_name_temp.bus(pq(i),3)+Step; % The Unit of input variable of "Step" is MVA
    Results=runpf(case_name_temp);
    Sens.P2V(:,i)=-(Results.bus(pq,8)-results_NR.bus(pq,8))/Step;  % nagtive means the power injection.
    Sens.P2sita(:,i)=-(Results.bus(pq,9)-results_NR.bus(pq,9))/Step;  % nagtive means the power injection.
    Ploss_OR=sum(abs(results_NR.branch(:,14)+results_NR.branch(:,16)));
    Ploss_Adjed=sum(abs(Results.branch(:,14)+Results.branch(:,16)));
    Sens.P2Ploss(:,i)=-(Ploss_Adjed-Ploss_OR)/Step; 
    Sens.P2PL(:,i)=-(Results.branch(Pos_Active_line,14)-results_NR.branch(Pos_Active_line,14))/Step;
    Sens.P2PL(:,i)=-(Results.branch(Pos_Active_line,15)-results_NR.branch(Pos_Active_line,15))/Step;

    SL_OR=sqrt(results_NR.branch(Pos_Active_line,15).*results_NR.branch(Pos_Active_line,15)+results_NR.branch(Pos_Active_line,14).*results_NR.branch(Pos_Active_line,14));
    SL_Adjed=sqrt(Results.branch(Pos_Active_line,15).*Results.branch(Pos_Active_line,15)+Results.branch(Pos_Active_line,14).*Results.branch(Pos_Active_line,14));
    Sens.P2SL(:,i)=-(SL_Adjed-SL_OR)/Step;

end
%% Reactive Power Injection to Voltage
for i=1:length(pq)
    case_name_temp=results_NR;
    case_name_temp.bus(pq(i),4)=case_name_temp.bus(pq(i),4)+Step; % The Unit of input variable of "Step" is MVA
    Results=runpf(case_name_temp);
    Sens.Q2V(:,i)=-(Results.bus(pq,8)-results_NR.bus(pq,8))/Step; % nagtive means the power injection.
    Sens.Q2sita(:,i)=-(Results.bus(pq,9)-results_NR.bus(pq,9))/Step; % nagtive means the power injection.
    Ploss_OR=sum(abs(results_NR.branch(:,14)+results_NR.branch(:,16)));
    Ploss_Adjed=sum(abs(Results.branch(:,14)+Results.branch(:,16)));
    Sens.Q2Ploss(:,i)=-(Ploss_Adjed-Ploss_OR)/Step; 
    Sens.Q2QL(:,i)=-(Results.branch(Pos_Active_line,14)-results_NR.branch(Pos_Active_line,14))/Step;
    Sens.Q2QL(:,i)=-(Results.branch(Pos_Active_line,15)-results_NR.branch(Pos_Active_line,15))/Step;
    
    SL_OR=sqrt(results_NR.branch(Pos_Active_line,15).*results_NR.branch(Pos_Active_line,15)+results_NR.branch(Pos_Active_line,14).*results_NR.branch(Pos_Active_line,14));
    SL_Adjed=sqrt(Results.branch(Pos_Active_line,15).*Results.branch(Pos_Active_line,15)+Results.branch(Pos_Active_line,14).*Results.branch(Pos_Active_line,14));
    Sens.Q2SL(:,i)=-(SL_Adjed-SL_OR)/Step;

end
end