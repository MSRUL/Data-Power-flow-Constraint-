function [Input,Output_NR,Output_DLPF] = Generate_Tranning_OR_Testing_DLPF(input_num,test_input_num,num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,Range,TestItem)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明


%%
input_Cbank=Device_Info.input_Cbank;
Transformer_Tab=Device_Info.Transformer_Tab;
INclude_PV_node_Pos=Device_Info.INclude_PV_node_Pos;
INclude_PV_S=Device_Info.INclude_PV_S;
%%

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;
pos_gen_p=2;
pos_gen_v=6;
Bus_Num=size(case_name.bus,1);
line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
%%
% input_Cbank=temp_range_input_Cbank/1000;
temp_range_input_Cbank_num=length(input_Cbank);
temp_range_input_TransTab_num=length(Transformer_Tab);

%%  Data of KPM DD_PF
Input=zeros(input_num,num_inpuit);
num=num_inpuit;

Input(1:length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_P_M+Tranning_Range.PQ_P_B).*case_name_or_simp.bus(pq,3);
Input(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_Q_M+Tranning_Range.PQ_Q_B).*Input(1:length(pq),:);
for i=1:length(pv)
    Input(2*length(pq)+i,:)=(rand(1,num)*Tranning_Range.PV_P_M+Tranning_Range.PV_P_B)*sum(case_name_or_simp.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
    %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
    Input(2*length(pq)+length(pv)+i,:)=case_name_or_simp.gen( pv_pos(i,1),6)*(rand(1,num)*Tranning_Range.PV_V_M+Tranning_Range.PV_V_B);
end
Input(2*length(pq)+2*length(pv)+1,:)=case_name_or_simp.gen( ref_pos,6)*(rand(1,num)*Tranning_Range.REF_V_M+Tranning_Range.REF_V_B);
temp_C_bank=ceil(rand(1,num)*temp_range_input_Cbank_num);
if Device_Info.input_Cbank_state
    Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state,:)=-input_Cbank(temp_C_bank);
end
if length(INclude_PV_S)>0
    temp_PV_P_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_P_M+Tranning_Range.PhotoVoltake_P_B).*INclude_PV_S';
    temp_S=ones(size(temp_PV_P_Out)).*INclude_PV_S';
    max_temp_PV_Q_Out=sqrt(temp_S.^2-temp_PV_P_Out.^2);
    Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S),:)=temp_PV_P_Out;
    temp_PV_Q_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_Q_M+Tranning_Range.PhotoVoltake_Q_B).*INclude_PV_S';
    temp_PV_Q_Out=min(temp_PV_Q_Out,max_temp_PV_Q_Out); % limit the Inverter Q power to fit the total S limit
    Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2,:)=temp_PV_Q_Out;
end
temp_TransTab=ceil(rand(1,num)*temp_range_input_TransTab_num);
if Device_Info.Transformer_Tab_state
    Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state,:)=Transformer_Tab(temp_TransTab);
end
%%  Data of DLPF
Data_DDLPF.Vm=zeros(Bus_Num,num_inpuit);
%%
% Output=zeros(output_num,num);
SS=[];

for i=1:num
    temp_iptpq_p=Input(1:length(pq),i);
    temp_iptpq_q=Input(length(pq)+1:2*length(pq),i);
    if length(INclude_PV_node_Pos)>0
        temp_iptpq_p(INclude_PV_node_Pos)=temp_iptpq_p(INclude_PV_node_Pos)-Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S),i);
        temp_iptpq_q(INclude_PV_node_Pos)=temp_iptpq_q(INclude_PV_node_Pos)-Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2,i);
    end
    temp_iptpv_p=Input(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input(2*length(pq)+length(pv)+1:2*length(pq)+2*length(pv),i);
    temp_iptref_v=Input(2*length(pq)+2*length(pv)+1,i);
    
    
    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,6)=temp_iptref_v;
    
    
    if Device_Info.input_Cbank_state
        temp_C_bank=Input(2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state,i);
    case_name.bus(ref,4)=temp_C_bank;
    end
    if Device_Info.Transformer_Tab_state
        temp_TranTab=Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state,i);
        case_name.branch(1,9)=temp_TranTab;
    end
%%
[result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    [Results_DLPF]=DLPF(case_name);
    %%
    output1_NR=result.bus(pq,8);
    output2_NR=result.branch(line_active,14);
    output3_NR=result.branch(line_active,15);
    output4_NR=result.bus(pq,9);
    output5_NR=result.bus(pv,9);
    output_PLOSS_NR=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));
    
    output_Vol_DLPF=Results_DLPF.busVol(pq,:);
    output_Ang_DLPF=Results_DLPF.busAgl;
    output_PL_DLPF=Results_DLPF.BranchFlow_PL;
    output_QL_DLPF=Results_DLPF.BranchFlow_QL;
    output_PLOSS_DLPF=Results_DLPF.BranchFlow_NR_Loss1;
    %%
    output_NR=[];
    output_DLPF=[];
  
    if TestItem.PQ_Vm
        output_NR=[output_NR;output1_NR];
        output_DLPF=[output_DLPF;output_Vol_DLPF];
    end
    if TestItem.Va
        output_NR=[output_NR;output4_NR;output5_NR];
        output_DLPF=[output_DLPF;output_Ang_DLPF];
    end
    if TestItem.LP
        output_NR=[output_NR;output2_NR];
        output_DLPF=[output_DLPF;output_PL_DLPF];
    end
    if TestItem.LQ
        output_NR=[output_NR;output3_NR];
        output_DLPF=[output_DLPF;output_QL_DLPF];
    end
    if TestItem.PLoss
        output_NR=[output_NR;output_PLOSS_NR];
        output_DLPF=[output_DLPF;output_PLOSS_DLPF];
    end

    Output_NR(:,i)=output_NR;
    Output_DLPF(:,i)=output_DLPF;
end
%% Only keep the results of power flow convergence
Input=Input(1:test_input_num,SS);
Output_NR=Output_NR(:,SS);
Output_DLPF=Output_DLPF(:,SS);

end

