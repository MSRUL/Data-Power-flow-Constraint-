function [Data_Result1,Data_Result2] = Show_Test_situation(OPT_kpm,OPT_PF,SCU,case_name,time,type,test_index)
%UNTITLED4 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    [ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
    if type==1
        Data_Result_NRPF=OPT_PF(SCU,1:length(pq));
        Data_Result_KPMPF=OPT_kpm(SCU,1:length(pq));
    end
    if type==2
        Data_Result_NRPF=OPT_PF(SCU,length(pq)+1:length(pq)+length(case_name.branch));
        Data_Result_KPMPF=OPT_kpm(SCU,length(pq)+1:length(pq)+length(case_name.branch));
    end
    if type==3
        Data_Result_NRPF=OPT_PF(SCU,length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
        Data_Result_KPMPF=OPT_kpm(SCU,length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    end
    if type==4
        Data_Result_NRPF=OPT_PF(SCU,length(pq)+2*length(case_name.branch)+1:2*length(pq)+2*length(case_name.branch));
        Data_Result_KPMPF=OPT_kpm(SCU,length(pq)+2*length(case_name.branch)+1:2*length(pq)+2*length(case_name.branch));
    end
    if type==5
        Data_Result_NRPF=OPT_PF(SCU,2*length(pq)+2*length(case_name.branch)+1:length(pv)+2*length(pq)+2*length(case_name.branch));
        Data_Result_KPMPF=OPT_kpm(SCU,2*length(pq)+2*length(case_name.branch)+1:length(pv)+2*length(pq)+2*length(case_name.branch));
    end
    Data_Result1=Data_Result_NRPF(time,test_index);
    Data_Result2=Data_Result_KPMPF(time,test_index);
    
end

