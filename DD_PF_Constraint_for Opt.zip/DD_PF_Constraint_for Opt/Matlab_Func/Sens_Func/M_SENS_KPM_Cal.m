function [M_Sens_KPM] = M_SENS_KPM_Cal(M_Compelet,Input_test,Peremeters)
%UNTITLED2 Calculate the senstive matrix

M_Sens_KPM=zeros(size(M_Compelet,1),size(Input_test,1),size(Input_test,2));

Input_test=[Input_test;ones(1,size(Input_test,2))]; %Input Row with a constant row

for test_time_ID=1:size(Input_test,2)

    
    Test_temp=zeros(size(Input_test,1),size(Input_test,1)-1);
    for i =1:(size(Input_test,1)-1)
        Test_temp(:,i)=Input_test(:,test_time_ID);
    end
    %% KMP calculated results
    switch   Peremeters.Way %'Direction'  'Delta'
        case 'Direction'
            temp_direction=zeros(size(Input_test,1)-1,size(Input_test,1)-1);
            for i=1:size(temp_direction,1)
                temp_direction(i,i)=Peremeters.Direc_length;
            end
            Test_input_temp=[Test_temp;temp_direction];
        case 'Delta'
            temp_difference=zeros(size(Input_test,1)-1,size(Input_test,1)-1);
            for i=1:size(temp_difference,1)
                temp_difference(i,i)=Peremeters.Diff_input;
            end
            Test_input_temp=[Test_temp;temp_difference];
    end
    Lifted_Output_Test_Compelet = Lift_Vector_Complete(Test_input_temp,Peremeters.rbf_type,Peremeters.cent_input_compelete);
    temp11=M_Compelet*Lifted_Output_Test_Compelet;
    if strcmp(Peremeters.Way,'Delta')
        temp11=temp11/Peremeters.Diff_input;
    end
    M_Sens_KPM(:,:,test_time_ID)=temp11;  % The last one is the constant bus
    
end


end