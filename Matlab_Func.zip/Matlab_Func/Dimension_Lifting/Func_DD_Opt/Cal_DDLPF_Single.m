function [Vm_temp] = Cal_DDLPF_Single(M_DDLPF,Input_temp,Device_Info,Pos_In_OutPut)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
%% Case Info

baseMVA=Pos_In_OutPut.baseMVA;
pq=Pos_In_OutPut.pq;
pv=Pos_In_OutPut.pv;
ref=Pos_In_OutPut.ref;
Bus_Num=Pos_In_OutPut.Bus_Num;
%%
P_Load=[0;Input_temp(Pos_In_OutPut.Pos_P_Load)];% The first 0 is Power injection of Ref Bus
Q_Load=[0;Input_temp(Pos_In_OutPut.Pos_Q_Load)];
PV_P=Input_temp(Pos_In_OutPut.Pos_P_in_Inventer);
PV_Q=Input_temp(Pos_In_OutPut.Pos_Q_in_Inventer);
Vm_ref=Input_temp(Pos_In_OutPut.Pos_RefBus );

%% DDLPF Parameters
X_Line=[M_DDLPF.XPL(:,1:2*Bus_Num);M_DDLPF.XQL(:,1:2*Bus_Num)];
C_Line = [M_DDLPF.XPL(:,2*Bus_Num + 1);M_DDLPF.XQL(:,2*Bus_Num + 1)];

X11 = [M_DDLPF.XVa([pq; pv; ref], [pq; pv; ref; pq + Bus_Num]);...
    M_DDLPF.XVm(pq, [pq; pv; ref; pq + Bus_Num])]; %Already Known injection power Parts
X12 = [M_DDLPF.XVa([pq; pv; ref], [pv; ref] + Bus_Num);...
    M_DDLPF.XVm(pq, [pv; ref] + Bus_Num)];% The Reactive Bus of PV ,Ref bus Parts
X21 = M_DDLPF.XVm([pv; ref], [pq; pv; ref; pq + Bus_Num]);
X22 = M_DDLPF.XVm([pv; ref], [pv; ref] + Bus_Num);
C1 = [M_DDLPF.XVa([pq; pv; ref],2*Bus_Num + 1);M_DDLPF.XVm(pq,2*Bus_Num + 1)];
C2 = M_DDLPF.XVm([pv; ref],2*Bus_Num + 1);
%%
% Y2=case_name.bus([pv; ref],8)';
Y2=Vm_ref;
P_Injection=zeros(Bus_Num,1);
Q_Injection=zeros(Bus_Num,1);
for i=1:Bus_Num
    if ismember(i,Device_Info.INclude_PV_node)
        pos_PV_num=find(Device_Info.INclude_PV_node==i);
        P_Injection(i,1)=-P_Load(i,1)/baseMVA+PV_P(pos_PV_num,1)/baseMVA;
        Q_Injection(i,1)=-Q_Load(i,1)/baseMVA+PV_Q(pos_PV_num,1)/baseMVA;
    else
        P_Injection(i,1)=-P_Load(i,1)/baseMVA;
        Q_Injection(i,1)=-Q_Load(i,1)/baseMVA;
    end
end
a1=[P_Injection([pq; pv; ref],1);Q_Injection(pq,1)];%The Already Known injection power
a2 = X22 \ (Y2 - X21 * a1 - C2);% Calculate the Reactive Bus of PV ,Ref bus.
Y1 = X11 * a1 + X12 * a2 + C1;

Vm_temp = zeros(Bus_Num, 1);
% Vm_temp([pv; ref]) = Vm(i, [pv; ref]);
Vm_temp(ref) = Vm_ref;
Vm_temp(pq) = Y1(Bus_Num + 1: Bus_Num + length(pq));


end

