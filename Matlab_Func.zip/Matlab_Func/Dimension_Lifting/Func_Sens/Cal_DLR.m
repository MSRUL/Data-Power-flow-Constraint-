function [Output] = Cal_DLR(Input,M,DLR_Parameter)
% ZYX 20220415
%   
Input_lifted=Lift_Vector_Complete_Total(Input,DLR_Parameter);
Output=M*Input_lifted;
end