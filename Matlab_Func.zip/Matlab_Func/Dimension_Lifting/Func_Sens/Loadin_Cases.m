function [Input_Standard] = Loadin_Cases(path_last,LoadinCase_Info)
%%   case_type='Massive';  %'Single'  'Massive'
% case_chose='case116';   %'case116'  'case109' % Different DG and Load Power;
% Generate Data Function: 'J:\科研\Koopman_PF_Dispatch\Generate_TestCases.m'
%%

Case_Name=LoadinCase_Info.Case_Name;
case_type=LoadinCase_Info.case_type;
case_chose=LoadinCase_Info.case_chose;
number=LoadinCase_Info.number;

% LoadinCase_Info.case_type='ALL_Voltage';  %  'OverVoltage'  'ALL_Voltage'(both below & over voltage)
switch LoadinCase_Info.case_S_type
    case 'OverVoltage'
        case_title='OverVoltageCaseInput';
    case 'ALL_Voltage'
        case_title='ALLCaseInput';
end

%%
switch Case_Name
    case 'IEEE33'
        switch case_type
            case 'Single'
                %% Single Standerd case
                switch case_chose
                    case 'case116'
                        temp_load_data=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\Saved_Test_Case_116.mat'));%Case ID is 116
                    case 'case109'
                        temp_load_data=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\Saved_Test_Case_109.mat'));%Case ID is 109
                end
                Input_Standard=temp_load_data.Saved_Test_Case.Input_Standard(1:Device_Info.Standard_Num,1);
                Input_Standard(Pos_In_OutPut.Pos_PV_P_Inventer_Start+find(Input_Standard(Pos_In_OutPut.Pos_P_in_Inventer,1)<=0),1)=0;
            case 'Massive'
                %% Massive case (New)  (Generation Function  F:\科研\Koopman_PF_Dispatch\Generate_TestCases.m)
                temp=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\',Case_Name,'\',case_title,'_No',num2str(number),'.mat'));
                Input_Standard=temp.Input_Standard;
        end
    case 'IEEE69'
        switch case_type
            case 'Single'
                switch case_chose
                    case 'case116' % The Default Case ID is 116
                        temp_load_data=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\Saved_Test_Case69_ID116.mat'));
                    case 'case109'
                        ;
                end
                Input_Standard=temp_load_data.Input_Standard;
            case 'Massive'
                %% Massive case (New)
                temp=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\',Case_Name,'\',case_title,'_No',num2str(number),'.mat'));
                Input_Standard=temp.Input_Standard;
        end
    case 'IEEE141'
        switch case_type
            case 'Massive'
                %% Massive case (New)
                temp=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\',Case_Name,'\',case_title,'_No',num2str(number),'.mat'));
                Input_Standard=temp.Input_Standard;
        end
    case 'IEEE85'
        switch case_type
            case 'Massive'
                %% Massive case (New)
                temp=load(strcat(path_last,'Koopman_PF_Dispatch\存储数据\主函数输入数据\',Case_Name,'\',case_title,'_No',num2str(number),'.mat'));
                Input_Standard=temp.Input_Standard;
        end
end
end

