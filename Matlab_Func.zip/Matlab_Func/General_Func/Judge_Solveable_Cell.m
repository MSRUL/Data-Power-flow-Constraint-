function [OK_Final] = Judge_Solveable_Cell(Opt_Info)
%UNTITLED 此处提供此函数的摘要
%   此处提供详细说明

outputArg1=zeros(size(Opt_Info));

for j=1:size(Opt_Info,2)
    for i=1:size(Opt_Info,1)
        temp=char(Opt_Info(i,j));
        if length(temp)>=20
        if strcmp(temp(1:20),'Successfully solved ')
            outputArg1(i,j)=1;
        end
        end
    end
end
%%
OK_Final_temp=zeros(size(Opt_Info,1),1);
for i=1:size(Opt_Info,1)
    temp_a=1;
    for j=1:size(Opt_Info,2)
        temp_a=temp_a*outputArg1(i,j);
    end
    if temp_a

        OK_Final_temp(i,1)=1;
    end
end
%%
OK_Final=find(OK_Final_temp~=0);
end