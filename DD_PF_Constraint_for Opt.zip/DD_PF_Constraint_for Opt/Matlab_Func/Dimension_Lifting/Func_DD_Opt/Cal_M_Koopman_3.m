function [M,M_Struct] = Cal_M_Koopman_3(inputData,OutputData,rbf_type,Cent,RisePos)
%Cal_M_Koopman_3 Use the Koopman to Tranning the M Matrix. (In this Part , The Dimension of Control Variable is not Lifted)
% Different from Cal_M_Koopman_2, the senstive of control variable is the function of others.
%%
Un_RisePos=Find_Wihtout_Which([1:size(inputData,1)],RisePos);
%%
[XM,XP] = Lift_Vector_Incomplete_2(inputData,rbf_type,Cent,RisePos);
%% LS最小二乘法
% %______TRaining________________________________
Using_M=1;  
if Using_M==1 %Use the Traditional Least Squares Method to Calculate the Matrix M
    W = XM*XM';
    V = OutputData*XM';
    M = V*pinv(W);
else %Use the Direct Calculate the Matrix M
    M=OutputData*pinv(XM);
end

M_Struct.MS=M(:,1:size(XP,1));
M_Struct.M1=M(:,1+size(XP,1):end);

% % ______TEST________________________________
Output_test=zeros(size(OutputData));
for test_ID=1:size(inputData,2)
    XS_temp = Lift_Vector_InComplete_with_Direction(inputData(:,test_ID),rbf_type,Cent.Part1,RisePos);
    Output_test(:,test_ID)=M_Struct.MS*XS_temp*inputData(Un_RisePos,test_ID)+M_Struct.M1*Lift_Dem_Fun_Tradi(inputData(RisePos,test_ID),rbf_type,Cent.Part2); 
end
fprintf('\n【LS Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(OutputData-Output_test))),max(max(abs(OutputData-Output_test))));



% PLS 偏最小二乘估计方法【'主要用于解决数据共线性后引起的矩阵近奇异问题，对于提高回归精度的效果有限'】
% %______TRaining________________________________
% num_PLS=50;
% [~,~,~,~,beta_PLS,PCTVAR] = plsregress(XM',OutputData',num_PLS);
% max(cumsum(100*PCTVAR(2,:)))
% %______TEST________________________________
% yfit = [ones(size(XM',1),1) XM']*beta_PLS;
% Y_PLS=yfit';
% fprintf('\n【PLS Parameter Info】num_PLS： %d  .',num_PLS);
% fprintf('\n【PLS Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Y_PLS-OutputData))),max(max(abs(Y_PLS-OutputData))));


%% SVR 支持向量机回归【'主要用于解决部分节点量测数据存在较大偏差的问题'】
% %______TRaining________________________________
% kernel_type='g';  %'g':%gaussian Kernel  'l':linear Kernel  'p':poly3 Kernel
% maxItr=10;
% Alpha_SVR=SVR_Rge_Mul(XM',OutputData',kernel_type,maxItr);
% %______TEST________________________________
% F_o = SVR_Predic(inputData',Alpha_SVR,kernel_type);
% Y_SVR=F_o';
% fprintf('\n【SVR Parameter Info】kernel_type： %s  ，maxItr： %d  .',kernel_type,maxItr);
% fprintf('\n【SVR Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Y_SVR-OutputData))),max(max(abs(Y_SVR-OutputData))));


end



