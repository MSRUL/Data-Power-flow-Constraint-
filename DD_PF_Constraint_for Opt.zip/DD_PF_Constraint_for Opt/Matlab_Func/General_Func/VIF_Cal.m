function [VIF] = VIF_Cal(Input_Test)
% variance inflation factor 方差扩大因子
% ZYX 20220913

% 当0~5时，没有复共线性；
% 当5~10时，有较弱的复共线性；
% 当10~100时，有中等或较强的复共线性；
% 当时，有严重的复共线性。由于(称为容忍值)，所以也可以用来诊断复共线性。
[R]=corrcoef(Input_Test');
R_det=det(R);
i_all=1:size(R,1);
Rou=zeros(size(R,1),1); %Multiple Correlation Coefficient
for i=1:size(R,1)
    [~,~,A_mins_B,~] = Logic_cal_2Vector(i_all',i);
    R_temp=corrcoef(Input_Test(A_mins_B,:)');
    Rou(i,1)=sqrt(1-R_det/det(R_temp));
end
% max(Rou)

VIF_all=ones(size(R,1),1)./(ones(size(R,1),1)-Rou.^2);
VIF=max(VIF_all);
end