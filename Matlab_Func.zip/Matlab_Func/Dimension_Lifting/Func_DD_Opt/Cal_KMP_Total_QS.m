function [M,M_Struct,M_Output,beta_PLS,M_Ridge] = Cal_KMP_Total_QS(Data,IDL_Peremeters,Train_Ops)
%UNTITLED 此处提供此函数的摘要
%   此处提供详细说明
Input=Data.Input;
Output=Data.Output;



rbf_type=IDL_Peremeters.rbf_type;
RisePos=IDL_Peremeters.RisePos;
Un_RisePos=Find_Wihtout_Which([1:size(Input,1)],RisePos);
IDL_Peremeters.type;

%%
num_data=size(Data.Input,2);
Data_Lag.Input_Delta=Data.Input(:,[2:num_data,1])-Data.Input;
Data_Lag.Output_Delta=Data.Output(:,[2:num_data,1])-Data.Output;
Data_Lag.Input_LagMid=(Data.Input(:,[2:num_data,1])+Data.Input)/2;
%%

[Lifted_Vector] = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
Lifted_Vector.XP;
Lifted_Vector.Input_Lifted;
 fprintf('\n【REGRESSION】start');
%%
switch Train_Ops.way
    case 'LS_OR' % Classical Least Squares
        
        if Train_Ops.M_Type
            W = Lifted_Vector.Input_Lifted*Lifted_Vector.Input_Lifted';
            V = Output*Lifted_Vector.Input_Lifted';
            M1 = V*pinv(W);
        else
            M1 = Output*pinv(Lifted_Vector.Input_Lifted);
        end
        y_test=M1*Lifted_Vector.Input_Lifted;
        Error_temp.mean=mean(mean(abs(y_test-Output)));
        Error_temp.max=max(max(abs(y_test-Output)));
        fprintf('\n【LS Error】Average Error： %f  ，Maximum Error： %f  .',Error_temp.mean,Error_temp.max);

        %%
        X_Lag_New=zeros(size(M1,2),num_data);
        for i =1:num_data
            A_Transf=[ones(length(Un_RisePos),1);Data_Lag.Input_LagMid(Un_RisePos,i);ones(length(RisePos)+size(IDL_Peremeters.cent,2),1);];
            A_Transf=A_Transf*ones(1,size(Data.Input,1));
            A_Transf=A_Transf*Data_Lag.Input_Delta(:,i);
            X_Lag_New(:,i)=A_Transf;
        end
        if Train_Ops.M_Type
            W_lag = X_Lag_New*X_Lag_New';
            V_lag = Data_Lag.Output_Delta*X_Lag_New';
            M_lag = V_lag*pinv(W_lag);
        else
            M_lag = Data_Lag.Output_Delta*pinv(X_Lag_New);
        end
%         Err=[];
%         for i=1:1000
%             bb=i/1000;
%             M=M1+bb*M_lag;
% 
%             y_test=M*Lifted_Vector.Input_Lifted;
%             Error_temp.mean=mean(mean(abs(y_test-Output)));
%             Error_temp.max=max(max(abs(y_test-Output)));
%             fprintf('\n【LS Error】Average Error： %f  ，Maximum Error： %f  .',Error_temp.mean,Error_temp.max);
%             Err=[Err;[Error_temp.mean,Error_temp.max]];
%         end
        M=M1+Train_Ops.Beita*M_lag;
end
Error_temp.mean=mean(mean(abs(y_test-Output)));
Error_temp.max=max(max(abs(y_test-Output)));


%%
M_Struct.MS=M(:,1:size(Lifted_Vector.XP,1));
M_Struct.M1=M(:,1+size(Lifted_Vector.XP,1):end);

M_Output.M_Incompelet=M;
M_Output.M_Struct=M_Struct;


[Output_test] = Case_PF_Accuracy_Test(IDL_Peremeters,M,M_Struct,Data.Input);
fprintf('\n【LS Error with SM】Average Error： %f  ，Maximum Error： %f  .', ...
    mean(mean(abs(Output-Output_test))),max(max(abs(Output-Output_test))));


%%
% % PLS 偏最小二乘估计方法【'主要用于解决数据共线性后引起的矩阵近奇异问题，对于提高回归精度的效果有限'】
% %______TRaining________________________________
% num_PLS=50;
% [~,~,~,~,beta_PLS1,~] = plsregress(Lifted_Vector.Input_Lifted',Output',num_PLS);
% [~,~,~,~,beta_PLS2,~] = plsregress(X_Lag_New',Data_Lag.Output_Delta',num_PLS);
% %______TEST________________________________
% yfit = [ones(size(Lifted_Vector.Input_Lifted',1),1) Lifted_Vector.Input_Lifted']*beta_PLS1;
% Output_test_pls=yfit';
% fprintf('\n【PLS Parameter Info】num_PLS： %d  .',num_PLS);
% fprintf('\n【PLS Error】Average Error： %f  ，Maximum Error： %f  .', ...
%     mean(mean(abs(Output_test_pls-Output))),max(max(abs(Output_test_pls-Output))));
% 
% yfit2 = [ones(size(X_Lag_New',1),1) X_Lag_New']*beta_PLS2;
% Output_test_TEMP2=yfit2';
% Output_test_pls2=Output_test_pls+Train_Ops.Beita*Output_test_TEMP2;
% 
% fprintf('\n【PLS Error with SM】Average Error： %f  ，Maximum Error： %f  .', ...
%     mean(mean(abs(Output_test_pls2-Output))),max(max(abs(Output_test_pls2-Output))));
% 
% beta_PLS=beta_PLS1+Train_Ops.Beita*beta_PLS2;
%% Ridge
% M_Ridge=zeros(size(Output,1),size(Lifted_Vector.Input_Lifted,1));
% k_ridge=1;
% for i=1:size(Output,1)
%     B1=ridge(Output(i,:)',Lifted_Vector.Input_Lifted',k_ridge);
%     M_Ridge(i,:)=B1;
% end
% Output_Test_ridge=M_Ridge*Lifted_Vector.Input_Lifted;
% fprintf('\n【Ridge Error】Average Error： %f  ，Maximum Error： %f  .', ...
%     mean(mean(abs(Output_Test_ridge-Output))),max(max(abs(Output_Test_ridge-Output))));

%% SVR 支持向量机回归【'主要用于解决部分节点量测数据存在较大偏差的问题'】
% %______TRaining________________________________
% kernel_type='g';  %'g':%gaussian Kernel  'l':linear Kernel  'p':poly3 Kernel
% maxItr=10;
% Alpha_SVR=SVR_Rge_Mul(XM',OutputData',kernel_type,maxItr);
% %______TEST________________________________
% F_o = SVR_Predic(inputData',Alpha_SVR,kernel_type);
% Y_SVR=F_o';
% fprintf('\n【SVR Parameter Info】kernel_type： %s  ，maxItr： %d  .',kernel_type,maxItr);
% fprintf('\n【SVR Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Y_SVR-OutputData))),max(max(abs(Y_SVR-OutputData))));

 fprintf('\n【REGRESSION】end\n\n');
end