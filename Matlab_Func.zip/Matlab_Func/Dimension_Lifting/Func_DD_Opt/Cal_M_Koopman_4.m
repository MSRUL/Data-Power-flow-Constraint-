function [M,Storge_Info] = Cal_M_Koopman_4(inputData,OutputData,rbf_type,cent_input,Pos_In_OutPut)
%Cal_M_Koopman_2 Use the Koopman to Tranning the M Matrix. (In this Part , The Dimension of Control Variable is not Lifted)

% % 3:the basic incomplete dimension lifting with the control variable is quadratic space
[Xp] =Lift_Vector_Incomplete_3(inputData,rbf_type,cent_input,Pos_In_OutPut.RisePos); %the control parts: 3N+1  ; The Other Parts: 'rbf_type'
%% LS最小二乘法
% %______TRaining________________________________
Using_M=1;  
if Using_M==1 %Use the Traditional Least Squares Method to Calculate the Matrix M
    W = Xp*Xp';
    V = OutputData*Xp';
    M = V*pinv(W);
else %Use the Direct Calculate the Matrix M
    M=OutputData*pinv(Xp);
end
Storge_Info=[];
% %______TEST________________________________
% Lifted_Output_Test_Incompelet = Lift_Vector_Incomplete(inputData,rbf_type,cent_input,RisePos);
% Y_LS=M*Lifted_Output_Test_Incompelet;
% fprintf('\n【LS Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Y_LS-OutputData))),max(max(abs(Y_LS-OutputData))));
%% The LP Method
% Options.M_OR_LS=M;
% Options.Pos_OR_VarOpt=Pos_In_OutPut.Un_RisePos;
% Options.Opt_Var_Type='Qua_All';  %'Qua_Part'  'Qua_All'
% Options.Cons_Qua_Postive=0;
% [M,~] = Mmatrix_Opti2(Xp,OutputData,Options);
% 
% Storge_Info.rbf_type=rbf_type;
% Storge_Info.cent_input=cent_input;
% Storge_Info.Opt_Var_Type=Options.Opt_Var_Type;
% Storge_Info.M_OR_LS=Options.M_OR_LS;
% Storge_Info.M_Opt_LS=M;

%% PLS 偏最小二乘估计方法【'主要用于解决数据共线性后引起的矩阵近奇异问题，对于提高回归精度的效果有限'】
% %______TRaining________________________________
% num_PLS=50;
% [~,~,~,~,beta_PLS,PCTVAR] = plsregress(Xp',OutputData',num_PLS);
% max(cumsum(100*PCTVAR(2,:)))
% %______TEST________________________________
% yfit = [ones(size(Xp',1),1) Xp']*beta_PLS;
% Y_PLS=yfit';
% fprintf('\n【PLS Parameter Info】num_PLS： %d  .',num_PLS);
% fprintf('\n【PLS Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Y_PLS-OutputData))),max(max(abs(Y_PLS-OutputData))));

%% SVR 支持向量机回归【'主要用于解决部分节点量测数据存在较大偏差的问题'】
% %______TRaining________________________________
% kernel_type='g';  %'g':%gaussian Kernel  'l':linear Kernel  'p':poly3 Kernel
% maxItr=10;
% Alpha_SVR=SVR_Rge_Mul(Xp',OutputData',kernel_type,maxItr);
% %______TEST________________________________
% F_o = SVR_Predic(inputData',Alpha_SVR,kernel_type);
% Y_SVR=F_o';
% fprintf('\n【SVR Parameter Info】kernel_type： %s  ，maxItr： %d  .',kernel_type,maxItr);
% fprintf('\n【SVR Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Y_SVR-OutputData))),max(max(abs(Y_SVR-OutputData))));
%% 本函数作为基础改进后的函数列表：（修改本函数后，注意相应调整。）
% 【REFFERECNE 】
%[1] 'F:\科研\Koopman_PF2\Function\Cal_M_Koopman_3.m'
end



