function [Jac,SensM] = Build_JacM_Classic_PF_Equition(case_PF_result)
%ZYX 2021.10 Cal the Jac Matrix based on the classic PF equi
%%
Bus_num=size(case_PF_result.bus,1);
bus=case_PF_result.bus;
branch=case_PF_result.branch;
baseMVA=case_PF_result.baseMVA;
%%
[Ybus, ~, ~] = makeYbus(baseMVA, bus, branch);
%%
H=zeros(Bus_num,Bus_num); %delta Pi/delta sitaj
N=zeros(Bus_num,Bus_num); %delta Pu/[(delta Uj)/Uj]
M=zeros(Bus_num,Bus_num); %delta Qu/delta sitaj
L=zeros(Bus_num,Bus_num); %delta Qu/[(delta Uj)/Uj]
N_noU=N;%delta Pi/delta Uj
L_noU=L;%delta Qi/delta Uj
%%
for i=1:Bus_num
    for j=1:Bus_num
        sita_ij=bus(i,9)-bus(j,9);
        if i==j
            N_noU(i,j)=N_noU(i,j)+2*bus(j,8)*(real(Ybus(i,j))*cos(sita_ij)+imag(Ybus(i,j))*sin(sita_ij));
            L_noU(i,j)=L_noU(i,j)-2*bus(j,8)*(imag(Ybus(i,j))*cos(sita_ij)-real(Ybus(i,j))*sin(sita_ij));
        else
            N_noU(i,j)=N_noU(i,j)+bus(i,8)*(real(Ybus(i,j))*cos(sita_ij)+imag(Ybus(i,j))*sin(sita_ij));
            L_noU(i,j)=L_noU(i,j)-bus(i,8)*(imag(Ybus(i,j))*cos(sita_ij)-real(Ybus(i,j))*sin(sita_ij));
        end
         H(i,j)=H(i,j)+bus(i,8)*bus(j,8)*(-real(Ybus(i,j))*sin(sita_ij)-imag(Ybus(i,j))*cos(sita_ij));
         M(i,j)=M(i,j)-bus(i,8)*bus(j,8)*(-imag(Ybus(i,j))*sin(sita_ij)-real(Ybus(i,j))*cos(sita_ij));
    end
end

Jac=[H,N_noU;M,L_noU]; % Not the Jac in NR method; (N_noU ~=N;L_noU~=L)
SensM=Jac^-1;
end

