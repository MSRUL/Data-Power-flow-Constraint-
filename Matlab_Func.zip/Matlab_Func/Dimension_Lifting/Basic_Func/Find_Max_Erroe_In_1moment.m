function [pos_temp,temp] = Find_Max_Erroe_In_1moment(inputArg1,inputArg2,index,type,case_name)
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

    [ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
if type==1
    target_NRPF=inputArg1(1:length(pq));
    target_KPM=inputArg2(1:length(pq));
end
if type==2
    target_NRPF=inputArg1(length(pq)+1:length(pq)+length(case_name.branch));
    target_KPM=inputArg2(length(pq)+1:length(pq)+length(case_name.branch));
end
if type==3
    target_NRPF=inputArg1(length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    target_KPM=inputArg2(length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
end
if type==4
    target_NRPF=inputArg1(length(pq)+2*length(case_name.branch)+1:2*length(pq)+2*length(case_name.branch));
    target_KPM=inputArg2(length(pq)+2*length(case_name.branch)+1:2*length(pq)+2*length(case_name.branch));
end
if type==5
    target_NRPF=inputArg1(2*length(pq)+2*length(case_name.branch)+1:length(pv)+2*length(pq)+2*length(case_name.branch));
    target_KPM=inputArg2(2*length(pq)+2*length(case_name.branch)+1:length(pv)+2*length(pq)+2*length(case_name.branch));
end
pos_temp= find(abs((target_NRPF-target_KPM))>=index);
temp=abs((target_NRPF-target_KPM));


end

