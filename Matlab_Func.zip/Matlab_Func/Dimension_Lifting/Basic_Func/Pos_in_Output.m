function [outputArg1] = Pos_in_Output(type,node,line,pq,pvbranch)
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

if size(node,1)*size(node,2)>1
    ;
else
    
end

if type==1
    outputArg1=node;
end

if type==2
    outputArg1=line+num_pq;
end

if type==3
    outputArg1=line+num_pq+num_branch;
    
end
if type==4
    outputArg1=num_pq+num_branch*2+node;
end
if type==5
    outputArg1=num_pq*2+num_branch*2+node;
end

end

