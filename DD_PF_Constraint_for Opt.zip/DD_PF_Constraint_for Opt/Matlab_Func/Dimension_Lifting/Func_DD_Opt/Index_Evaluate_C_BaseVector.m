function [Index] = Index_Evaluate_C_BaseVector(cent_input_compelete)
%Index_Evaluate_C_BaseVector 评估
%   此处提供详细说明

%% 矩阵的与均值的差值
Vector_Mean=mean(cent_input_compelete');
Distance_Mean=mean(abs(cent_input_compelete-Vector_Mean'));
Distance_Max=max(abs(cent_input_compelete-Vector_Mean'));
Index.Dis2Mean.MeanMean=mean(Distance_Mean);
Index.Dis2Mean.MeanMax=mean(Distance_Max);
Index.Dis2Mean.MaxMax=max(Distance_Max);

%% 矩阵向量之间的差值
A_Dis=zeros(size(cent_input_compelete,2),size(cent_input_compelete,2));
for i=1:size(cent_input_compelete,2)
    for j=1:size(cent_input_compelete,2)
        A_Dis_mean(i,j)=mean(abs(cent_input_compelete(:,i)-cent_input_compelete(:,j)));
        A_Dis_max(i,j)=max(abs(cent_input_compelete(:,i)-cent_input_compelete(:,j)));
    end
end
for i=1:length(A_Dis)
    A_Dis_mean(i,i)=0;
    A_Dis_max(i,i)=0;
end
Index.Dis_BetweenEacher.EMeanMean=mean(mean(A_Dis_mean));
Index.Dis_BetweenEacher.EMeanMax=mean(max(A_Dis_mean));
Index.Dis_BetweenEacher.EMaxMax=max(max(A_Dis_mean));
Index.Dis_BetweenEacher.MMeanMean=mean(mean(A_Dis_max));
Index.Dis_BetweenEacher.MMeanMax=mean(max(A_Dis_max));
Index.Dis_BetweenEacher.MMaxMax=max(max(A_Dis_max));

%% 相关性
CovX=cov(cent_input_compelete);
for i=1:length(CovX)
    CovX(i,i)=0;
end
Index.CovX.MeanMean=mean(mean(CovX));
Index.CovX.MeanMax=mean(max(CovX));
Index.CovX.MaxMax=max(max(CovX));
%%

Index.Total=[   Index.Dis2Mean.MeanMean;    Index.Dis2Mean.MeanMax;    Index.Dis2Mean.MaxMax;...
                Index.Dis_BetweenEacher.EMeanMean;   Index.Dis_BetweenEacher.EMeanMax;   Index.Dis_BetweenEacher.EMaxMax;...
                Index.Dis_BetweenEacher.MMeanMean;   Index.Dis_BetweenEacher.MMeanMax;   Index.Dis_BetweenEacher.MMaxMax;...
                Index.CovX.MeanMean;    Index.CovX.MeanMax;    Index.CovX.MaxMax];
end