function [cent] = Generate_Cent_Pro(IDL_Peremeters,Nrbf1)
%ZYX  20220825 
% Based on the Generate_Cent, the random Vector is based on the average
% Data of Input
%   此处提供详细说明
Way=1;% 1  2  3
switch IDL_Peremeters.type
    case 'IDL'
        switch Way
            case 1% =======Way1================= 1st
                cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1).*IDL_Peremeters.Input(IDL_Peremeters.RisePos,1)*2;
            case 2%=======Way2================= 3rd
                cent = (rand(size(IDL_Peremeters.RisePos,2),Nrbf1)+0.5).*IDL_Peremeters.Input(IDL_Peremeters.RisePos,1);
            case 3%=======Way3================= 2ed
                temp=rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
                for i=1:size(IDL_Peremeters.RisePos,2)
                    for j=1:Nrbf1
                        if temp(i,j)<0.5 temp(i,j)=-1; else temp(i,j)=1;end
                    end
                end
                cent = temp.*IDL_Peremeters.Input(IDL_Peremeters.RisePos,1)*2;
        end
    case 'IDL_withSM'
        cent.Part2=rand(size(IDL_Peremeters.RisePos,2),Nrbf1); % The basic part
        cent.Part1=rand(size(IDL_Peremeters.RisePos,2)+size(IDL_Peremeters.Un_RisePos,2),Nrbf1);% The additional part

    case 'IDL_QuaModified'
        switch Way
            case 1% =======Way1================= 1st
                cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1).*IDL_Peremeters.Input(IDL_Peremeters.RisePos,1)*2;
            case 2%=======Way2================= 3rd
                %         cent = (rand(size(IDL_Peremeters.RisePos,2),Nrbf1)+0.5).*IDL_Peremeters.Input(IDL_Peremeters.RisePos,1)*2;
            case 3%=======Way3================= 2ed
                %         temp=rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
                %         for i=1:size(IDL_Peremeters.RisePos,2)
                %             for j=1:Nrbf1
                %                 if temp(i,j)<0.5 temp(i,j)=-1; else temp(i,j)=1;end
                %             end
                %         end
                %         cent = temp.*IDL_Peremeters.Input(IDL_Peremeters.RisePos,1)*2;
        end
    case 'IDL_QuaModified_withSM'
        cent.Part2=rand(size(IDL_Peremeters.RisePos,2),Nrbf1); % The basic part
        cent.Part1=rand(size(IDL_Peremeters.RisePos,2)+2*size(IDL_Peremeters.Un_RisePos,2)+1,Nrbf1);% The additional part
       
    case 'IDL_QuaModified_withSM_3Np1'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
    case 'IDLSM2'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
    case 'IDLSM3'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
    case 'IDL_CubicSpace'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
      
end
end