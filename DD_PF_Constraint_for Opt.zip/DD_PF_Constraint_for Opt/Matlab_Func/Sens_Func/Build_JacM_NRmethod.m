function [Jac,SensM] = Build_JacM_NRmethod(case_PF_result)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明


Bus_num=size(case_PF_result.bus,1);
bus=case_PF_result.bus;
gen=case_PF_result.gen;
branch=case_PF_result.branch;
baseMVA=case_PF_result.baseMVA;
line_active=find(branch(:,11)==1);

%%
[Ybus, Yf, Yt] = makeYbus(baseMVA, bus, branch);
%%
H=zeros(Bus_num,Bus_num); %delta Pi/delta sitaj
N=zeros(Bus_num,Bus_num); %delta Pu/[(delta Uj)/Uj]
J=zeros(Bus_num,Bus_num); %delta Qu/delta sitaj
L=zeros(Bus_num,Bus_num); %delta Qu/[(delta Uj)/Uj]
N_noU=N;%delta Pi/delta Uj
L_noU=L;%delta Qi/delta Uj
for i=1:Bus_num
    for j=1:Bus_num
        sita_ij=bus(i,9)-bus(j,9);
        if i~=j
            H(i,j)=bus(i,8)*bus(j,8)*(real(Ybus(i,j))*sin(sita_ij)-imag(Ybus(i,j))*cos(sita_ij));
            J(i,j)=-bus(i,8)*bus(j,8)*(real(Ybus(i,j))*cos(sita_ij)+imag(Ybus(i,j))*sin(sita_ij));
            N(i,j)=bus(i,8)*(real(Ybus(i,j))*sin(sita_ij)+imag(Ybus(i,j))*cos(sita_ij));
            L(i,j)=bus(i,8)*(real(Ybus(i,j))*sin(sita_ij)-imag(Ybus(i,j))*cos(sita_ij));
            N_noU(i,j)=bus(i,8)*(real(Ybus(i,j))*sin(sita_ij)+imag(Ybus(i,j))*cos(sita_ij));
            L_noU(i,j)=bus(i,8)*(real(Ybus(i,j))*sin(sita_ij)-imag(Ybus(i,j))*cos(sita_ij));      
        end
    end
end
%--------Diagonal element------
for i=1:Bus_num
    for j_temp=1:Bus_num
        if i~=j_temp
            sita_ij=bus(i,9)-bus(j_temp,9);
            H(i,i)=H(i,i)-bus(i,8)*bus(j_temp,8)*(real(Ybus(i,j_temp))*sin(sita_ij)-imag(Ybus(i,j_temp))*cos(sita_ij));
            J(i,i)=J(i,i)+bus(i,8)*bus(j_temp,8)*(real(Ybus(i,j_temp))*cos(sita_ij)+imag(Ybus(i,j_temp))*sin(sita_ij));
            N(i,i)=N(i,i)+bus(i,8)*bus(j_temp,8)*(real(Ybus(i,j_temp))*cos(sita_ij)+imag(Ybus(i,j_temp))*sin(sita_ij));
            L(i,i)=L(i,i)+bus(i,8)*bus(j_temp,8)*(real(Ybus(i,j_temp))*sin(sita_ij)-imag(Ybus(i,j_temp))*cos(sita_ij));
            N_noU(i,i)=N_noU(i,i)+bus(j_temp,8)*(real(Ybus(i,j_temp))*cos(sita_ij)+imag(Ybus(i,j_temp))*sin(sita_ij));
            L_noU(i,i)=L_noU(i,i)++bus(j_temp,8)*(real(Ybus(i,j_temp))*sin(sita_ij)-imag(Ybus(i,j_temp))*cos(sita_ij));
        end
    end
    N(i,i)=N(i,i)+2*bus(i,8)*bus(i,8)*real(Ybus(i,j_temp));
    L(i,i)=L(i,i)-2*bus(i,8)*bus(i,8)*imag(Ybus(i,j_temp));
    N_noU(i,i)=N_noU(i,i)+2*bus(i,8)*real(Ybus(i,j_temp));
    L_noU(i,i)=L_noU(i,i)-2*bus(i,8)*imag(Ybus(i,j_temp));
end



Jac=[H N;J L];
%%
[ref, pv, pq] = bustypes(bus, gen);
    Jac(ref,:)=0;
    Jac(:,ref)=0;
    Jac(ref,ref)=1;
    Jac(Bus_num+ref,:)=0;
    Jac(:,Bus_num+ref)=0;
    Jac(Bus_num+ref,Bus_num+ref)=1;
    Jac(Bus_num+pv,:) = 0;
    Jac(:,Bus_num+pv) = 0;
%%
SensM=Jac\eye(size(Jac));
end

