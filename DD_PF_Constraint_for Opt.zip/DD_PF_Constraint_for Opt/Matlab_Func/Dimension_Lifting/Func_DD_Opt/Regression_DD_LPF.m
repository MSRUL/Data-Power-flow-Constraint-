function [M_DDLPF] = Regression_DD_LPF(Data_DDLPF,case_name,Regression_Sets)
% Regression (Inverse)
%   此处显示详细说明

line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
%% Data Info
P_injection=Data_DDLPF.P_injection';
Q_injection=Data_DDLPF.Q_injection';
Vm=Data_DDLPF.Vm';
Va=Data_DDLPF.Va';
PL=Data_DDLPF.PL';
QL=Data_DDLPF.QL';
PLoss=Data_DDLPF.PLoss';
%% Cae Info
[ref] = bustypes(case_name.bus, case_name.gen);
%%
switch Regression_Sets.regression
	case 'LS' % ordinary least squares
		for i = 1:size(case_name.bus,1) 
			P = P_injection;
			P(:, ref) = zeros;
			PQ_va = [P Q_injection ones(size(Vm, 1), 1)];
			[b,~,~,~,~] = regress(Va(:, i) * pi / 180, PQ_va);
			Xva(i, :) = b';
			[b,~,~,~,~] = regress(Vm(:, i), PQ_va);
			Xv(i, :) = b';
        end
        for i = 1:Branch_Num
			P = P_injection;
			P(:, ref) = zeros;
			PQ_va = [P Q_injection ones(size(Vm, 1), 1)];
			[b,~,~,~,~] = regress(PL(:, i) , PQ_va);
			Xpf(i, :) = b';
			[b,~,~,~,~] = regress(QL(:, i), PQ_va);
			Xqf(i, :) = b';
        end
	case 'PLS' % partial least squares
%         P = data.P;
% 		P(:, ref) = zeros;
% 		k = rank(P) + rank(data.Q) + 1;
% 		k = min(k, size(data.P, 1) - 1);
% 		X_pls = [P data.Q];
% 		Y_va_pls = data.Va  * pi / 180;
% 		Y_va_pls(:, ref) = data.P(:, ref);
% 		[~,~,~,~,Xva] = plsregress(X_pls, Y_va_pls, k);   % 功率  -  电压相角
% % 		beta=Xva;%测试用
%         Xva = Xva';
% 		temp = Xva(:,1);Xva(:,1) = [];Xva = [Xva temp];
%         
%         
		P = P_injection;
		P(:, ref) = zeros;
		k = rank(P) + rank(Q_injection) + 1;
		k = min(k, size(P_injection, 1) - 1);
		X_pls = [P Q_injection];
        %%
		Y_va_pls = Va  * pi / 180;
		Y_va_pls(:, ref) = P_injection(:, ref);
		[~,~,~,~,Xva] = plsregress(X_pls, Y_va_pls, k);   % Power Injection  -  Bus Voltage Angle
		beta=Xva;%测试用
        Xva = Xva';
		temp = Xva(:,1);Xva(:,1) = [];Xva = [Xva temp];%Change the position of the constant item
        yfitVa = [ones(size(X_pls,1),1) X_pls]*beta;  %测试用

		Y_v_pls = Vm;
		[~,~,~,~,Xv] = plsregress(X_pls, Y_v_pls, k);  % Power Injection  -  Bus Voltage Magnitude
		beta=Xv;%测试用
        Xv = Xv';
		temp = Xv(:,1);Xv(:,1) = [];Xv = [Xv temp];%Change the position of the constant item
        yfitVm = [ones(size(X_pls,1),1) X_pls]*beta;%测试用
        
		Y_pf_pls = PL;
		[~,~,~,~,Xpf] = plsregress(X_pls, Y_pf_pls, k);   % Power Injection  -  Branch Active Power Flow
		beta_pf=Xpf;
        Xpf = Xpf';
		temp = Xpf(:,1);Xpf(:,1) = [];Xpf = [Xpf temp];%Change the position of the constant item
        yfitpf = [ones(size(X_pls,1),1) X_pls]*beta_pf;%测试用
        
		Y_qf_pls = QL;
		[~,~,~,~,Xqf] = plsregress(X_pls, Y_qf_pls, k);   % Power Injection  -  Branch Reactive Power Flow
        beta_qf=Xqf;
		Xqf = Xqf';
		temp = Xqf(:,1);Xqf(:,1) = [];Xqf = [Xqf temp];%Change the position of the constant item
        yfitqf = [ones(size(X_pls,1),1) X_pls]*beta_qf;%测试用
        aaa=0;
end
M_DDLPF.XVa=Xva;
M_DDLPF.XVm=Xv;
M_DDLPF.XPL=Xpf;
M_DDLPF.XQL=Xqf;
end

