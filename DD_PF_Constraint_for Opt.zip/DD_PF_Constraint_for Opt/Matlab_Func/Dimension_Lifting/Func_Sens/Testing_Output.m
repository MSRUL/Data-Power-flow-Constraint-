function [OPT1,OPT2] = Testing_Output(Input,Output,M,M_Inverse,cent_input,cent_output,rbf_type,rbf_type_Inverse)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明

OPT1=zeros(size(Output));
OPT2=zeros(size(Input));

for i=1:size(Input,2)
    IPT_test=Lift_Vector_Complete(Input(:,i),rbf_type,cent_input);
    
    OPT1(:,i)=M*IPT_test;
    
    IPT_test=Lift_Vector_Complete(Output(:,i),rbf_type_Inverse,cent_output);
    OPT2(:,i)=M_Inverse*IPT_test;
end

end

