function [Lifted_Vector] = Lift_Vector_Complete_Total(inputArg1,DLR_Peremeters)
% ZYX 20220415
% 

rbf_type=DLR_Peremeters.rbf_type;
cent=DLR_Peremeters.cent;


switch rbf_type
    case 'polyharmonic'
        lifted_inpuit = Lift_Dem_Fun_Tradi(inputArg1,rbf_type,cent);
    case 'invquad'
        lifted_inpuit = Lift_Dem_Fun_Tradi(inputArg1,rbf_type,cent);
    case 'invmultquad'
        lifted_inpuit = Lift_Dem_Fun_Tradi(inputArg1,rbf_type,cent);
    case '2n+1' % Quadratic function(without the interaction between variables)
        [lifted_inpuit] = Lift_Dem_Fun_2NP1(inputArg1);
    case '3n+1'% 3N+1褰㈠紡
        lifted_inpuit = Lift_Dem_Fun_3NP1(inputArg1);
    case 'Cubic_3NP1'
        lifted_inpuit = Lift_Dem_Fun_Cubic_3NP1(inputArg1);
    case '2second order'% 瀹屾暣鐨勪簩娆″瀷绌洪棿
        lifted_inpuit = Lift_Func(inputArg1);
    case 'MIX polyh and 3n+1'
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',cent);
        lifted_inpuit2 =  Lift_Dem_Fun_3NP1(inputArg1);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 'MIX polyh and invquad'
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 'MIX polyh and invmultquad'
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 'MIX invquad and invmultquad'
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 'MIX polyh invquad invmultquad' % polyharmonic+invquad+invmultquad,!!!DIMENSION *1.5!!!!
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent3);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:);lifted_inpuit3(size(inputArg1,1)+1:end,:)];
    case 'MIX polyh invquad invmultquad 3n+1' % polyharmonic+invquad+invmultquad+3np1,!!!DIMENSION DOUBLE!!!!
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent3);
        lifted_inpuit4 =  Lift_Dem_Fun_3NP1(inputArg1);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:);lifted_inpuit3(size(inputArg1,1)+1:end,:);lifted_inpuit4(size(inputArg1,1)+1:end,:)];
end
Lifted_Vector=[lifted_inpuit];
% Lifted_Vector=[inputArg1;lifted_inpuit];
end

%%
