function [Result_CPLEX] = CPLEX_DLPF_Optimization(casename_NR,INclude_PV_node,Constraint,Objective_Info,Weather_cal_Branch_Flow_S)
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%%

Voltage=Constraint.Voltage;
% FixVar=Constraint.FixVar;
%% Define matpower constants
define_constants;
%% Matrices  ��Fixed variable��

casename_NR.bus(:,[3,4])=[Constraint.P_Load,Constraint.Q_Load];

[baseMVA, bus, gen ,branch] = deal(casename_NR.baseMVA, casename_NR.bus, casename_NR.gen, casename_NR.branch);
[ref,pv, pq,pv_pos,ref_pos,pv_total] = Case_Info(casename_NR);
Ybus = makeYbus(casename_NR);
Gbus = real(Ybus);
Bbus = imag(Ybus);
GP = Gbus;
BD = diag(sum(Bbus));             %shunt elements
BP = -Bbus + BD;
BQ = -Bbus;
GQ = -Gbus;                       %GQ approxiately equals -Gbus

%% DLPF Parameter
B11 = BP([pv;pq],[pv;pq]);
G12 = GP([pv;pq],pq);
G21 = GQ(pq,[pv;pq]);
B22 = BQ(pq,pq);
% -----------------Matrices in equation (17)---------------
t2 = G21/B11;
t1 = G12/B22;
B22m = B22 - t2*G12;
B11m = B11 - t1*G21;

%% Input Parameter
Sbus = makeSbus(baseMVA, bus, gen);  % Power injection ,so the load is below zero
P_Load = real(Sbus);
Q_Load = imag(Sbus);
PVinverter_P=Constraint.PVinverter_P/baseMVA;
INclude_PV_S=Constraint.INclude_PV_S/baseMVA;
PVinverter_Q=Constraint.PVinverter_Q/baseMVA;
%% Init variable

PV_P= sdpvar(size(INclude_PV_node,2),1);
PV_Q = sdpvar(size(INclude_PV_node,2),1);
Vol = sdpvar(size(casename_NR.bus,1),1);
BusAgl = sdpvar(size(casename_NR.bus,1),1);
Pbus = sdpvar(size(casename_NR.bus,1),1);
Qbus = sdpvar(size(casename_NR.bus,1),1);
Pm1_2=sdpvar(length(pq),1);
Qm1= sdpvar(length(pq),1);
Qm2= sdpvar(length(pq),1);
Pm2= sdpvar(length(pq)+length(pv),1);
% BranchFlow= sdpvar(size(branch,1),1);
BranchFlow_DLPF_Active= sdpvar(size(branch,1),1);
BranchFlow_DLPF_Reactive= sdpvar(size(branch,1),1);
BranchFlow_DLPF_Loss= sdpvar(size(branch,1),1);

% Matrices in equation (11)
%      | Pm1 |   | B11  G12 |   | delta   |   
%      |     | = |          | * |         | 
%      | Qm1 |   | G21  B22 |   | voltage | 
%% Init DLPF Constraint
% Pm1 = Pbus([pv;pq]) - GP([pv;pq],ref)*bus(ref,VM) - GP([pv;pq],pv)*bus(pv,VM);
Pm1_1 = Pbus(pv) - GP(pv,ref)*bus(ref,VM) - GP(pv,pv)*bus(pv,VM);  %��Fixed variable��
%% DLPF Constraint

Constraints=[];
for i=1:size(casename_NR.bus,1)
    if ismember(i,INclude_PV_node)
        pos_PV_num=find(INclude_PV_node==i);
        Constraints=[Constraints;Pbus(i,1)==P_Load(i,1)+PV_P(pos_PV_num,1)];% The P_Load is negative number(Injection)
        Constraints=[Constraints;Qbus(i,1)==Q_Load(i,1)+PV_Q(pos_PV_num,1)];
    else
        Constraints=[Constraints;Pbus(i,1)==P_Load(i,1)];
        Constraints=[Constraints;Qbus(i,1)==Q_Load(i,1)];
    end
end

Constraints=[Constraints;Pm2 == [Pm1_1;Pm1_2] - t1*Qm1;];
Constraints=[Constraints;Pm1_2 == Pbus(pq) - GP(pq,ref)*bus(ref,VM) - GP(pq,pv)*bus(pv,VM)];
Constraints=[Constraints;Qm1 == Qbus(pq) - BQ(pq,ref)*bus(ref,VM) - BQ(pq,pv)*bus(pv,VM);];
Constraints=[Constraints;Qm2 == Qm1 - t2*[Pm1_1;Pm1_2]];
Constraints=[Constraints;Vol(pq,1)==(B22m^-1)*Qm2];

Constraints=[Constraints;BusAgl([pv;pq]) == ones(length(pv)+length(pq),1)*bus(ref,VA) + B11m\Pm2/pi*180];
Constraints=[Constraints;BusAgl(ref)== ones(length(ref),1)*bus(ref,VA)];

%% Voltage Magnitude and Angle Constraint
Constraints=[Constraints;Vol(ref,1)==gen(ref_pos,6)];
Constraints=[Constraints;Vol(pv,1)==bus(pv,VM)];
Constraints=[Constraints;Voltage.min<=Vol(pq,1)<=Voltage.max];

%% Photovoltaic Inverter Power
for i=1:size(PV_P,1)
    PV_Q_Limit_Rate=1;
    if strcmp(Objective_Info.type,'DG_Consumption')||strcmp(Objective_Info.Opt_Variable,'Active_Power')
        Constraints=[Constraints; 0<=PV_P(i,1)<=PVinverter_P(i,1)];  %PV inverter Active Power limint
        Constraints=[Constraints; PV_Q(i,1)==PVinverter_Q(i,1)];  %PV inverter Active Power limint
%         Constraints=[Constraints; abs(PV_Q(i,1))<=INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Reactive Power limint
        Constraints=[Constraints; norm([PV_P(i,1);PV_Q(i,1)])<=INclude_PV_S(i,1)];  %PV inverter Reactive Power limint
    else
        Constraints=[Constraints; PV_P(i,1)==PVinverter_P(i,1)];  %PV inverter Active Power limint
        Constraints=[Constraints; abs(PV_Q(i,1))<=INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Reactive Power limint
        Constraints=[Constraints; norm([PV_P(i,1);PV_Q(i,1)])<=INclude_PV_S(i,1)];  %PV inverter Reactive Power limint
    end
end

%% Additional variables(for calculation/optimazition porpose)
%--------------Branch Power Flow --------------------------

temp1=zeros(size(branch,1),2);
for i=1:length(temp1)
    temp1(i,1)=Gbus(branch(i,F_BUS),branch(i,T_BUS));
    temp1(i,2)=Bbus(branch(i,F_BUS),branch(i,T_BUS));
end
Constraints=[Constraints; BranchFlow_DLPF_Active == ((Vol(branch(:,F_BUS)) - Vol(branch(:,T_BUS))).*temp1(:,1)*baseMVA ...
    -(BusAgl(branch(:,F_BUS))-BusAgl(branch(:,T_BUS))).*temp1(:,2)/180*pi*baseMVA)]; % the sitas in equation (27) is 0,so neglected.
Constraints=[Constraints; BranchFlow_DLPF_Reactive == ((Vol(branch(:,T_BUS)) - Vol(branch(:,F_BUS))).*temp1(:,2)*baseMVA ...
    -(BusAgl(branch(:,F_BUS))-BusAgl(branch(:,T_BUS))).*temp1(:,1)/180*pi*baseMVA)];  % the sitas in equation (27) is 0,so neglected.
if Weather_cal_Branch_Flow_S==1
    %--------------Branch Power Flow Loss-----��The DLPF ignort the branch loss ��--------Ploss=(PL^2+QL^2)*R-------(Ploss=(PL^2+QL^2)/U^2*R)--------
    Constraints=[Constraints; BranchFlow_DLPF_Loss==(((BranchFlow_DLPF_Active/baseMVA).^2+(BranchFlow_DLPF_Reactive/baseMVA).^2).*branch(:,BR_R))*baseMVA];
end
%% Objective

switch Objective_Info.type
    case 'Min Adjustment'
        switch Objective_Info.Opt_Variable
            case 'Reactive_Power'
                objective=sum(abs(PV_Q-Constraint.PVinverter_Q)); %
            case 'Active_Power'
                objective=sum(abs(PV_P-Constraint.PVinverter_P)); %
        end
    case 'Min Loss'
        objective=sum(BranchFlow_DLPF_Loss);
    case 'Hybrid'
         objective=Objective_Info.Hybrid_Index(1)*sum(BranchFlow_DLPF_Loss)+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q-Constraint.PVinverter_Q));
    case 'Min_Voltage_deviation_rate'
         objective=sum(abs(Objective_Info.Voltage_Tatget-Vol));
    case 'Min_VDR_and_Min_Adj'
         objective=Objective_Info.Hybrid_Index(1)*sum(abs(Objective_Info.Voltage_Tatget-Vol))+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q-Constraint.PVinverter_Q));
    case 'DG_Consumption'
        objective=-sum(abs(PV_P));
end
varargout=optimize(Constraints,objective);
varargout.info
%%
Result_CPLEX.PV_P=value(PV_P)*baseMVA;
Result_CPLEX.PV_Q=value(PV_Q)*baseMVA;
Result_CPLEX.Pbus=value(Pbus);
Result_CPLEX.Qbus=value(Qbus);
Result_CPLEX.Voltage=value(Vol);
Result_CPLEX.Vm_PQ=value(Vol(pq));
Result_CPLEX.BusAgl=value(BusAgl);
Result_CPLEX.objective=value(objective);
Result_CPLEX.BranchFlow_DLPF_Active=-value(BranchFlow_DLPF_Active);
Result_CPLEX.BranchFlow_DLPF_Reactive=-value(BranchFlow_DLPF_Reactive);
Result_CPLEX.BranchFlow_DLPF_Loss=value(BranchFlow_DLPF_Loss);
Result_CPLEX.Ploss=sum(Result_CPLEX.BranchFlow_DLPF_Loss);
Result_CPLEX.PV_Q_Adj=value(PV_Q)*baseMVA-PVinverter_Q*baseMVA;
Result_CPLEX.PV_P_Adj=value(PV_P)*baseMVA-PVinverter_P*baseMVA;
Result_CPLEX.Opt_Info=varargout.info;
Result_CPLEX.solvertime=varargout.solvertime;
% figure;
% subplot(3,1,1);plot(Result_CPLEX.PV_P); hold on;plot(PVinverter_P*baseMVA)
% subplot(3,1,2);plot(Result_CPLEX.PV_Q); hold on;plot(PVinverter_Q*baseMVA)
% subplot(3,1,3);plot(Result_CPLEX.Voltage); hold on;plot(value(Vol))

end











