function [INPUT_Record,OUTPUT_Record] = Senstive_KPM_Voltage_Control(Input_controled,M_V,Senstive_M,Below_Voltage,AdjStep,rbf_type,cent_input_compelete,Voltage,Device_Info,Pos_In_OutPut)
%UNTITLED15 Koopman
%%
Device_Info.INclude_PV_S;
Device_Info.INclude_PV_node;
AdjStep.TransTab_step;
AdjStep.adjust_P_step;
AdjStep.adjust_Q_step;
Pos_In_OutPut.Pos_P_in_Inventer;
Pos_In_OutPut.Pos_Q_in_Inventer;
%%
M_V_Rank=Senstive_M;
Adj_T=0; %Weather to Adjust the Transformer Tab, 1:Yes, 0:No
Adj_Q=1; %Weather to Adjust the Reactive Power of Photovoltaic Inventer, 1:Yes, 0:No
OUTPUT_Record=[];
INPUT_Record=[];
Adj_Input=Input_controled;
while(length(Below_Voltage)>0)
    sum_of_PV_outRange_S=0;
    for i=1:length(Below_Voltage)
%         temp_i=find(OUTPUT_Record(:,end)==min(OUTPUT_Record(:,end)));
%          i=find(Below_Voltage==temp_i(1,1));
        if Adj_Q
            %Find the node that has the greatest effect on the node voltage
            [numof_PV_inventor]=find(  abs(M_V_Rank(Below_Voltage(i),Pos_In_OutPut.Pos_Q_in_Inventer))==max(abs(M_V_Rank(Below_Voltage(i),Pos_In_OutPut.Pos_Q_in_Inventer))) );
        end
        if length(numof_PV_inventor)>1 ||Adj_T
            % numof_PV_inventor>1 means that all the elements of Matrix Senstive_M is 0,there are 0 of the reactive power capacity PV inventer
            if Adj_Input(Pos_In_OutPut.Pos_TransTab,1)>min(Pos_In_OutPut.Transformer_Tab)
                Adj_Input(Pos_In_OutPut.Pos_TransTab,1)=Adj_Input(Pos_In_OutPut.Pos_TransTab,1)-Device_Info.Transformer_Tab_Step;
                Adj_Input(1:Pos_TransTab-1,1)=Input_controled(1:Pos_TransTab-1,1);
                Adj_T=0;
                M_V_Rank=Senstive_M;
                break
            end
            
        end
        
        %% Determine the direction of sensitivity
        if M_V_Rank(Below_Voltage(i),Pos_In_OutPut.Pos_PV_P_Inventer_Start+numof_PV_inventor)>=0
            B_postive=1;
        else
            B_postive=-1;
        end
        %!!!!!!!!!!!!!!!!!
        B_postive=1;
        %%
        if (Adj_Input(Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)^2+Adj_Input(Pos_In_OutPut.Pos_PV_P_Inventer_Start+numof_PV_inventor,1)^2)<Device_Info.INclude_PV_S(numof_PV_inventor)^2 %后续补充调节容量约束
            Adj_Input(Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)=Adj_Input(Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)+B_postive*AdjStep.adjust_Q_step;
        else
            M_V_Rank(:,Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor)=0;
            %Number of PV bus that have used up reactive power: sum_of_PV_outRange_S
            sum_of_PV_outRange_S=sum_of_PV_outRange_S+1; 
            if sum_of_PV_outRange_S==length(Below_Voltage)
                %All of PV nodes that have used up reactive power
                if Device_Info.Transformer_Tab_state
                    Adj_T=1; % It need to adjust the Transformer Tab
                end
            end
        end
        
    end
    Lifted_Output_Test_Compelet = Lift_Vector_Complete(Adj_Input,rbf_type,cent_input_compelete);
    KPM_Output=M_V*Lifted_Output_Test_Compelet;
    OUTPUT_Record=[OUTPUT_Record,KPM_Output];
    INPUT_Record=[INPUT_Record,Adj_Input];
    Below_Voltage=find(KPM_Output<=Voltage.min);
end


end

