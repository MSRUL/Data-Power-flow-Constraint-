function [Result_OPT_KPM,M_Matrix] = Cplex_KPM7_Opt_Only_PV_Q(Input,M_Incompelet,Pos_Info,IDL_Peremeters,Constraint,Objective_Info)
% ZYX %Use the Koopman to Tranning the M Matrix. (In this Part , The Dimension of Control Variable is not Lifted)
% Use the Matrix M to Optimazition by the CPLEX
% Cplex_KPM2_Opt_Only_PV_Q: Only the Reactive Power of Photovoltaic is Unlifted

%% Fixed Parameters
% Pos_OutPut.RisePos;
% Un_RisePos=Find_Wihtout_Which([1:RisePos.input_num],Pos_OutPut.RisePos); % Position of the Unrised Vector 【Control Variable】
%%
Constraint.PVinverter_P; %MW
Constraint.PVinverter_Q; %MVar
Constraint.P_Load; %MW
Constraint.Q_Load; %MVar
Constraint.INclude_PV_node;
Constraint.INclude_PV_S;
Constraint.Voltage;
%% Variables
PV_P= sdpvar(length(Pos_Info.Pos_P_in_Inventer),1);
Optm_Variables = sdpvar(length(Pos_Info.Un_RisePos),1);
PV_Q=Optm_Variables;
Vm_PQ = sdpvar(length(Pos_Info.pq),1);
P_Loss = sdpvar(1,1);
%% 【！！！！】The lifted variable is  No need to specifically set constraints!!
%% 【！！！！】The lifted variable is  No need to specifically set constraints!!
%% 【！！！！】The lifted variable is  No need to specifically set constraints!!
%%
% Input_temp=Lift_Dem_Fun_Tradi_2(Input,'polyharmonic',cent_input_incompelet,Pos_Info.RisePos);
Input_lifted_temp = Lift_Vector_Incomplete_Total(Input,IDL_Peremeters);
Input_temp=Input_lifted_temp.Input_Lifted;

% temp1=M_Incompelet*Input_temp;hold on;plot(temp1(1:end-1));
Inout_temp_to_Rise=Input_temp(1+size(IDL_Peremeters.cent,2)+size(Pos_Info.RisePos,2):end);
%% Constraints

%% (1)Koopman PF 
Num_FirstPart=size(IDL_Peremeters.cent,2)+size(Pos_Info.RisePos,2);
M11=M_Incompelet(1:length(Pos_Info.pq),1:Num_FirstPart);  % Optimization variable
M12=M_Incompelet(1:length(Pos_Info.pq),1+Num_FirstPart:length(Input_temp)); %Other lifting dimension variables
M_Matrix.M11=M11;
M_Matrix.M12=M12;

% ------------------temp test---------start
% Vm_PQ_test=M11*Input(Pos_Info.Pos_P_in_Inventer,1)+M12*Input(Pos_Info.Pos_Q_in_Inventer,1)+M13*Inout_temp_to_Rise;
% figure;plot(Vm_PQ_test);
% ------------------temp test---------end
Constraints=[];


Constraints=[Constraints;Vm_PQ==M11*Inout_temp_to_Rise*IDL_Peremeters.M_Asstence*Optm_Variables+M12*Inout_temp_to_Rise];
if strcmp(Objective_Info.type,'Min Loss')||strcmp(Objective_Info.type,'Hybrid')
    M21=M_Incompelet(1+length(Pos_Info.pq),1:length(Pos_Info.Un_RisePos));
    M22=M_Incompelet(1+length(Pos_Info.pq),1+length(Pos_Info.Un_RisePos):length(Input_temp));
    M_Matrix.M21=M21;
    M_Matrix.M22=M22;
    Constraints=[Constraints;P_Loss==M21*Optm_Variables+M22*Inout_temp_to_Rise];
end
Constraints=[Constraints;ones(length(Pos_Info.pq),1)*Constraint.Voltage.min<=Vm_PQ <=ones(length(Pos_Info.pq),1)*Constraint.Voltage.max];

%% (2)PV Inverter Output Constraint
PV_Q_Limit_Rate=1;
PVinverter_P=Input(Pos_Info.Pos_P_in_Inventer);
for i=1:size(PV_Q,1)
    Constraints=[Constraints; norm([PVinverter_P(i,1);PV_Q(i,1)])<=Constraint.INclude_PV_S(i,1)];  %PV inverter Active Power Up limint
    Constraints=[Constraints; abs(PV_Q(i,1))<=Constraint.INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Active Power Up limint
    %% 【！！！！】PV_P is the lifted variable, so it is the fixed, No need to specifically set constraints!!
end
%% Objective

Objective_Info.Hybrid_Index=[1,1];
switch Objective_Info.type
    case 'Min Loss'
        objective=P_Loss;
    case 'Min Adjustment'
        objective=sum(abs(PV_Q-Constraint.PVinverter_Q)); %
    case 'Hybrid'
        objective=Objective_Info.Hybrid_Index(1)*P_Loss+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q));
    case 'Min_Voltage_deviation_rate'
         objective=sum(abs(Objective_Info.Voltage_Tatget-Vm_PQ));
    case 'Min_VDR_and_Min_Adj'
        objective=Objective_Info.Hybrid_Index(1)*sum(abs(Objective_Info.Voltage_Tatget-Vm_PQ))+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q));
end

varargout=optimize(Constraints,objective);
varargout.info

%% Output
temp=value(Optm_Variables);
Result_OPT_KPM.PV_P=PVinverter_P;
Result_OPT_KPM.PV_Q=value(PV_Q);
Result_OPT_KPM.Vm_PQ=value(Vm_PQ);
Result_OPT_KPM.P_Loss=value(P_Loss);
Result_OPT_KPM.PV_Q_Adj=value(PV_Q)-Input(Pos_Info.Pos_Q_in_Inventer);
Result_OPT_KPM.PV_P_Adj=value(PV_P)-Input(Pos_Info.Pos_P_in_Inventer);
Result_OPT_KPM.objective=value(objective);
Result_OPT_KPM.Opt_Info=varargout.info;
%% Check

%% Adheusted  （o change in the parameters here, just to unify the format with it）
M_Matrix.M11_AfterAdj=M11;
M_Matrix.M12_AfterAdj=M12;
if strcmp(Objective_Info.type,'Min Loss')||strcmp(Objective_Info.type,'Hybrid')
    M_Matrix.M21_AfterAdj=M21;
    M_Matrix.M22_AfterAdj=M22;
end
end

