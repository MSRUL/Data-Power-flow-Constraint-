function [Record] = SensiAdj_OverVoltage_KPM(case_name,M_V,Senstive_M,Input_Standard,Output_KPM,Device_Info,Pos_In_OutPut,AdjStep,Voltage,rbf_type,cent_input_compelete)
%SensiAdj_OverVoltage_KPM   Use Koopman Mapping Matrix and Sensitive Matrix to control the Voltage control
%%

%%
Device_Info.INclude_PV_S;
Device_Info.INclude_PV_node;
AdjStep.TransTab_step;
AdjStep.TransTab_step.max=max(Device_Info.Transformer_Tab);
AdjStep.TransTab_step.min=min(Device_Info.Transformer_Tab);

AdjStep.adjust_P_step;
AdjStep.adjust_Q_step;
Pos_In_OutPut.Pos_P_in_Inventer;
Pos_In_OutPut.Pos_Q_in_Inventer;

%%
Over_Voltage=find(Output_KPM>Voltage.max); % The Vm only include the PQ bus!!
Below_Voltage=find(Output_KPM<Voltage.min);
%%
INPUT_Record=[];INPUT_Record_B=[];INPUT_Record_O=[];
if ~(isempty(Over_Voltage)&&isempty(Below_Voltage))
    Input_controled=Input_Standard;
    if length(Below_Voltage)
        [INPUT_Record_B,OUTPUT_Record_B] = Senstive_KPM_Voltage_Control(Input_controled,M_V,Senstive_M,Below_Voltage,AdjStep,rbf_type,cent_input_compelete,Voltage,Device_Info,Pos_In_OutPut);
        Input_controled=INPUT_Record_B(:,end);
        AdjStep.TransTab_step.max=Input_controled(Pos_In_OutPut.Pos_TransTab);
        INPUT_Record=INPUT_Record_B;
        Output_Record=OUTPUT_Record_B;
    end
    if length(Over_Voltage)>0
        %             [OUTPUT_Record,INPUT_Record_O,Senstive_M_Record] = Senstive_KPM_OverVoltage_Control(Input_controled,case_name,pq,pv,INclude_PV_S,INclude_PV_node_Pos,M_V,Senstive_M,Over_Voltage,TransTab_step,cent_input,adjust_Q_step,adjust_P_step,KPM_Output,Voltage);
        if ~length(INPUT_Record)
            INPUT_In=Input_Standard;
            OUTPUT_In=Output_KPM;
        else
            INPUT_In=INPUT_Record_B(:,end);
            OUTPUT_In=OUTPUT_Record_B(:,end);
        end
%         [INPUT_Record_O,OUTPUT_Record_O] = Senstive_KPM_OverVoltage_Control_test(INPUT_In,OUTPUT_In,M_V,Senstive_M,Over_Voltage,AdjStep,rbf_type,cent_input_compelete,Voltage,Device_Info,Pos_In_OutPut);
        [INPUT_Record_O,OUTPUT_Record_O] = Senstive_KPM_OverVoltage_Control_modified(INPUT_In,OUTPUT_In,M_V,Senstive_M,Over_Voltage,AdjStep,rbf_type,cent_input_compelete,Voltage,Device_Info,Pos_In_OutPut);
        Input_controled=INPUT_Record_O(:,end);
        
        if ~length(INPUT_Record)
            INPUT_Record=INPUT_Record_O;
            Output_Record=OUTPUT_Record_O;
        else
            INPUT_Record=[INPUT_Record_B,INPUT_Record_O];
            Output_Record=[OUTPUT_Record_B,OUTPUT_Record_O];
        end
        
    end

%     plot(OUTPUT_Result+mean(Output_Standard.Vm-OUTPUT_Result));
%     title('调整电压后结果')
%     
%     [Print_Item,Info] = Print_Chinese_Words(Input_controled,Input_Standard,INclude_PV_node,Pos_In_OutPut);
%     fprintf('%s\n%s\n%s\n', Print_Item.str_PV_Q, Print_Item.str_Tras_Tab,Print_Item.str_PV_P);
%     
%     Input_controled_Lifted=Lift_Dem_Fun_Tradi(Input_controled,'polyharmonic',cent_input);
%     KPM_Output_Ploss=M_Ploss*Input_controled_Lifted;
%     fprintf('网损%s\n',KPM_Output_Ploss);
%     
%     
%    
%     figure;plot(INPUT_Record(:,end)-INPUT_Record(:,1));title('调节量');
else
    fprintf('电压合格无需调整\n');
    INPUT_Record=[];
    Output_Record=[];
end
Record.INPUT_Record=INPUT_Record;
Record.Output_Record=Output_Record;

end

