function [Sens_Matrix] = Cal_Sens_by_PFderivation(Data,M,DLR_Parameter)
% ZYX 20220421 obtain the sensitivity by derivation of the power flow equation


Sens_Matrix=zeros(size(Data.Output,1),size(Data.Input,1),size(Data.Input,2));

[~,X_state] = Cal_xs_PFDerivation(Data.Input,Data.Input,DLR_Parameter);
for i =1:size(Data.Input,2)
    Sens_Matrix(:,:,i)=M*X_state(:,:,i);
end


end