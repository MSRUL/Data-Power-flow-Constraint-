function [Sens_P2V,Sens_Q2V] = Cal_Sens(results_NR)
%UNTITLED2 此处提供此函数的摘要
%   此处提供详细说明
[~, ~, pq] = bustypes(results_NR.bus, results_NR.gen);
Sens_P2V=zeros(length(pq),length(pq));
Sens_Q2V=zeros(length(pq),length(pq));

[Ybus] = makeYbus(results_NR);


for i =1:length(pq)
    for j =1:length(pq)
        % dUj/dPi
        Sens_P2V(j,i)=1/(  results_NR.bus(pq(i),8)*(   real( Ybus(pq(i),pq(j)))*cos(results_NR.bus(pq(i),9)-results_NR.bus(pq(j),9))+...
            imag( Ybus(pq(i),pq(j)))*sin(results_NR.bus(pq(i),9)-results_NR.bus(pq(j),9))   )  );
        % dUj/dQi
        Sens_Q2V(j,i)=1/(  results_NR.bus(pq(i),8)*(   real( Ybus(pq(i),pq(j)))*sin(results_NR.bus(pq(i),9)-results_NR.bus(pq(j),9))-...
            imag( Ybus(pq(i),pq(j)))*cos(results_NR.bus(pq(i),9)-results_NR.bus(pq(j),9))   )  );
    end
end

end