function [Result_CPLEX] = CPLEX_DDLPF_Optimization(Constraint,Objective_Info)
%UNTITLED5 '数据驱动潮流优化计算'《Data-driven power flow linearization: A regression approach》
%   此处显示详细说明
%% Init Parameters
M_DDLPF=Constraint.M_DDLPF;
Pos_In_OutPut=Constraint.Pos_In_OutPut;
Input_temp=Constraint.Input_temp;
Device_Info=Constraint.Device_Info;
Voltage=Constraint.Voltage;
%------Case Info----------
baseMVA=Pos_In_OutPut.baseMVA;
pq=Pos_In_OutPut.pq;
pv=Pos_In_OutPut.pv;
ref=Pos_In_OutPut.ref;
Bus_Num=Pos_In_OutPut.Bus_Num;
PV_Num=Pos_In_OutPut.PV_Num;
Device_Info.INclude_PV_S;

P_Load=[0;Input_temp(Pos_In_OutPut.Pos_P_Load)];% The first 0 is Power injection of Ref Bus
Q_Load=[0;Input_temp(Pos_In_OutPut.Pos_Q_Load)];
PVinverter_P=Input_temp(Pos_In_OutPut.Pos_P_in_Inventer);
PVinverter_Q=Input_temp(Pos_In_OutPut.Pos_Q_in_Inventer);
Vm_ref=Input_temp(Pos_In_OutPut.Pos_RefBus );

%% DDLPF Parameters
X_Line=[M_DDLPF.XPL(:,1:2*Bus_Num);M_DDLPF.XQL(:,1:2*Bus_Num)];
C_Line = [M_DDLPF.XPL(:,2*Bus_Num + 1);M_DDLPF.XQL(:,2*Bus_Num + 1)];

X11 = [M_DDLPF.XVa([pq; pv; ref], [pq; pv; ref; pq + Bus_Num]);...
    M_DDLPF.XVm(pq, [pq; pv; ref; pq + Bus_Num])]; %Already Known injection power Parts
X12 = [M_DDLPF.XVa([pq; pv; ref], [pv; ref] + Bus_Num);...
    M_DDLPF.XVm(pq, [pv; ref] + Bus_Num)];% The Reactive Bus of PV ,Ref bus Parts
X21 = M_DDLPF.XVm([pv; ref], [pq; pv; ref; pq + Bus_Num]);
X22 = M_DDLPF.XVm([pv; ref], [pv; ref] + Bus_Num);
C1 = [M_DDLPF.XVa([pq; pv; ref],2*Bus_Num + 1);M_DDLPF.XVm(pq,2*Bus_Num + 1)];
C2 = M_DDLPF.XVm([pv; ref],2*Bus_Num + 1);
%%
PV_P= sdpvar(PV_Num,1);
PV_Q = sdpvar(PV_Num,1);
Vm = sdpvar(Bus_Num,1);
V_temp = sdpvar(Bus_Num*2-1,1);
P_Inj = sdpvar(Bus_Num,1);
Q_Inj = sdpvar(Bus_Num,1);
%%
Constraints=[];
for i=1:Bus_Num
    if ismember(i,Device_Info.INclude_PV_node)
        pos_PV_num=find(Device_Info.INclude_PV_node==i);
        Constraints=[Constraints;P_Inj(i,1)==-P_Load(i,1)/baseMVA+PV_P(pos_PV_num,1)/baseMVA];
        Constraints=[Constraints;Q_Inj(i,1)==-Q_Load(i,1)/baseMVA+PV_Q(pos_PV_num,1)/baseMVA];
    else
         Constraints=[Constraints;P_Inj(i,1)==-P_Load(i,1)/baseMVA];
         Constraints=[Constraints;Q_Inj(i,1)==-Q_Load(i,1)/baseMVA];
    end
end

%% DDLPF Voltage Calculation---------------
% a1=[P_Inj([pq; pv; ref],1);Q_Inj(pq,1)];%The Already Known injection power
% a2 = X22 \ (Y2 - X21 * a1 - C2);% Calculate the Reactive Bus of PV ,Ref bus.
% Y1 = X11 * a1 + X12 * a2 + C1;
Y2=Vm_ref;
Constraints=[Constraints;V_temp == X11 * [P_Inj([pq; pv; ref],1);Q_Inj(pq,1)] + X12 * (X22 \ (Y2 - X21 * [P_Inj([pq; pv; ref],1);Q_Inj(pq,1)] - C2)) + C1]; %a1 here is nonlinear
Constraints=[Constraints;Vm(ref) == Vm_ref];
Constraints=[Constraints;Vm(pq) == V_temp(Bus_Num + 1: Bus_Num + length(pq))];
Constraints=[Constraints;Voltage.min<=Vm(pq,1)<=Voltage.max];
%% Photovoltaic Inverter Power
for i=1:size(PV_P,1)
    PV_Q_Limit_Rate=1;
    if strcmp(Objective_Info.type,'DG_Consumption')||strcmp(Objective_Info.Opt_Variable,'Active_Power')
        Constraints=[Constraints; 0<=PV_P(i,1)<=PVinverter_P(i,1)];  %PV inverter Active Power limint
        Constraints=[Constraints; PV_Q(i,1)==PVinverter_Q(i,1)];  %PV inverter Active Power limint
        Constraints=[Constraints; norm([PV_P(i,1);PV_Q(i,1)])<=Device_Info.INclude_PV_S(1,i)];  %PV inverter Reactive Power limint
    else
        Constraints=[Constraints; PV_P(i,1)==PVinverter_P(i,1)];  %PV inverter Active Power limint
        Constraints=[Constraints; abs(PV_Q(i,1))<=Device_Info.INclude_PV_S(1,i)*PV_Q_Limit_Rate];  %PV inverter Reactive Power limint
        Constraints=[Constraints; norm([PV_P(i,1);PV_Q(i,1)])<=Device_Info.INclude_PV_S(1,i)];  %PV inverter Reactive Power limint
    end
end
%%
switch Objective_Info.type
    case 'Min Adjustment'
        switch Objective_Info.Opt_Variable
            case 'Reactive_Power'
                objective=sum(abs(PV_Q-PVinverter_Q)); %
            case 'Active_Power'
                objective=sum(abs(PV_P-PVinverter_P)); %
        end
    case 'Min_Voltage_deviation_rate'
         objective=sum(abs(Objective_Info.Voltage_Tatget-Vm));
    case 'Min_VDR_and_Min_Adj'
         objective=Objective_Info.Hybrid_Index(1)*sum(abs(Objective_Info.Voltage_Tatget-Vm))+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q-PVinverter_Q));
    case 'DG_Consumption'
        objective=-sum(abs(PV_P));
end
varargout=optimize(Constraints,objective);
varargout.info
%%
Result_CPLEX.PV_P=value(PV_P);
Result_CPLEX.PV_Q=value(PV_Q);
Result_CPLEX.Voltage=value(Vm);
Result_CPLEX.Vm_PQ=value(Vm(pq));

Result_CPLEX.objective=value(objective);

Result_CPLEX.PV_Q_Adj=value(PV_Q)-PVinverter_Q;
Result_CPLEX.PV_P_Adj=value(PV_P)-PVinverter_P;
Result_CPLEX.Ploss=[];
Result_CPLEX.Opt_Info=varargout.info;
Result_CPLEX.solvertime=varargout.solvertime;
end

