function [X_LM] = Lagrangian_Median_Value(X1,X2,Order)
%Fourth-order Lagrangian median theorem
%  四阶拉格朗日中值定理,求取切点位置
switch Order
    case 2
        X_LM = (X1+X2)/2;
    case 3
        X_LM = ((X1.^2+X1.*X2+X2.^2)/3).^(1/2);
    case 4
        X_LM = ((X1+X2).*(X1.^2+X2.^2)/4).^(1/3);
   case 5
        X_LM = ((X1.^4+X1.^3.*X2.^1+X1.^2.*X2.^2+X1.^1.*X2.^3+X2.^4)/5).^(1/4);
end
end

