function [Coefficient_Vector] = Opt_PlaneMapping(Xp_Train,InputVector)
%Through linear optimization calculation, the optimal combination of parameters

%%
Coefficient_Opt= sdpvar(size(Xp_Train,2),1);
Caled_Vector=sdpvar(size(InputVector,2),size(InputVector,1));

Constraint=[];
Constraint=[Constraint;Coefficient_Opt>=zeros(size(Coefficient_Opt))];
Constraint=[Constraint;sum(Coefficient_Opt)<=5];
Constraint=[Constraint;Caled_Vector==Coefficient_Opt'*Xp_Train'];

objective=sum(abs(InputVector-Caled_Vector'));

varargout=optimize(Constraint,objective);
varargout.info
%%
Coefficient_Vector=value(Coefficient_Opt);
end

