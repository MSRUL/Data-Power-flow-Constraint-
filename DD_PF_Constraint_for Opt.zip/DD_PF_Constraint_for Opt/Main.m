clear,clc
close all;
path_base = mfilename('fullpath');i=findstr(path_base,'\');path_base=path_base(1:i(end));
path_last = mfilename('fullpath');i=findstr(path_base,'\');path_last=path_last(1:i(end-1)); %此代码必须运行m文件执行

%%
Case_Name='IEEE33'; %'IEEE33'
Opt_Variable='Reactive_Power'; %'Active_Power' 'Reactive_Power'
IDL_Peremeters.type='IDL';  % 'IDL'  'IDL_QuaModified'
Objective_Info.type='Min Adjustment';  %'Min Adjustment''Min_Voltage_deviation_rate'
%%
case_name_or=case33bw;

%------------Generated Data Parameters--------------
Range=3.2;   % 3.2 In Letter Cases
New_Training_data=0;
training_data_file='1000组_Range3.2_Vm'; %Only New_Training_data==0

%------------Dimension Lifting Parameters-----------
num_inpuit=1000;   %Num of Training Data Sets--------
Nrbf1=10;  % dimension lifting number
Nrbf2=0; %input_num-output_num;
rbf_type='polyharmonic';rbf_type_Inverse='polyharmonic';

% --------Output Variable List----------------------
ItemName='';
TestItem.PQ_Vm=1;   if TestItem.PQ_Vm ;ItemName=strcat(ItemName,'Vm'); end

%% Init the Case Parameters
case_name_or_simp=Transfer_node_num_to_consecutive(case_name_or);  % Change the bus name to consecutive numbers
case_name=Transfer_node_num_to_consecutive(case_name_or);  % Change the bus name to consecutive numbers
Bus_Num=size(case_name.bus,1);
line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
Standard_result=runpf(case_name);
[ref,pv, pq,pv_pos,ref_pos,pv_total] = Case_Info(case_name);

%% Init the PhotoVoltak/CapacitorBank Parameters
HaveDG=1; %This Program default is 1(For the optimization)
[Device_Info] = Init_Device_Info(case_name,HaveDG);

%% Data Parameter
input_num=Device_Info.Input_Num;
test_input_num=input_num; %size(pq,1)*2+size(pv,1);
case_name.bus(pq,3:4)=0;
case_name.gen([pv_total;ref_pos],[2,6])=0;
num_test_input=max(num_inpuit*1.2,num_inpuit+1000);

%% Position of Variable in Input Vector
[Pos_In_OutPut] = Define_Pos_VariableVector(case_name,Device_Info,Bus_Num,Branch_Num);
%--------Additional Modification---------------------
Pos_In_OutPut.Un_RisePos=[Pos_In_OutPut.Pos_Q_in_Inventer];% Position of the Unrised Vector 【Control Variable】
Pos_In_OutPut.RisePos=Find_Wihtout_Which([1:input_num],Pos_In_OutPut.Un_RisePos); % Position of the Rised Vector 【State Variable】
Pos_In_OutPut.Pos_Input_Rise=length(Pos_In_OutPut.RisePos)+1:Pos_In_OutPut.input_num; %The Unreised Part of Input During the Process of maltiping the M.

%% Generate the Training Data
[Tranning_Range,Testing_Range] = Init_Training_Data_Range(Range);
if New_Training_data % Every time the program is executed,  the training data is randomly generated
    for i=1:2
        [Input,Output] = Generate_Tranning_OR_Testing_Data(input_num,test_input_num,num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,TestItem);
        Data.Input=Input;
        Data.Output=Output;
        save_data_path=strcat(path_base,'\PF_Training_Data\',num2str(num_inpuit),'组_Range',num2str(Range),'_',ItemName,'_no',num2str(i),'.mat');
        save(save_data_path,'Data');
    end
    training_data_file=strcat(path_base,'\PF_Training_Data\',num2str(num_inpuit),'组_Range',num2str(Range),'_',ItemName,'_no',num2str(1),'.mat');
else % Using the generated training data  (The last randomly generated data above)
    load(strcat(path_base,'\PF_Training_Data\',training_data_file,'.mat'));
end

%%
%% Koopman Matrix Calculate
IDL_Peremeters.rbf_type=rbf_type;
IDL_Peremeters.RisePos=Pos_In_OutPut.RisePos;
IDL_Peremeters.Un_RisePos=Pos_In_OutPut.Un_RisePos;
IDL_Peremeters.cent = Generate_Cent(IDL_Peremeters,Nrbf1);
IDL_Peremeters.type;
IDL_Peremeters.M_Asstence=rand(1,length(Pos_In_OutPut.Un_RisePos));

Train_Ops.way='LS_OR';
Train_Ops.Beita=0.1;
Train_Ops.M_Type=1; % Default

%% The Training Parts
switch IDL_Peremeters.type % 'IDL' 'IDL_QuaModified'
    case 'IDL'
        [M_Incompelet,M_Struct,M_Output] = Cal_KMP_Total(Data,IDL_Peremeters,Train_Ops);
    case 'IDL_QuaModified'
        [M_Incompelet,M_Struct,M_Output] = Cal_KMP_Total_QS(Data,IDL_Peremeters,Train_Ops);
end

%% Test case Number
Runtimes=200;

%% ---------------Rolling Test Accuracy-1-------------------------
Result_Opted.data=zeros(Runtimes,2);
Result_Opted.error_info=cell(Runtimes,1);
Result_Opted.Value_objective=zeros(Runtimes,1);
Result_Opted.OptResults.V_PQ_Cal=zeros(length(pq),Runtimes);
Result_Opted.OptResults.V_PQ_Check=zeros(length(pq),Runtimes);
Result_Opted.OptResults.Q_adj=zeros(length(Pos_In_OutPut.Pos_Q_in_Inventer),Runtimes);
Result_Opted.solve_time=zeros(Runtimes,1);

for i_time_count=1:Runtimes
    fprintf('\nSolving the No. %d snapshot',i_time_count);

    %% Generate test examples randomly
    % ±100% Random Load Fluctuations 
    % Random Active power of DG
    
    Test_case_NewGenerat=0; % 1: generate new case every time, 
    if Test_case_NewGenerat % Every time the program is executed,  the test case is randomly generated
        [Input_Standard] = Generate_Standard_Case_Vector(case_name_or_simp,Device_Info,'RAND_Num');
        LoadinCase_Info.case_chose='New Generated Case';
    else % Use the generated case
        temp=load(strcat(path_base,'Case_to_Opt\OverVoltageCaseInput_No',num2str(i_time_count),'.mat'));
        Input_Standard=temp.Input_Standard;
    end

    % All the cases are regenerated, and the results may be different from the original, but they are basically at the same level

    %% Case Basic Analyze
    [Output_NR,Input_NR,casename_NR,results_NR]=NR_PF_Cal(case_name,Input_Standard,Device_Info);
    [Output_Test_Incompelet] = Case_PF_Accuracy_Test(IDL_Peremeters,M_Incompelet,M_Struct,Input_Standard);

    %%
    Constraint.PVinverter_P=Input_Standard(Pos_In_OutPut.Pos_P_in_Inventer,1)*1; %MW
    Constraint.PVinverter_Q=Input_Standard(Pos_In_OutPut.Pos_Q_in_Inventer,1)*1; %MW
    Constraint.P_Load=[0;Input_Standard(Pos_In_OutPut.Pos_P_Load,1)]*1;
    Constraint.Q_Load=[0;Input_Standard(Pos_In_OutPut.Pos_Q_Load,1)]*1;
    Constraint.INclude_PV_node=Device_Info.INclude_PV_node;
    Constraint.INclude_PV_S=Device_Info.INclude_PV_S';%MVA
    Constraint.Voltage.max=1.05;
    Constraint.Voltage.min=0.95;
    Objective_Info.Voltage_Tatget=ones(size(pq,1),1)*results_NR.gen(1,6);

    switch IDL_Peremeters.type
        case 'IDL'
            [Result_OPT_KPM,M_Matrix] = Cplex_KPM2_Opt_Only_PV_Q(Input_Standard,M_Incompelet,Pos_In_OutPut,IDL_Peremeters ,Constraint,Objective_Info);
        case 'IDL_QuaModified'
            [Result_OPT_KPM,M_Matrix] = Cplex_KPM4_Opt_Only_PV_Q_bothPQ(Input_Standard,M_Incompelet,Pos_In_OutPut,IDL_Peremeters ,Constraint,Objective_Info);
    end

    %% ---------------Opt Results Check--------------
    input_temp=Input_Standard;
    input_temp([Pos_In_OutPut.Pos_P_in_Inventer,Pos_In_OutPut.Pos_Q_in_Inventer],1)=[Result_OPT_KPM.PV_P;Result_OPT_KPM.PV_Q];
    [~,~,~,results_NR_AfterAdj]=NR_PF_Cal(case_name,input_temp,Device_Info);
    Result_OPT_KPM.Vm_PQ_NRCheck=results_NR_AfterAdj.bus(pq,8);
    %% ---------------Rolling Test Accuracy--2------------------------
    fprintf('\n Adjustment Error： Average: %f ;  Maximum: %f',mean(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8))),...
        max(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8))));
    Result_Opted.data(i_time_count,1)=mean(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8)));
    Result_Opted.data(i_time_count,2)=max(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8)));
    Result_Opted.error_info{i_time_count,1}=Result_OPT_KPM.Opt_Info;
    Result_Opted.Value_objective(i_time_count,1)=Result_OPT_KPM.objective;
    Result_Opted.OptResults.V_PQ_Cal(:,i_time_count)=Result_OPT_KPM.Vm_PQ;
    Result_Opted.OptResults.V_PQ_Check(:,i_time_count)=Result_OPT_KPM.Vm_PQ_NRCheck;
    Result_Opted.OptResults.Q_adj(:,i_time_count)=Result_OPT_KPM.PV_Q_Adj;
    Result_Opted.OptResults.P_adj(:,i_time_count)=Result_OPT_KPM.PV_P_Adj;
    Result_Opted.solve_time(i_time_count,1)=Result_OPT_KPM.solvertime;

end

CaseID_Solveable = Judge_Solveable_Cell(Result_Opted.error_info); % Some randomly generated cases have no solution, should  not collected
fprintf('\n AE:%f ,ME: %f ',mean(Result_Opted.data(CaseID_Solveable,1)),max(Result_Opted.data(CaseID_Solveable,2)))










