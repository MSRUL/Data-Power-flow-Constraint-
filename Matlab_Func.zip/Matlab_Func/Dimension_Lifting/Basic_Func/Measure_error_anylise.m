function [temp_Vm1,temp_Va1,temp_Pl1,temp_Ql1] = Measure_error_anylise(Result1)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
% Result1=Result_invmultquad_2000in_400LD_IEEE118;
Result_num=size(Result1,2);
temp_Vm=zeros(size(Result1(1,1).E_absolute_mean_Vm,1),size(Result1,2));
temp_Va=zeros(size(Result1(1,1).E_absolute_mean_Va,1),size(Result1,2));
temp_Pl=zeros(size(Result1(1,1).E_relative_mean_PL,1),size(Result1,2));
temp_Ql=zeros(size(Result1(1,1).E_relative_mean_QL,1),size(Result1,2));
temp_Vm_Max=0;
temp_Va_Max=0;
temp_Pl_Max=0;
temp_Ql_Max=0;

for i=1:Result_num
    temp_Vm(:,i)=Result1(1,i).E_absolute_mean_Vm;
    temp_Va(:,i)=Result1(1,i).E_absolute_mean_Va;
    temp_Pl(:,i)=Result1(1,i).E_relative_mean_PL;
    temp_Ql(:,i)=Result1(1,i).E_relative_mean_QL;
end

for i=1:size(temp_Vm,1)
    temp_pos=find(temp_Vm(i,:)==max(temp_Vm(i,:)));
    temp_Vm(i,temp_pos)=0;
    temp_pos=find(temp_Va(i,:)==max(temp_Va(i,:)));
    temp_Va(i,temp_pos)=0;
    temp_pos=find(temp_Pl(i,:)==max(temp_Pl(i,:)));
    temp_Pl(i,temp_pos)=0;
    temp_pos=find(temp_Ql(i,:)==max(temp_Ql(i,:)));
    temp_Ql(i,temp_pos)=0;
end


temp_Vm1=sum(temp_Vm')/(size(temp_Vm,2)-1);
temp_Va1=sum(temp_Va')/(size(temp_Va,2)-1);
temp_Pl1=sum(temp_Pl')/(size(temp_Pl,2)-1);
temp_Ql1=sum(temp_Ql')/(size(temp_Ql,2)-1);
end

