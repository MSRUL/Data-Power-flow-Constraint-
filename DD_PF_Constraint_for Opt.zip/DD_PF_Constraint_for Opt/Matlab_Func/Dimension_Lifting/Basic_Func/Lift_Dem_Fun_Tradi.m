function [outputArg1] = Lift_Dem_Fun_Tradi(inputArg1,rbf_type,cent)
%ZYX 20220415
    outputArg1=( [inputArg1;rbf_self_use(inputArg1,cent,rbf_type)] );
end

