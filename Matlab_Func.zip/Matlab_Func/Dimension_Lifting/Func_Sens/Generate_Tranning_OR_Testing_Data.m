function [Input_KPM,Output_KMP,Data_DDLPF] = Generate_Tranning_OR_Testing_Data(input_num,test_input_num,num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,Measure_Noise,TestItem)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明


%%
input_Cbank=Device_Info.input_Cbank;
Transformer_Tab=Device_Info.Transformer_Tab;
INclude_PV_node_Pos=Device_Info.INclude_PV_node_Pos;
INclude_PV_S=Device_Info.INclude_PV_S;
%%

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;
pos_gen_p=2;
pos_gen_v=6;
Bus_Num=size(case_name.bus,1);
line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
%%
% input_Cbank=temp_range_input_Cbank/1000;
temp_range_input_Cbank_num=length(input_Cbank);
temp_range_input_TransTab_num=length(Transformer_Tab);

%%  Data of KPM DD_PF
Input_KPM=zeros(input_num,num_inpuit);
num=num_inpuit;

Input_KPM(1:length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_P_M+Tranning_Range.PQ_P_B).*case_name_or_simp.bus(pq,3);
switch Tranning_Range.Q_Load_Mode
    case 'fai' %Determine Q by the known P and rand fai
        Input_KPM(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_Q_M+Tranning_Range.PQ_Q_B).*Input_KPM(1:length(pq),:);

    case 'Q' % Determine the Q directly
        Input_KPM(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_Q_Direc_M+Tranning_Range.PQ_Q_Direc_B).*case_name_or_simp.bus(pq,4);
end
for i=1:length(pv)
    Input_KPM(2*length(pq)+i,:)=(rand(1,num)*Tranning_Range.PV_P_M+Tranning_Range.PV_P_B)*sum(case_name_or_simp.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
    %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
    Input_KPM(2*length(pq)+length(pv)+i,:)=case_name_or_simp.gen( pv_pos(i,1),6)*(rand(1,num)*Tranning_Range.PV_V_M+Tranning_Range.PV_V_B);
end
Input_KPM(2*length(pq)+2*length(pv)+1,:)=case_name_or_simp.gen( ref_pos,6)*(rand(1,num)*Tranning_Range.REF_V_M+Tranning_Range.REF_V_B);
temp_C_bank=ceil(rand(1,num)*temp_range_input_Cbank_num);
if Device_Info.input_Cbank_state
    Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state,:)=-input_Cbank(temp_C_bank);
end
if length(INclude_PV_S)>0
    temp_PV_P_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_P_M+Tranning_Range.PhotoVoltake_P_B).*INclude_PV_S';
    temp_S=ones(size(temp_PV_P_Out)).*INclude_PV_S';
    max_temp_PV_Q_Out=sqrt(temp_S.^2-temp_PV_P_Out.^2);
    Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S),:)=temp_PV_P_Out;
    temp_PV_Q_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_Q_M+Tranning_Range.PhotoVoltake_Q_B).*INclude_PV_S';
    temp_PV_Q_Out=min(temp_PV_Q_Out,max_temp_PV_Q_Out); % limit the Inverter Q power to fit the total S limit
    Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2,:)=temp_PV_Q_Out;
end
temp_TransTab=ceil(rand(1,num)*temp_range_input_TransTab_num);
if Device_Info.Transformer_Tab_state
    Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state,:)=Transformer_Tab(temp_TransTab);
end
%%  Data of DD_LPF 《Data-driven power flow linearization: A regression approach》
Data_DDLPF.P_injection=zeros(Bus_Num,num_inpuit);
Data_DDLPF.Q_injection=zeros(Bus_Num,num_inpuit);
Data_DDLPF.Vm=zeros(Bus_Num,num_inpuit);
Data_DDLPF.Va=zeros(Bus_Num,num_inpuit);
Data_DDLPF.PL=zeros(Branch_Num,num_inpuit);
Data_DDLPF.QL=zeros(Branch_Num,num_inpuit);
Data_DDLPF.PLoss=zeros(1,num_inpuit);
%%
% Output=zeros(output_num,num);
SS=[];

for i=1:num
    temp_iptpq_p=Input_KPM(1:length(pq),i);
    temp_iptpq_q=Input_KPM(length(pq)+1:2*length(pq),i);
    if length(INclude_PV_node_Pos)>0
        temp_iptpq_p(INclude_PV_node_Pos)=temp_iptpq_p(INclude_PV_node_Pos)-Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S),i);
        temp_iptpq_q(INclude_PV_node_Pos)=temp_iptpq_q(INclude_PV_node_Pos)-Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2,i);
    end
    temp_iptpv_p=Input_KPM(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input_KPM(2*length(pq)+length(pv)+1:2*length(pq)+2*length(pv),i);
    temp_iptref_v=Input_KPM(2*length(pq)+2*length(pv)+1,i);
    
    
    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,6)=temp_iptref_v;
    
    
    if Device_Info.input_Cbank_state
        temp_C_bank=Input_KPM(2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state,i);
    case_name.bus(ref,4)=temp_C_bank;
    end
    if Device_Info.Transformer_Tab_state
        temp_TranTab=Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state,i);
        case_name.branch(1,9)=temp_TranTab;
    end
    
    [result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    output1=result.bus(pq,8);
    output2=result.branch(line_active,14);
    output3=result.branch(line_active,15);
    output4=result.bus(pq,9);
    output5=result.bus(pv,9);
    output_PLOSS=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));
    
    %     Output(:,i)=[output1;output2;output3;output4;output5;output_PLOSS];
    %     Output(:,i)=[output1;output_PLOSS];
    
    output_temp=[];
  
    if TestItem.PQ_Vm
        output_temp=[output_temp;output1];
    end
    if TestItem.Va
        output_temp=[output_temp;output4;output5];
    end
    if TestItem.LP
        output_temp=[output_temp;output2];
    end
    if TestItem.LQ
        output_temp=[output_temp;output3];
    end
    if TestItem.PLoss
        output_temp=[output_temp;output_PLOSS];
    end

    Output_KMP(:,i)=output_temp;
    %% DDLPF Data (Not distinguish the input and output)
%     [MVAbase, bus, gen, ~] = runpf(result);
    Sbus = makeSbus(result.baseMVA,result.bus, result.gen);
    Data_DDLPF.P_injection(:,i)=real(Sbus);
    Data_DDLPF.Q_injection(:,i)=imag(Sbus);
    Data_DDLPF.Vm(:,i)=result.bus(:,8);
    Data_DDLPF.Va(:,i)=result.bus(:,9);
    Data_DDLPF.PL(:,i)=result.branch(line_active,14);
    Data_DDLPF.QL(:,i)=result.branch(line_active,15);
    Data_DDLPF.PLoss(:,i)=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));
end
%% Only keep the results of power flow convergence
Input_KPM=Input_KPM(1:test_input_num,SS);
Output_KMP=Output_KMP(:,SS);
%--------Add Measure Noise --------------
input_nosise_rate=rand(size(Input_KPM))*Measure_Noise.range+(1-Measure_Noise.range/2);
output_nosise_rate=rand(size(Output_KMP))*Measure_Noise.range+(1-Measure_Noise.range/2);
if Measure_Noise.state.input % Add measure noise in input
    Input_KPM=Input_KPM.*input_nosise_rate;
end
if Measure_Noise.state.output % Add measure noise in output
    Output_KMP=Output_KMP.*output_nosise_rate;
end

%--------Add Measure Noise --------------
temp_nosise_rate_P=rand(size(Data_DDLPF.P_injection(:,SS)))*Measure_Noise.range+(1-Measure_Noise.range/2);% Add Measure Noise
temp_nosise_rate_Q=rand(size(Data_DDLPF.Q_injection(:,SS)))*Measure_Noise.range+(1-Measure_Noise.range/2);
temp_nosise_rate_Vm=rand(size(Data_DDLPF.Vm(:,SS)))*Measure_Noise.range+(1-Measure_Noise.range/2);
temp_nosise_rate_Va=rand(size(Data_DDLPF.Va(:,SS)))*Measure_Noise.range+(1-Measure_Noise.range/2);
temp_nosise_rate_PL=rand(size(Data_DDLPF.PL(:,SS)))*Measure_Noise.range+(1-Measure_Noise.range/2);
temp_nosise_rate_QL=rand(size(Data_DDLPF.QL(:,SS)))*Measure_Noise.range+(1-Measure_Noise.range/2);
temp_nosise_rate_Ploss=rand(size(Data_DDLPF.PLoss(:,SS)))*Measure_Noise.range+(1-Measure_Noise.range/2);

if Measure_Noise.state.input  % Add measure noise in input
    Data_DDLPF.P_injection=Data_DDLPF.P_injection(:,SS).*temp_nosise_rate_P;% Add Measure Noise
    Data_DDLPF.Q_injection=Data_DDLPF.Q_injection(:,SS).*temp_nosise_rate_Q;
end
if Measure_Noise.state.output % Add measure noise in output
    Data_DDLPF.Vm=Data_DDLPF.Vm(:,SS).*temp_nosise_rate_Vm;
    Data_DDLPF.Va=Data_DDLPF.Va(:,SS).*temp_nosise_rate_Va;
    Data_DDLPF.PL=Data_DDLPF.PL(:,SS).*temp_nosise_rate_PL;
    Data_DDLPF.QL=Data_DDLPF.QL(:,SS).*temp_nosise_rate_QL;
    Data_DDLPF.PLoss=Data_DDLPF.PLoss(:,SS).*temp_nosise_rate_Ploss;
end
end

