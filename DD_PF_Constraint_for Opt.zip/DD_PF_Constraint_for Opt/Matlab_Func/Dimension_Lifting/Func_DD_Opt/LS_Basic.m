function [M_LS_Basic,Error] = LS_Basic(Input,Output)
%UNTITLED2 此处提供此函数的摘要
%   此处提供详细说明
%% init the Matrix
M_LS_Basic= sdpvar(size(Output,1),size(Input,1));


%% init the Constraints
Constraints=[];
for i =1:size(M_LS_Basic,1)
    for j =1:size(M_LS_Basic,2)
        Constraints=[Constraints;-100<=M_LS_Basic(i,j);M_LS_Basic(i,j)<=100];
    end
end

%% Determine the objective
 objective=sum(sum(abs(M_LS_Basic*Input-Output)));
% objective=norm(M_LS_Basic*Input-Output);

%% optimize Process
varargout=optimize(Constraints,objective);
varargout.info

%% Output
M_LS_Basic=value(M_LS_Basic);

Error.data=abs(M_LS_Basic*Input-Output);
Error.mean=mean(mean(abs(M_LS_Basic*Input-Output)));
Error.max=max(max(abs(M_LS_Basic*Input-Output)));

end