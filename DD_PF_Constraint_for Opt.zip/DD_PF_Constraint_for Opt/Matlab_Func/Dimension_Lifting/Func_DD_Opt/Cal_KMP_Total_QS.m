function [M,M_Struct,M_Output,beta_PLS,M_Ridge] = Cal_KMP_Total_QS(Data,IDL_Peremeters,Train_Ops)
%UNTITLED 此处提供此函数的摘要
%   此处提供详细说明
Input=Data.Input;
Output=Data.Output;

rbf_type=IDL_Peremeters.rbf_type;
RisePos=IDL_Peremeters.RisePos;
Un_RisePos=Find_Wihtout_Which([1:size(Input,1)],RisePos);
IDL_Peremeters.type;

%%
num_data=size(Data.Input,2);
Data_Lag.Input_Delta=Data.Input(:,[2:num_data,1])-Data.Input;
Data_Lag.Output_Delta=Data.Output(:,[2:num_data,1])-Data.Output;
Data_Lag.Input_LagMid=(Data.Input(:,[2:num_data,1])+Data.Input)/2;
%%

[Lifted_Vector] = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
Lifted_Vector.XP;
Lifted_Vector.Input_Lifted;
 fprintf('\n【REGRESSION】start');
%%
switch Train_Ops.way
    case 'LS_OR' % Classical Least Squares
        
        if Train_Ops.M_Type
            W = Lifted_Vector.Input_Lifted*Lifted_Vector.Input_Lifted';
            V = Output*Lifted_Vector.Input_Lifted';
            M1 = V*pinv(W);
        else
            M1 = Output*pinv(Lifted_Vector.Input_Lifted);
        end
        y_test=M1*Lifted_Vector.Input_Lifted;
        Error_temp.mean=mean(mean(abs(y_test-Output)));
        Error_temp.max=max(max(abs(y_test-Output)));
        fprintf('\n【LS Error】Average Error： %f  ，Maximum Error： %f  .',Error_temp.mean,Error_temp.max);

        %%
        X_Lag_New=zeros(size(M1,2),num_data);
        for i =1:num_data
            A_Transf=[ones(length(Un_RisePos),1);Data_Lag.Input_LagMid(Un_RisePos,i);ones(length(RisePos)+size(IDL_Peremeters.cent,2),1);];
            A_Transf=A_Transf*ones(1,size(Data.Input,1));
            A_Transf=A_Transf*Data_Lag.Input_Delta(:,i);
            X_Lag_New(:,i)=A_Transf;
        end
        if Train_Ops.M_Type
            W_lag = X_Lag_New*X_Lag_New';
            V_lag = Data_Lag.Output_Delta*X_Lag_New';
            M_lag = V_lag*pinv(W_lag);
        else
            M_lag = Data_Lag.Output_Delta*pinv(X_Lag_New);
        end

        M=M1+Train_Ops.Beita*M_lag;
end
Error_temp.mean=mean(mean(abs(y_test-Output)));
Error_temp.max=max(max(abs(y_test-Output)));


%%
M_Struct.MS=M(:,1:size(Lifted_Vector.XP,1));
M_Struct.M1=M(:,1+size(Lifted_Vector.XP,1):end);

M_Output.M_Incompelet=M;
M_Output.M_Struct=M_Struct;


[Output_test] = Case_PF_Accuracy_Test(IDL_Peremeters,M,M_Struct,Data.Input);
fprintf('\n【LS Error with SM】Average Error： %f  ，Maximum Error： %f  .', ...
    mean(mean(abs(Output-Output_test))),max(max(abs(Output-Output_test))));


 fprintf('\n【REGRESSION】end\n\n');
end