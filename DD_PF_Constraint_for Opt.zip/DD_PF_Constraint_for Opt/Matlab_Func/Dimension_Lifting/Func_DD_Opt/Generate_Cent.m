function [cent] = Generate_Cent(IDL_Peremeters,Nrbf1)
%ZYX  此处提供此函数的摘要
%   此处提供详细说明
switch IDL_Peremeters.type
    case 'IDL'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
        
    case 'IDL_withSM'
        cent.Part2=rand(size(IDL_Peremeters.RisePos,2),Nrbf1); % The basic part
        cent.Part1=rand(size(IDL_Peremeters.RisePos,2)+size(IDL_Peremeters.Un_RisePos,2),Nrbf1);% The additional part

    case 'IDL_QuaModified'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
        
    case 'IDL_QuaModified_withSM'
        cent.Part2=rand(size(IDL_Peremeters.RisePos,2),Nrbf1); % The basic part
        cent.Part1=rand(size(IDL_Peremeters.RisePos,2)+2*size(IDL_Peremeters.Un_RisePos,2)+1,Nrbf1);% The additional part
       
    case 'IDL_QuaModified_withSM_3Np1'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
    case 'IDLSM2'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
    case 'IDLSM3'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
    case 'IDL_CubicSpace'
        cent = rand(size(IDL_Peremeters.RisePos,2),Nrbf1);
      
end
end