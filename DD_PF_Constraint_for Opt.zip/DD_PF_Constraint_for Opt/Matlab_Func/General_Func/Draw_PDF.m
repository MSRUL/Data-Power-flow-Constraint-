function [PDF_Count,new_range,CDF_Count] = Draw_PDF(Data,Range,Drawn_Index)
%Plot the probability density function of an array

PDF_Count=zeros(length(Range)-1,1);
new_range=(Range(2:end)+Range(1:end-1))/2;
for i=2:length(Range)
%     if i<length(Range)
        pos_temp1=find(Range(i-1)<Data);
        pos_temp2=find(Data<Range(i));
        pos_temp=intersect(pos_temp1,pos_temp2);
        PDF_Count(i-1)=length(Data(pos_temp));
%     else
%         pos_temp=find(Range(i-1)<Data);;
%         PDF_Count(i-1)=length(Data(pos_temp));
%     end
end
PDF_Count=PDF_Count/sum(PDF_Count);


CDF_Count=PDF_Count;
for i =2:length(CDF_Count)
    CDF_Count(i,1)=CDF_Count(i,1)+CDF_Count(i-1,1);
end


%%
if Drawn_Index

    subplot(1,2,1);bar(new_range,PDF_Count);title('PDF curve')
    subplot(1,2,2);bar(new_range,CDF_Count);title('CDF curve')
end
end