function [Pos_In_OutPut] = Define_Pos_VariableVector(case_name,Device_Info,Bus_Num,Branch_Num)
%Define_Pos_VariableVector Define the Position of Variable in Vector
input_num=Device_Info.Input_Num;

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
INclude_PV_S=Device_Info.INclude_PV_S;
%%
Pos_In_OutPut.Pos_P_Load                =1:length(pq);
Pos_In_OutPut.Pos_Q_Load                =length(pq)+1:2*length(pq);
Pos_In_OutPut.Pos_RefBus                =2*length(pq)+1;
Pos_In_OutPut.Pos_P_in_Inventer         =2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S);
Pos_In_OutPut.Pos_Q_in_Inventer         =2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2;
Pos_In_OutPut.Pos_PV_P_Inventer_Start   =2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state;
Pos_In_OutPut.Pos_PV_Q_Inventer_Start   =2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S);
if Device_Info.Transformer_Tab_state
Pos_In_OutPut.Pos_TransTab              =2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state;
else
    Pos_In_OutPut.Pos_TransTab=[];
end
if Device_Info.input_Cbank_state
Pos_In_OutPut.Pos_C_Bank                =2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state;
else
    Pos_In_OutPut.Pos_C_Bank =[];
end
% Pos_Q_in_Inventer
Pos_In_OutPut.VMS=case_name.bus(ref,10);

Pos_In_OutPut.PV_Num=length(INclude_PV_S);
Pos_In_OutPut.Vm=1:length(pq);
Pos_In_OutPut.PLoss=length(pq)+1;
Pos_In_OutPut.Bus_Num=Bus_Num;
Pos_In_OutPut.Branch_Num=Branch_Num;
Pos_In_OutPut.pq=pq;
Pos_In_OutPut.pv=pv;
Pos_In_OutPut.ref=ref;
Pos_In_OutPut.baseMVA=case_name.baseMVA;
Pos_In_OutPut.input_num=input_num;


Pos_In_OutPut.Pload_with_PInventor_in_Input=zeros(length(Device_Info.INclude_PV_node),1);
Pos_In_OutPut.Qload_with_PInventor_in_Input=zeros(length(Device_Info.INclude_PV_node),1);
for i=1:length(Device_Info.INclude_PV_node)
    Pos_In_OutPut.Pload_with_PInventor_in_Input(i,1)=find(pq==Device_Info.INclude_PV_node(i));
    Pos_In_OutPut.Qload_with_PInventor_in_Input(i,1)=find(pq==Device_Info.INclude_PV_node(i))+length(pq);
end



% Pos_In_OutPut.Un_RisePos=[Pos_In_OutPut.Pos_P_in_Inventer,Pos_In_OutPut.Pos_Q_in_Inventer];
Pos_In_OutPut.Un_RisePos=[Pos_In_OutPut.Pos_Q_in_Inventer];% Position of the Unrised Vector ��Control Variable��
Pos_In_OutPut.RisePos=Find_Wihtout_Which([1:input_num],Pos_In_OutPut.Un_RisePos); % Position of the Rised Vector ��State Variable��

Pos_In_OutPut.Pos_Input_Rise=length(Pos_In_OutPut.RisePos)+1:Pos_In_OutPut.input_num; %The Unreised Part of Input During the Process of maltiping the M. 

end

