function [outputArg1] = Lift_Dem_Fun_Tradi_2(inputArg1,rbf_type,cent,RisePos)
%UNTITLED3 
    Un_RisePos=Find_Wihtout_Which([1:size(inputArg1,1)],RisePos);
    lift_inpuit=inputArg1(RisePos,:);
    lifted_inpuit=( [lift_inpuit;rbf_self_use(lift_inpuit,cent,rbf_type)] );
    outputArg1=[inputArg1(Un_RisePos,:);lifted_inpuit];
%     outputArg1=( [inputArg1;rbf_self_use(inputArg1,cent,rbf_type);1] );
end