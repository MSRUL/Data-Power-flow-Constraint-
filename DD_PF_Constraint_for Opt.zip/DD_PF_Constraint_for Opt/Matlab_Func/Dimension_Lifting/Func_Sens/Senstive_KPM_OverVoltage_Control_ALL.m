function [OUTPUT_Record,INPUT_Record,Senstive_M_Record] = Senstive_KPM_OverVoltage_Control_ALL(Input_Standard,pq,pv,INclude_PV_S,M_V,Senstive_M,Over_Voltage,TransTab_step,cent_input,adjust_Q_step,adjust_P_step,KPM_Output,Voltage)
%UNTITLED15 Koopman 灵敏度调压方�?
%   此处显示详细说明
OUTPUT_Record=KPM_Output;
Adj_Input=Input_Standard;
INPUT_Record=Adj_Input;
M_V_Rank=Senstive_M;
Senstive_M_Record=zeros(size(Senstive_M,1),size(Senstive_M,2),1);
count_term=0;
% zeros(size(M_V));
% M_V_Rank(:,INclude_PV_node_Pos)=M_V(:,INclude_PV_node_Pos);
% M_V_Rank(:,size(pq,1)+INclude_PV_node_Pos)=M_V(:,size(pq,1)+INclude_PV_node_Pos);

Pos_P_in_Input=2*length(pq)+length(pv)+1+1+1:2*length(pq)+length(pv)+1+1+length(INclude_PV_S);
Pos_Q_in_Input=2*length(pq)+length(pv)+1+1+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+1+length(INclude_PV_S)*2;
Pos_PV_P_Inventer_Start=2*length(pq)+length(pv)+1+1;
Pos_PV_Q_Inventer_Start=2*length(pq)+length(pv)+1+1+length(INclude_PV_S);
Pos_TransTab=2*length(pq)+length(pv)+1+1+length(INclude_PV_S)*2+1;

Adj_T=0; %进行变压器的分接头调�?
Adj_Q=1; % 进行无功功率调节
Adj_P=0; % 进行有功功率调节
numof_PV_inventor=[1,1,1]; %初始�?
while(length(Over_Voltage)>0) %调节过电�?
    %     length(Below_Voltage) %剩余的需要电压调节的节点个数
    if Adj_P&&length(Over_Voltage)>0  %过电压问题中，�?�过调节分接头和光伏逆变器已经不足以满足电压要求，需要限制光伏的倒�?�功�?
        for i=1:length(Over_Voltage)
            [numof_PV_inventor]=find(  abs(M_V_Rank(Over_Voltage(i),Pos_P_in_Input))==max(abs(M_V_Rank(Over_Voltage(i),Pos_P_in_Input))) );  %寻找无功功率调节灵敏度最高的�?
            if length(numof_PV_inventor)>1
                stophere=1;
            else
                ;
            end
            if M_V_Rank(Over_Voltage(i),Pos_PV_Q_Inventer_Start+numof_PV_inventor)>=0  %判断�?大影响点是正还是�?,作为正负系数加入调节量中
                B_direction=-1;
            else
                B_direction=1;
            end
            B_direction=-1;
            if Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)+B_direction*adjust_P_step>=0 %调节后输出有功功率为正的约束
                Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)=Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)+B_direction*adjust_P_step;
            else
                M_V_Rank(:,Pos_PV_P_Inventer_Start+numof_PV_inventor)=0;
                '第i个光伏�?�变器没有无功功率可用了'
            end
        end
    end
    if ~Adj_P
        for i=1:length(Over_Voltage)
            Over_Voltage(i);
            Over_Voltage(i);
            if Adj_Q
                [numof_PV_inventor]=find(  abs(M_V_Rank(Over_Voltage(i),Pos_Q_in_Input))==max(abs(M_V_Rank(Over_Voltage(i),Pos_Q_in_Input))) );  %寻找无功功率调节灵敏度最高的�?
            end
            if length(numof_PV_inventor)>1  %无法找到灵敏度最大的点，表明此时系统中已经没有光伏的无功功率可以参与调节了�??
                
                if Adj_Input(Pos_TransTab,1)+TransTab_step.step<=TransTab_step.max %判断分接头是否还有调节的余地
                    Adj_Input(Pos_TransTab,1)=Adj_Input(Pos_TransTab,1)+TransTab_step.step; %向下调节�?个步长的分接�?
                    Adj_Input(1:Pos_TransTab-1,1)=Input_Standard(1:Pos_TransTab-1,1); % 调节完分接头后，将重置所有其他的输入变量
                    M_V_Rank=Senstive_M;
                    break
                else
                    Adj_P=1; %�?要进行有功功率调�?
                    Adj_Q=0;
                    break
                end
            end
            %         if max(abs(M_V_Rank(Below_Voltage(i),size(pq,1)+1:size(pq,1)*2)))>abs(M_V_Rank(Below_Voltage(i),size(pq,1)*2+2))  %是否�?要调节电容器   %这里暂时不�?�虑成本，只从�?�辑顺序上调�?
            %             Adj_CB=0;
            %         else
            %             Adj_CB=1;
            %             temp_pos_q=size(pq,1)+2;
            %         end
            
            if ~Adj_P
                if M_V_Rank(Over_Voltage(i),Pos_PV_Q_Inventer_Start+numof_PV_inventor)>=0  %判断�?大影响点是正还是�?,作为正负系数加入调节量中
                    B_direction=-1;
                else
                    B_direction=1;
                end
                B_direction=-1; %这里实际测试中，如果通过灵敏度方法计算时，会出现正负号不确定的情况，在特殊的条件下，导致多个节点同时调节�?个�?�变器，但是�?个正�?个负，相当于没调，陷入死循环�?1�?
                if (Adj_Input(Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)^2+Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)^2)<INclude_PV_S(numof_PV_inventor)^2 %后续补充调节容量约束
                    Adj_Input(Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)=Adj_Input(Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)+B_direction*adjust_Q_step;  %*...  %接下句标幺化的部�?
                    % abs(M_V_Rank(Over_Voltage(i),Pos_PV_Q_Inventer_Start+numof_PV_inventor))/max(max(abs(M_V_Rank(Over_Voltage,Pos_Q_in_Input)))); %标幺化灵敏度 %主要是为了防止�??1】中的互补陷入死循环，但是最终还是不行�??
                else
                    M_V_Rank(:,Pos_PV_Q_Inventer_Start+numof_PV_inventor)=0;
                    '第i个光伏�?�变器没有无功功率可用了'
                end
            end
        end
    end
    Adj_Input_Lifted=Lift_Dem_Fun_Tradi(Adj_Input,'polyharmonic',cent_input);
    KPM_Output=M_V*Adj_Input_Lifted;
    %----------------------------------
%         [Senstive_M_Adj] = Koopman_Senstive_Matric(Adj_Input,'polyharmonic',cent_input,M_V);
%         [x1,y1]=find(M_V_Rank~=0);
%         for i=1:size(x1,1)
%             M_V_Rank(x1(i),y1(i))=Senstive_M_Adj(x1(i),y1(i));
%         end
%         count_term=count_term+1;
%         Senstive_M_Record(:,:,count_term)=Senstive_M_Adj;
    %----------------------------------
    
    OUTPUT_Record=[OUTPUT_Record,KPM_Output];
    INPUT_Record=[INPUT_Record,Adj_Input];
    Over_Voltage=find(KPM_Output>Voltage.max);
end

% size(OUTPUT_Record,2) %迭代调压次数
end

