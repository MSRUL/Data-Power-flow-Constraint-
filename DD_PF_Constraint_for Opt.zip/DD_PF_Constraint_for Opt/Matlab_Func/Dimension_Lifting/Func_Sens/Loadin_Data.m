function [temp_load_data,temp_load_data_DDLPF] = Loadin_Data(path_last,Objectivetype,case_chose,Qno0)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明
if Qno0
    switch Objectivetype
        case 'Min Adjustment'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_deltaQ_case116_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_deltaQ_case116_Qno0.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_deltaQ_case109_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_deltaQ_case109_Qno0.mat'));
            end
        case 'Min Loss'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case116_Qno0.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case109_Qno0.mat'));
            end
        case 'Hybrid'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case116_Qno0.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case109_Qno0.mat'));
            end
        case 'Min_Voltage_deviation_rate'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case116_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case116_Qno0.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case109_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case109_Qno0.mat'));
            end
        case   'Min_VDR_and_Min_Adj'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case116_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case116_Qno0.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case109_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case109_Qno0.mat'));
            end
        case   'DG_Consumption'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case116_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_max_DG_Consumption_case116_Qno0.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case109_Qno0.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_max_DG_Consumption_case109_Qno0.mat'));
            end
    end
else
    switch Objectivetype
        case 'Min Adjustment'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_deltaQ_case116.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_deltaQ_case116.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_deltaQ_case109.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_deltaQ_case109.mat'));
            end
        case 'Min Loss'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case116.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case109.mat'));
            end
        case 'Hybrid'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case116.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case109.mat'));
            end
        case 'Min_Voltage_deviation_rate'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case116.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case116.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case109.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case109.mat'));
            end
        case 'Min_VDR_and_Min_Adj'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case116.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case116.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case109.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_min_VDR_case109.mat'));
            end
        case   'DG_Consumption'
            switch case_chose
                case 'case116'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case116.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_max_DG_Consumption_case116.mat'));
                case 'case109'
                    temp_load_data=load(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case109.mat'));
                    temp_load_data_DDLPF=load(strcat(path_last,'Result_CPLEX_DD_LPF_max_DG_Consumption_case109.mat'));
            end
    end
end




end

