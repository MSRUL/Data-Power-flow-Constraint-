function [Result_OPT_KPM,M_Matrix] = Cplex_KPM4_Opt_Only_PV_Q_bothPQ(Input,M_Incompelet,Pos_Info,IDL_Peremeters,Constraint,Objective_Info)
%%
Constraint.PVinverter_P; %MW
Constraint.PVinverter_Q; %MVar
Constraint.P_Load; %MW
Constraint.Q_Load; %MVar
Constraint.INclude_PV_node;
Constraint.INclude_PV_S;
Constraint.Voltage;
%% Variables
PV_P= sdpvar(length(Pos_Info.Pos_P_in_Inventer),1);
PV_Q= sdpvar(length(Pos_Info.Pos_P_in_Inventer),1);
Optm_Variables = sdpvar(length(Pos_Info.Un_RisePos)*2,1);
Vm_PQ = sdpvar(length(Pos_Info.pq),1);
P_Loss = sdpvar(1,1);
%%
Input_lifted_temp = Lift_Vector_Incomplete_Total(Input,IDL_Peremeters);
Input_temp=Input_lifted_temp.Input_Lifted;

Inout_temp_to_Rise=Input_temp(2*length(Pos_Info.Un_RisePos)+1:end);
%% Constraints

%% (1)Koopman PF
M11=M_Incompelet(1:length(Pos_Info.pq),1:(length(Pos_Info.Un_RisePos)*2));  % Optimization variable  %dimension lifted 3N+1
M12=M_Incompelet(1:length(Pos_Info.pq),(length(Pos_Info.Un_RisePos)*2+1):length(Input_temp)); %Other lifting dimension variables
M_Matrix.M11=M11;
M_Matrix.M12=M12;


Constraints=[];
Constraints=[Constraints;Optm_Variables==[ PV_Q ; PV_Q.*PV_Q ]];
Constraints=[Constraints;Vm_PQ==M11*Optm_Variables+M12*Inout_temp_to_Rise];
Constraints=[Constraints;Vm_PQ <=ones(length(Pos_Info.pq),1)*Constraint.Voltage.max];

%% (2)PV Inverter Output Constraint
PV_Q_Limit_Rate=1;
PVinverter_P=Input(Pos_Info.Pos_P_in_Inventer);
PVinverter_Q=Input(Pos_Info.Pos_Q_in_Inventer);
for i=1:size(PV_Q,1)
    Constraints=[Constraints; norm([PVinverter_P(i,1);PV_Q(i,1)])<=Constraint.INclude_PV_S(i,1)];  %PV inverter Active Power Up limint

    switch Objective_Info.Opt_Variable
        case 'Reactive_Power'
            Constraints=[Constraints; abs(PV_Q(i,1))<=Constraint.INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Active Power Up limint
            Constraints=[Constraints;PV_P(i,1)==PVinverter_P(i,1)];
        case 'Active_Power'
            Constraints=[Constraints;0<=PV_P(i,1)<=PVinverter_P(i,1)];
            Constraints=[Constraints;PV_Q(i,1)==PVinverter_Q(i,1)];
    end

end
%% Objective

Objective_Info.Hybrid_Index=[1,1];
switch Objective_Info.type
    case 'Min Adjustment'
        objective=sum(abs(PV_Q-Constraint.PVinverter_Q)); %
    case 'Min_Voltage_deviation_rate'
        objective=sum(abs(Objective_Info.Voltage_Tatget-Vm_PQ));
end
ops = sdpsettings('solver','gurobi','showprogress',1);
varargout=optimize(Constraints,objective,ops);
varargout.info

%% Output
Result_OPT_KPM.PV_P=PVinverter_P;
Result_OPT_KPM.PV_Q=value(PV_Q);
Result_OPT_KPM.Vm_PQ=value(Vm_PQ);
Result_OPT_KPM.P_Loss=value(P_Loss);
Result_OPT_KPM.PV_Q_Adj=value(PV_Q)-Input(Pos_Info.Pos_Q_in_Inventer);
Result_OPT_KPM.PV_P_Adj=value(PV_P)-Input(Pos_Info.Pos_P_in_Inventer);
Result_OPT_KPM.objective=value(objective);
Result_OPT_KPM.Opt_Info=varargout.info;
Result_OPT_KPM.solvertime=varargout.solvertime;


%% Adheusted  （o change in the parameters here, just to unify the format with it）
M_Matrix.M11_AfterAdj=M11;
M_Matrix.M12_AfterAdj=M12;

end

