function [Lifted_Vector] = Lift_Vector_Incomplete_Total(inputArg1,IDL_Peremeters)
%UNTITLED4 此处显示有关此函数的摘要
%   此处显示详细说明
%%
rbf_type=IDL_Peremeters.rbf_type;
cent=IDL_Peremeters.cent;
RisePos=IDL_Peremeters.RisePos;
IDL_Peremeters.type;
IDL_Peremeters.M_Asstence;

switch IDL_Peremeters.type
    case 'IDL'
        cent_part2=IDL_Peremeters.cent;
    case 'IDL_withSM'
        cent_part2=IDL_Peremeters.cent.Part2;
    case 'IDL_QuaModified'
        cent_part2=IDL_Peremeters.cent;
    case 'IDL_QuaModified_withSM'
        cent_part2=IDL_Peremeters.cent.Part2;
    case 'IDL_QuaModified_withSM_3Np1'
        cent_part2=IDL_Peremeters.cent;
    case 'IDLSM2'
        cent_part2=IDL_Peremeters.cent;
    case 'IDLSM3'
        cent_part2=IDL_Peremeters.cent;
    case 'IDL_CubicSpace'
        cent_part2=IDL_Peremeters.cent;
end
%% The Dimension lifted parts
FUN_select = Defined_Lift_FuncType(rbf_type);
Un_RisePos=Find_Wihtout_Which([1:size(inputArg1,1)],RisePos);
lift_inpuit=inputArg1(RisePos,:);
% lifted_inpuit=( [lift_inpuit;rbf_self_use(lift_inpuit,cent,rbf_type)] );
switch FUN_select
    case 1
        lifted_inpuit = Lift_Dem_Fun_Tradi(lift_inpuit,rbf_type,cent_part2);
    case 2% 3N+1褰㈠紡
        lifted_inpuit = Lift_Dem_Fun_3NP1(lift_inpuit);
    case 3% 瀹屾暣鐨勪簩娆″瀷绌洪棿
        lifted_inpuit = Lift_Func(lift_inpuit);
    case 4
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',cent_part2);
        lifted_inpuit2 =  Lift_Dem_Fun_3NP1(lift_inpuit);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 5
        halfcent1=cent_part2(:,1:size(cent_part2,2)/2);
        halfcent2=cent_part2(:,1:size(cent_part2,2)/2+1:size(cent_part2,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 6
        halfcent1=cent_part2(:,1:size(cent_part2,2)/2);
        halfcent2=cent_part2(:,1:size(cent_part2,2)/2+1:size(cent_part2,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 7
        halfcent1=cent_part2(:,1:size(cent_part2,2)/2);
        halfcent2=cent_part2(:,1:size(cent_part2,2)/2+1:size(cent_part2,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 8
        halfcent1=cent_part2(:,1:size(cent_part2,2)/2);
        halfcent2=cent_part2(:,1:size(cent_part2,2)/2+1:size(cent_part2,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent3);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:);lifted_inpuit3(size(lift_inpuit,1)+1:end,:)];
    case 9 % polyharmonic+invquad+invmultquad+3np1,!!!DIMENSION DOUBLE!!!!
        halfcent1=cent_part2(:,1:size(cent_part2,2)/2);
        halfcent2=cent_part2(:,1:size(cent_part2,2)/2+1:size(cent_part2,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent3);
        lifted_inpuit4 =  Lift_Dem_Fun_3NP1(lift_inpuit);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:);lifted_inpuit3(size(lift_inpuit,1)+1:end,:);lifted_inpuit4(size(lift_inpuit,1)+1:end,:)];
        
end
%% The Dimension Unlifted parts
switch IDL_Peremeters.type
    case 'IDL'
        XP=inputArg1(Un_RisePos,:);
        XS=[];
        Num_Opt=length(Un_RisePos);
    case 'IDL_withSM'
        XP=zeros(size(inputArg1,1)+size(cent.Part1,2),size(inputArg1,2));
        for j=1:size(inputArg1,2)
            XS = Lift_Vector_InComplete_with_Direction(inputArg1(:,j),rbf_type,cent.Part1,RisePos);% XS: Time variable(for disturbance variable)
            XP(:,j)=XS*inputArg1(Un_RisePos,j);
        end
        Num_Opt=length(Un_RisePos);
    case 'IDL_QuaModified'
%         XP= Lift_Dem_Fun_2NP1(inputArg1(Un_RisePos,:));
        XP= Lift_Dem_Fun_QS_2n(inputArg1(Un_RisePos,:)); %20220908
        XS=[];
        Num_Opt=2*length(Un_RisePos)+1;
    case 'IDL_QuaModified_withSM'
        XP=zeros(size(RisePos,2)+2*size(Un_RisePos,2)+1+size(cent.Part1,2),size(inputArg1,2));
        for j=1:size(inputArg1,2)
            XS = Lift_Vector_InComplete_with_Direction_ControlVariableQua(inputArg1(:,j),rbf_type,cent.Part1,RisePos);% XS: Time variable(for disturbance variable)
            Input_2NP1= Lift_Dem_Fun_2NP1(inputArg1(Un_RisePos,j)) ; 
            XP(:,j)=XS*Input_2NP1;
        end
        Num_Opt=2*length(Un_RisePos)+1;
    case 'IDL_QuaModified_withSM_3Np1'
        XP=Lift_Dem_Fun_3NP1(inputArg1(Un_RisePos,:));
        XS=[];
        Num_Opt=3*length(Un_RisePos)+1;
    case 'IDLSM2'
        M_Assitence_temp=repmat(IDL_Peremeters.M_Asstence,size(lifted_inpuit,2),1);
        XP=lifted_inpuit*M_Assitence_temp*inputArg1(Un_RisePos,:);
        XS=[];
    case 'IDLSM3'
        M_Assitence_temp=repmat(IDL_Peremeters.M_Asstence,size(lifted_inpuit,2),1);
        XP=lift_inpuit*M_Assitence_temp*inputArg1(Un_RisePos,:);
        XS=[];
    case 'IDL_CubicSpace'
        XP= Lift_Dem_Fun_CubicSpace(inputArg1(Un_RisePos,:));
        XS=[];
        Num_Opt=3*length(Un_RisePos)+1;
end

%%
Lifted_Vector.Input_Lifted=[XP;lifted_inpuit];
Lifted_Vector.XP=XP;
Lifted_Vector.XS=XS;
Lifted_Vector.Num_Opt=Num_Opt;
Lifted_Vector.lifted_inpuit=lifted_inpuit;

end

