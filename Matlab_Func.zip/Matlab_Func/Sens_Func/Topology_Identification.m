function [Adjacency_Matrix] = Topology_Identification(Data)
% UNTITLED4 此处提供此函数的摘要
%   此处提供详细说明
for i_1=1:size(Data.Input,1)
    for j_1=1:size(Data.Output,1)
        Pearson=corr([Data.Input(i_1,:)',Data.Output(j_1,:)'],'type','Pearson');

    end
end

end