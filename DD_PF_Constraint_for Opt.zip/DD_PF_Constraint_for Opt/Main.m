clear,clc
close all;
path_base = mfilename('fullpath');i=findstr(path_base,'\');path_base=path_base(1:i(end));
path_last = mfilename('fullpath');i=findstr(path_base,'\');path_last=path_last(1:i(end-1)); %此代码必须运行m文件执行
%% ZYX 202203


%% 【！！】Pay attention to the parameters before modification
%------------Case Name------------------------------
Case_Name='IEEE33'; %'IEEE33' 
Opt_Variable='Reactive_Power'; %'Active_Power' 'Reactive_Power'
IDL_Peremeters.type='IDL_QuaModified';  % 'IDL'  'IDL_QuaModified'
Objective_Info.type='Min Adjustment';  %'Min Adjustment''Min_Voltage_deviation_rate' 
%%

case_name_or=case33bw;

%------------Generated Data Parameters--------------
Range=3.2;   % 3.2 In Letter Cases
New_Training_data=0;
training_data_file='1000组_Range3.2_Vm'; %Only New_Training_data==0

%------------Dimension Lifting Parameters-----------
num_inpuit=1000;   %Num of Training Data Sets--------
Nrbf1=10;  % dimension lifting number
Nrbf2=0; %input_num-output_num;
rbf_type='polyharmonic';rbf_type_Inverse='polyharmonic';


% --------Output Variable List----------------------
ItemName='';
TestItem.PQ_Vm=1;   if TestItem.PQ_Vm ;ItemName=strcat(ItemName,'Vm'); end


if New_Training_data
    KPM_Parameters_Info=strcat(num2str(num_inpuit),'组_Range',num2str(Range),'_',ItemName);
else
    KPM_Parameters_Info=training_data_file;
end
additional_info_KMP='Using_M_equa_0__';
additional_info_KMP=strcat(additional_info_KMP,rbf_type);
KPM_Parameters_Info=strcat(KPM_Parameters_Info,additional_info_KMP);


% --------Objective in Optimization List----------------------
% see details in process below
%% Record the case info (Opt info) The deteail of the parameters are not included.
case_obj_info=Case_Name;
case_obj_info=strcat(case_obj_info,'_',IDL_Peremeters.type);
switch Objective_Info.type
    case 'Min Adjustment'
        case_obj_info=strcat(case_obj_info,'_MinAdj');
    case 'Min_Voltage_deviation_rate'
        case_obj_info=strcat(case_obj_info,'_MinVDR');
end
additional_info_IDL='';
case_obj_info=strcat(case_obj_info,additional_info_IDL);


%% Init the Case Parameters
case_name_or_simp=Transfer_node_num_to_consecutive(case_name_or);  % Change the bus name to consecutive numbers
case_name=Transfer_node_num_to_consecutive(case_name_or);  % Change the bus name to consecutive numbers
Bus_Num=size(case_name.bus,1);
line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
Standard_result=runpf(case_name);
fprintf('OR Power Loss: %f\n',sum(abs(Standard_result.branch(:,14)+Standard_result.branch(:,15)))/Standard_result.baseMVA);
[ref,pv, pq,pv_pos,ref_pos,pv_total] = Case_Info(case_name);
% figure;plot(Standard_result.bus(:,8))
%% Init the PhotoVoltak/CapacitorBank Parameters
HaveDG=1; %This Program default is 1(For the optimization)
switch Case_Name
    case 'IEEE33'
        [Device_Info] = Init_Device_Info(case_name,HaveDG);
    case 'IEEE69'
        [Device_Info] = Init_Device_Info_Case69(case_name,HaveDG);
    case 'IEEE85'
        [Device_Info] = Init_Device_Info_Case85(case_name,1);
    case 'IEEE141'
        [Device_Info] = Init_Device_Info_Case141(case_name,HaveDG);
end
%% Data Parameter
input_num=Device_Info.Input_Num;
test_input_num=input_num; %size(pq,1)*2+size(pv,1);
case_name.bus(pq,3:4)=0;
case_name.gen([pv_total;ref_pos],[2,6])=0;
num_test_input=max(num_inpuit*1.2,num_inpuit+1000);
% num_test_input=1;
%% Position of Variable in Input Vector
[Pos_In_OutPut] = Define_Pos_VariableVector(case_name,Device_Info,Bus_Num,Branch_Num);
%--------Additional Modification---------------------
Pos_In_OutPut.Un_RisePos=[Pos_In_OutPut.Pos_Q_in_Inventer];% Position of the Unrised Vector 【Control Variable】
Pos_In_OutPut.RisePos=Find_Wihtout_Which([1:input_num],Pos_In_OutPut.Un_RisePos); % Position of the Rised Vector 【State Variable】
Pos_In_OutPut.Pos_Input_Rise=length(Pos_In_OutPut.RisePos)+1:Pos_In_OutPut.input_num; %The Unreised Part of Input During the Process of maltiping the M.

%% Generate the Training Data
[Tranning_Range,Testing_Range] = Init_Training_Data_Range(Range);

if New_Training_data
    %     [Input,Output] = Generate_Tranning_OR_Testing_Data(input_num,test_input_num,num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,Measure_Noise,TestItem);
    %%  Storge Data
    for i=1:2
        [Input,Output] = Generate_Tranning_OR_Testing_Data(input_num,test_input_num,num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,TestItem);
        Data.Input=Input;
        Data.Output=Output;
        save_data_path=strcat(path_base,'\PF_Training_Data\',num2str(num_inpuit),'组_Range',num2str(Range),'_',ItemName,'_no',num2str(i),'.mat');
        save(save_data_path,'Data');
    end
    training_data_file=strcat(path_base,'\PF_Training_Data\',num2str(num_inpuit),'组_Range',num2str(Range),'_',ItemName,'_no',num2str(1),'.mat');
else
    load(strcat(path_base,'\PF_Training_Data\',training_data_file,'.mat'));
%     Data=Data_CoL; % When collinear data is in
end
% ------------------------------------------

%%
% Data.Input=Data.Input(:,1:120);
% Data.Output=Data.Output(:,1:120);
%% Koopman Matrix Calculate
fprintf('\n\nUse the Training Data to Test:\n');

% [M_Compelet,M_Inverse]=Cal_M_Koopman(Input,Output,rbf_type,rbf_type_Inverse,cent_input_compelete,cent_output);
%-----------【Incompelet】---------------------------------   The【Compelet】can be find in Koopman_PF_Optimization.m
IDL_Peremeters.rbf_type=rbf_type;
IDL_Peremeters.RisePos=Pos_In_OutPut.RisePos;
IDL_Peremeters.Un_RisePos=Pos_In_OutPut.Un_RisePos;
IDL_Peremeters.cent = Generate_Cent(IDL_Peremeters,Nrbf1);
IDL_Peremeters.type;
IDL_Peremeters.M_Asstence=rand(1,length(Pos_In_OutPut.Un_RisePos));

 Train_Ops.way='LS_OR';   %  'LS_OR'  'LS_OR_pu'  'LS_Opt' 'Load_Trained_Data'
 Train_Ops.Beita=0.1;
 Train_Ops.M_Type=1; % Default

 %% The Training Parts
 switch IDL_Peremeters.type % 'IDL' 'IDL_QuaModified'
     case 'IDL'
         [M_Incompelet,M_Struct,M_Output] = Cal_KMP_Total(Data,IDL_Peremeters,Train_Ops);
     case 'IDL_QuaModified'
         [M_Incompelet,M_Struct,M_Output] = Cal_KMP_Total_QS(Data,IDL_Peremeters,Train_Ops);
 end
Data_No0=Data;

%%
Runtimes=1000;

%% ---------------Rolling Test Accuracy-1-------------------------
Error_Rol.data=zeros(Runtimes,2);
Error_Rol.error_info=cell(Runtimes,1);
Error_Rol.Value_objective=zeros(Runtimes,1);
Error_Rol.OptResults.V_PQ_Cal=zeros(length(pq),Runtimes);
Error_Rol.OptResults.V_PQ_Check=zeros(length(pq),Runtimes);
Error_Rol.OptResults.Q_adj=zeros(length(Pos_In_OutPut.Pos_Q_in_Inventer),Runtimes);
Error_Rol.solve_time=zeros(Runtimes,1);
for i_time_count=1:Runtimes

fprintf('\nSolving the No. %d snapshot',i_time_count);
%% Case in
Qno0=0;  %1 :Have data
%------Weather Generate the New Cases / Load Case ---------------------
if 0
    [Input_Standard] = Generate_Standard_Case_Vector(case_name_or_simp,Device_Info,0.7);
    LoadinCase_Info.case_chose='New Generated Case';
else
     temp=load(strcat(path_base,'Case_to_Opt\OverVoltageCaseInput_No',num2str(i_time_count),'.mat'));
     Input_Standard=temp.Input_Standard;
end
%-------Weather Put the Reactive Power to 0--------------------
if Qno0
    ;
else
    Input_Standard(Pos_In_OutPut.Pos_Q_in_Inventer,:)=0;  %Weather to put 0 in Qoutput of PV
end


%% Case Basic Analyze
Input_Standard(Pos_In_OutPut.Pos_TransTab,:)=1;
Input_Standard(Pos_In_OutPut.Pos_C_Bank,:)=0;  % C bank put to 0; indeed it has no influences cos its on the referrence bus

[Output_NR,Input_NR,casename_NR,results_NR]=NR_PF_Cal(case_name,Input_Standard,Device_Info);

[Output_Test_Incompelet] = Case_PF_Accuracy_Test(IDL_Peremeters,M_Incompelet,M_Struct,Input_Standard);

%% 
Constraint.PVinverter_P=Input_Standard(Pos_In_OutPut.Pos_P_in_Inventer,1)*1; %MW
Constraint.PVinverter_Q=Input_Standard(Pos_In_OutPut.Pos_Q_in_Inventer,1)*1; %MW
Constraint.P_Load=[0;Input_Standard(Pos_In_OutPut.Pos_P_Load,1)]*1;
Constraint.Q_Load=[0;Input_Standard(Pos_In_OutPut.Pos_Q_Load,1)]*1;
Constraint.INclude_PV_node=Device_Info.INclude_PV_node;
Constraint.INclude_PV_S=Device_Info.INclude_PV_S';%MVA
Constraint.Voltage.max=1.05;
Constraint.Voltage.min=0.95;
Objective_Info.Hybrid_Index=[1,0.1];
Objective_Info.Voltage_Tatget=ones(size(pq,1),1)*results_NR.gen(1,6);
Objective_Info.Opt_Variable=Opt_Variable;

switch IDL_Peremeters.type	
    case 'IDL'
        [Result_OPT_KPM,M_Matrix] = Cplex_KPM2_Opt_Only_PV_Q(Input_Standard,M_Incompelet,Pos_In_OutPut,IDL_Peremeters ,Constraint,Objective_Info);
    case 'IDL_QuaModified'
        [Result_OPT_KPM,M_Matrix] = Cplex_KPM4_Opt_Only_PV_Q_bothPQ(Input_Standard,M_Incompelet,Pos_In_OutPut,IDL_Peremeters ,Constraint,Objective_Info);
end


%% ---------------Opt Results Check--------------
input_temp=Input_Standard;
% -------------KPM check-------------
input_temp([Pos_In_OutPut.Pos_P_in_Inventer,Pos_In_OutPut.Pos_Q_in_Inventer],1)=[Result_OPT_KPM.PV_P;Result_OPT_KPM.PV_Q];

[Output_Test_Standard] = Case_PF_Accuracy_Test(IDL_Peremeters,M_Incompelet,M_Struct,input_temp);
Result_OPT_KPM.Vm_PQ_KPMCheck=Output_Test_Standard(1:length(TestItem.PQ_Vm),1);
Result_OPT_KPM.PLoss_KPMCheck=Output_Test_Standard(1+length(TestItem.PQ_Vm),1);
% -------------KPM's NR PF check-------------
[~,~,~,results_NR_AfterAdj]=NR_PF_Cal(case_name,input_temp,Device_Info);
Result_OPT_KPM.Vm_PQ_NRCheck=results_NR_AfterAdj.bus(pq,8);
Result_OPT_KPM.PLoss_NRCheck=sum(abs(results_NR_AfterAdj.branch(:,14)+results_NR_AfterAdj.branch(:,16)));
%% ---------------Rolling Test Accuracy--2------------------------
fprintf('\n Adjustment Error： Average: %f ;  Maximum: %f',mean(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8))),...
    max(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8))));
Error_Rol.data(i_time_count,1)=mean(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8)));
Error_Rol.data(i_time_count,2)=max(abs([results_NR_AfterAdj.bus(1,8);Result_OPT_KPM.Vm_PQ]-results_NR_AfterAdj.bus(:,8)));
Error_Rol.error_info{i_time_count,1}=Result_OPT_KPM.Opt_Info;
Error_Rol.Value_objective(i_time_count,1)=Result_OPT_KPM.objective;
Error_Rol.OptResults.V_PQ_Cal(:,i_time_count)=Result_OPT_KPM.Vm_PQ;
Error_Rol.OptResults.V_PQ_Check(:,i_time_count)=Result_OPT_KPM.Vm_PQ_NRCheck;
Error_Rol.OptResults.Q_adj(:,i_time_count)=Result_OPT_KPM.PV_Q_Adj;
Error_Rol.OptResults.P_adj(:,i_time_count)=Result_OPT_KPM.PV_P_Adj;
Error_Rol.solve_time(i_time_count,1)=Result_OPT_KPM.solvertime;

end

Index_Solveable_Index_temp = Judge_Solveable_Cell(Error_Rol.error_info);
fprintf('\n AE:%f ,ME: %f ',mean(Error_Rol.data(Index_Solveable_Index_temp,1)),max(Error_Rol.data(Index_Solveable_Index_temp,2)))
        









