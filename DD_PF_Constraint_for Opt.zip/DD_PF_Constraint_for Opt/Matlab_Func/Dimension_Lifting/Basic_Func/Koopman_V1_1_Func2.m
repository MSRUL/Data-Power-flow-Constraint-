function [e_a_mean,e_a_max,e_s_mean,e_s_max,e_a_mean1,e_a_max1,e_a_mean2,e_a_max2,e_s_mean1,e_s_max1,e_s_mean2,e_s_max2] = ...
Koopman_V1_1_Func2(case_name_input,Figurte_Out_Put,FUN_select_input,TEST_input,temp_range_input,Nrbf_input,num_test_input,...
                num_input,PQV_range_input,sensitive_input,num_test_input1_rate,test_node_pq_input, rize_rate_input)

%Koopman_PF_V1
% �����޸���ά������ѡ������
% ����ѡ��������ݷ�Χ
% ��������PQ�ڵ��PQ��PV�ڵ��PV
% �������PQ�ڵ��V,��֧·�׶˵��й����ʡ��޹�����

Read_Historic_Data=1;
% 
% clear,clc
% close all;
%case24_ieee_rts
%case118
%case33bw

case_name_or=case_name_input;
case_name=Transfer_node_num_to_consecutive(case_name_or);  % �������нڵ��ţ�ʹ�������

A_result=runpf(case_name);

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);

pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;
pos_num_pv_p=[3,8];
pos_gen_pq=2:3;
pos_gen_p=2;
pos_gen_v=6;

P_rate=PQV_range_input(1);
Q_rate=P_rate/3;
PV_P_rate=PQV_range_input(2);
PV_V_rate=PQV_range_input(3);
% P_rate=60;
% Q_rate=P_rate/3;
% PV_P_rate=50;
% PV_V_rate=0.05;


PQ_1=case_name.bus(pq,[3,4]);
for i=1:length(PQ_1)
    if PQ_1(i,1)
        PQ_1(i,1)=PQ_1(i,1)/PQ_1(i,1);
    end
    if PQ_1(i,2)
        PQ_1(i,2)=PQ_1(i,2)/PQ_1(i,2);
    end
end

input_num=length(pq)*2+length(pv)*2;
output_num=length(pq)+2*length(case_name_or.branch);
case_name.bus(pq,pos_num_pq_pq)=0;
case_name.gen([pv_total;ref_pos],[pos_gen_p,pos_gen_v])=0;

% case_name.bus([pv;pq],pos_num_pq_pq)=0; %����matpowe�е�PV�ڵ����Դ�һ��
% PQ���ɣ�����������ڳ�����������ʵ�ǲ�������̼���ģ�����PQ���ɵ�P���ڼ���ǰ��PV�ڵ��P���PQ���ɵ�Q���ڳ����������PQ�ڵ��Q����
% �����ϣ�PV�ڵ��ϵ�PQ���ɣ���Ȼ����PV�ڵ��ṩ�ġ�
% ���������ļ����У�������ɿ���������һ���̶�ֵ�����ǲ�������Ϊ����������㣬��Ϊ������������������Ա������������ĳ������̽���������⡣
% ��Ȼ�������в�����Koopman��ʽʱ�������������������������Ͽ��Բ�һ�£������ۺϿ��ǵ��ڳ����ξ����α���������⣬���Ǻܿ�ȡ���п�����ɽϴ����


%% **********************��ά������ѡȡ*******

Using_M=2;   %���ּ���Mʱ�����Ĵ������� ʵ��ʹ��ʱ��𲻴�û��ϸ����
FUN_select=FUN_select_input;
TEST=TEST_input;
sensitive=sensitive_input;

%% **********************��ά������ѡȡ*******
%**************************************************
if FUN_select==1
    basisFunction = 'rbf';
    % RBF centers
    Nrbf = Nrbf_input;
    cent = rand(input_num,Nrbf);
    cent(1:length(pq),:)=cent(1:length(pq),:).*PQ_1(:,1)*P_rate;
    cent(length(pq)+1:2*length(pq),:)=cent(length(pq)+1:2*length(pq),:).*PQ_1(:,2)*Q_rate;
    cent(2*length(pq)+1:2*length(pq)+length(pv),:)=cent(2*length(pq)+1:2*length(pq)+length(pv),:)*PV_P_rate;
    cent(2*length(pq)+length(pv)+1:input_num,:)=cent(2*length(pq)+length(pv)+1:input_num,:)*PV_V_rate+1;
    rbf_type = 'invmultquad'; % 'thinplate' 'invquad'  'invmultquad'  'polyharmonic'
    % Lifting mapping - RBFs + the state itself
    liftFun = @(xx)( [xx;rbf_self_use(xx,cent,rbf_type)] );
    cent2 = rand(output_num,Nrbf);
    cent2(1:length(pq),:)=cent(1:length(pq),:).*A_result.bus(pq,8);
    cent2(length(pq)+1:2*length(pq),:)=cent(length(pq)+1:2*length(pq),:).*A_result.bus(pq,9);
    cent2(2*length(pq)+1:2*length(pq)+length(pv),:)=cent(2*length(pq)+1:2*length(pq)+length(pv),:).*A_result.bus(pv,9);
    % Lifting mapping - RBFs + the state itself
    liftFun2 = @(xx)( [xx;rbf_self_use(xx,cent2,rbf_type)] );
    Nlift = Nrbf + input_num;
end
if FUN_select==2
    liftFun = @(x)( [ x ; ones(1,size(x,2)) ; x(1:end-1,:).*(x(2:end,:)) ; x(1,:).*x(end,:) ; x.*x ]  ) ;
end
%**************************************************
%% ***************�����������ݵ�ѡȡ***********
%**************************************************
if ~Read_Historic_Data&&FUN_select==1
if TEST==1
    num=num_input;
    Input=zeros(input_num,num);
    Input(1:length(pq),:)=rand(length(pq),num).*PQ_1(:,1)*P_rate;% -P_rate/2;
    Input(length(pq)+1:2*length(pq),:)=rand(length(pq),num).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
    Input(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),num)*PV_P_rate;
    Input(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),num)*PV_V_rate+1;
    TEST=1;
end
%**************************************************
if TEST==2
    num=num_input;
    %     Input(1:length(pq),:)=rand(length(pq),num).*case_name_or.bus(pq,3)*2;
    %     Input(length(pq)+1:2*length(pq),:)=rand(length(pq),num).*case_name_or.bus(pq,4)*2;
    %     for i=1:length(pv)
    %         Input(2*length(pq)+i,:)=rand(1,num)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2))*2;  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
    % %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
    %         Input(2*length(pq)+length(pv)+i,:)=case_name_or.gen( pv_pos(i,1),6);
    %     end
    
    temp_range=temp_range_input;
    temp_range1=1-temp_range/2;
    Input(1:length(pq),:)=(rand(length(pq),num)*temp_range+temp_range1).*case_name_or.bus(pq,3);
    Input(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*temp_range+temp_range1).*case_name_or.bus(pq,4);
    for i=1:length(pv)
        Input(2*length(pq)+i,:)=(rand(1,num)*temp_range+temp_range1)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,:)=case_name_or.gen( pv_pos(i,1),6);
    end
end
%**************************************************
if TEST==3
    num1=num_input*num_test_input1_rate;
    num2=num_input*(1-num_test_input1_rate);
    num=num_input;
    Input=zeros(input_num,num);
    Input(1:length(pq),1:num1)=rand(length(pq),num1).*PQ_1(:,1)*P_rate;% -P_rate/2;
    Input(length(pq)+1:2*length(pq),1:num1)=rand(length(pq),num1).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
    Input(2*length(pq)+1:2*length(pq)+length(pv),1:num1)=rand(length(pv),num1)*PV_P_rate;
    Input(2*length(pq)+length(pv)+1:input_num,1:num1)=rand(length(pv),num1)*PV_V_rate+1;
    
    temp_range=temp_range_input;
    temp_range1=1-temp_range/2;
    Input(1:length(pq),(num1+1):num)=(rand(length(pq),num2)*temp_range+temp_range1).*case_name_or.bus(pq,3);
    Input(length(pq)+1:2*length(pq),(num1+1):num)=(rand(length(pq),num2)*temp_range+temp_range1).*case_name_or.bus(pq,4);
    for i=1:length(pv)
        Input(2*length(pq)+i,(num1+1):num)=(rand(1,num2)*temp_range+temp_range1)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,(num1+1+1):num)=case_name_or.gen( pv_pos(i,1),6);
    end
    
    
end

%**************************************************

%% %*********�����������*********************

Output=zeros(output_num,num_input);
SS=[];
tic

for i=1:num_input
    temp_iptpq_p=Input(1:length(pq),i);
    temp_iptpq_q=Input(length(pq)+1:2*length(pq),i);
    temp_iptpv_p=Input(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input(2*length(pq)+length(pv)+1:input_num,i);
    
    
    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,:)=case_name_or.gen(ref_pos,:);
    
    [result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    output1=result.bus(pq,8);
    output2=result.branch(:,14);
    output3=result.branch(:,15);
    
    Output(:,i)=[output1;output2;output3];
end
toc
Input=Input(:,SS);
Output=Output(:,SS);
end



if Read_Historic_Data&&FUN_select==1
    s1=ceil(rand()*(15000-num_input-2));
    range_temp=s1+1:s1+num_input;
Result=load('F:\����\koopman_PF\������\PF_IEEE118_50_50_0_14924_Result.mat');
Input=Result.Input(:,range_temp);
Output=Result.Output(:,range_temp);
end






if FUN_select==1
    Xp = liftFun(Input);
    Yp = liftFun2(Output);
end
if FUN_select==2
    Xp = liftFun(Input);
    Yp = liftFun(Output);
end

if Using_M==1
    W = Xp*Xp';
    V = Yp*Xp';
    M = V*pinv(W);
else
    M=Yp*pinv(Xp);
end


% ---------С����-----------
% 
% tic
% for i=1:1000
%     IPT1=liftFun(Input(:,i));
%     TPY=M*IPT1;
% end
% toc

%% *************��֤��������************

if TEST==1||TEST==3
    num_test=num_test_input;
    OPT_PF=zeros(num_test,output_num);
    OPT_kpm=zeros(num_test,output_num);
    
    
    
    for i=1:num_test
        
        Input_test=zeros(input_num,1);
        Input_test(1:length(pq),:)=rand(length(pq),1).*PQ_1(:,1)*P_rate; %-P_rate/2;
        Input_test(length(pq)+1:2*length(pq),:)=rand(length(pq),1).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
        Input_test(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),1)*PV_P_rate;
        Input_test(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),1)*PV_V_rate+1;
        
        temp_iptpq_p=Input_test(1:length(pq),1);
        temp_iptpq_q=Input_test(length(pq)+1:2*length(pq),1);
        temp_iptpv_p=Input_test(2*length(pq)+1:2*length(pq)+length(pv),1);
        temp_iptpv_v=Input_test(2*length(pq)+length(pv)+1:input_num,1);
        case_name1=case_name;
        
        case_name1.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
        %     case_name1.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
        for j=1:length(pv)
            case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
            case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
        end
        
        result_test=runpf(case_name1);
        output_testPF=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15)];
        OPT_PF(i,:)=output_testPF';
        
        IPT_test=liftFun(Input_test);
        if Using_M==1
            TPY=M*(IPT_test*IPT_test');
            OPT1=TPY(:,1)/IPT_test(1,1);
        else
            OPT1=M*IPT_test;
        end
        opt1=OPT1(1:output_num,1);
        OPT_kpm(i,:)=opt1';
        
    end
    
    OPT_PF_pq_Va=OPT_PF(:,1:length(pq));
    OPT_kpm_pq_Va=OPT_kpm(:,1:length(pq));
    
    OPT_PF_branch_p=OPT_PF(:,length(pq)+1:length(pq)+length(case_name.branch));
    OPT_kpm_branch_p=OPT_kpm(:,length(pq)+1:length(pq)+length(case_name.branch));
    %
    OPT_PF_branch_q=OPT_PF(:,length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    OPT_kpm_branch_q=OPT_kpm(:,length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    
    
    
    
    OPT_PF_pq_Va=reshape(OPT_PF_pq_Va,num_test*length(pq),1);
    OPT_kpm_pq_Va=reshape(OPT_kpm_pq_Va,num_test*length(pq),1);
    
    OPT_PF_branch_p=reshape(OPT_PF_branch_p,num_test*length(case_name.branch),1);
    OPT_kpm_branch_p=reshape(OPT_kpm_branch_p,num_test*length(case_name.branch),1);
    
    OPT_PF_branch_q=reshape(OPT_PF_branch_q,num_test*length(case_name.branch),1);
    OPT_kpm_branch_q=reshape(OPT_kpm_branch_q,num_test*length(case_name.branch),1);
    
    
    if Figurte_Out_Put
        figure;
        subplot(3,1,1)
        plot(OPT_PF_pq_Va);
        hold on;
        plot(OPT_kpm_pq_Va);
        legend('����������','Koopman')
        title('PQ�ڵ��ѹ��ֵ')
        subplot(3,1,2)
        plot(OPT_PF_branch_p);
        hold on;
        plot(OPT_kpm_branch_p);
        legend('����������','Koopman')
        title('֧·�й�����')
        subplot(3,1,3)
        plot(OPT_PF_branch_q);
        hold on;
        plot(OPT_kpm_branch_q);
        legend('����������','Koopman')
        title('֧·�޹�����')
        % subplot(4,1,4)
        % plot(OPT_PF_pv_Q);
        % hold on;
        % plot(OPT_kpm_pv_Q);
        % legend('����������','Koopman')
        % title('PV�ڵ��޹�����')
    end
    
    % 'ƽ���������';
    e_pq_p=mean(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)));
    e_pq_q=mean(abs((OPT_PF_branch_p-OPT_kpm_branch_p)));
    e_pv_sita=mean(abs((OPT_PF_branch_q-OPT_kpm_branch_q)));
    e_a_mean=[e_pq_p,e_pq_q,e_pv_sita];
    
    % '���������';
    e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)));
    e_pq_q=max(abs((OPT_PF_branch_p-OPT_kpm_branch_p)));
    e_pv_sita=max(abs((OPT_PF_branch_q-OPT_kpm_branch_q)));
    e_a_max=[e_pq_p,e_pq_q,e_pv_sita];
    % '�������'
    [e_a_mean;e_a_max];
    e_a_mean1=e_a_mean;
    e_a_max1=e_a_max;
    % % 'ƽ��������';
    % e_pq_p=mean(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
    % e_pq_q=mean(abs((OPT_PF_branch_p-OPT_kpm_branch_p)./OPT_PF_branch_p));
    % e_pv_sita=mean(abs((OPT_PF_branch_q-OPT_kpm_branch_q)./OPT_PF_branch_q));
    % e=[e_pq_p,e_pq_q,e_pv_sita];
    % emean=e*100;
    %
    % % '���������';
    % e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
    % e_pq_q=max(abs((OPT_PF_branch_p-OPT_kpm_branch_p)./OPT_PF_branch_p));
    % e_pv_sita=max(abs((OPT_PF_branch_q-OPT_kpm_branch_q)./OPT_PF_branch_q));
    % e=[e_pq_p,e_pq_q,e_pv_sita];
    % emax=e*100;
    % % '������'
    % [emean;emax];
end
%% ԭʼ���ݼ���
if TEST==2||TEST==3
    case_name_or1=Transfer_node_num_to_consecutive(case_name_or);
    [ref,pv, pq] = bustypes(case_name_or1.bus, case_name_or1.gen);
    
    
    
    Input_test=zeros(input_num,1);
    Input_test(1:length(pq),:)=case_name_or1.bus(pq,3);
    Input_test(length(pq)+1:2*length(pq),:)=case_name_or1.bus(pq,4);
    for i=1:length(pv)
        Input_test(2*length(pq)+i,1)=sum(case_name_or1.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        Input_test(2*length(pq)+length(pv)+i,1)=case_name_or1.gen( pv_pos(i,1),6);
    end
    
    IPT_test=liftFun(Input_test);
    if Using_M==1
        TPY=M*(IPT_test*IPT_test');
        OPT1=TPY(:,1)/IPT_test(1,1);
    else
        OPT1= M*IPT_test;
    end
    opt1=OPT1(1:output_num,1);
    
    result_test=runpf(case_name_or);
    output_testPF=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15)];
    
    if Figurte_Out_Put
        figure
        subplot(3,1,1)
        range=1:length(pq);
        plot(output_testPF(range),'--+')
        hold on;
        plot(opt1(range));
        xlabel('PQ�ڵ���')
        ylabel('��ѹ����ֵ')
        legend('IEEE118ϵͳ��׼���','���᷽��������');
        
        subplot(3,1,2)
        range=length(pq)+1:length(pq)+length(result_test.branch);
        plot(output_testPF(range),'--+')
        hold on;
        plot(opt1(range));
        xlabel('֧·���')
        ylabel('��·�׶��й�����/MW')
        legend('IEEE118ϵͳ��׼���','���᷽��������');
        
        subplot(3,1,3)
        range=length(pq)+length(result_test.branch)+1:length(pq)+2*length(result_test.branch);
        plot(output_testPF(range),'--+')
        hold on;
        plot(opt1(range));
        xlabel('֧·���')
        ylabel('��·ĩ���й�����/MVAR')
        legend('IEEE118ϵͳ��׼���','���᷽��������');
    end
    k_r1=opt1(1:length(pq));
    k_r2=opt1(length(pq)+1:length(pq)+length(case_name.branch));
    k_r3=opt1(length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    
    
    e1=mean(abs((k_r1-result_test.bus(pq,8))));
    e2=mean(abs((k_r2-result_test.branch(:,14)) ));
    e3=mean(abs((k_r3-result_test.branch(:,15)) ));
    e_a_mean=[e1,e2,e3];
    
    e1=max(abs((k_r1-result_test.bus(pq,8))));
    e2=max(abs((k_r2-result_test.branch(:,14)) ));
    e3=max(abs((k_r3-result_test.branch(:,15)) ));
    e_a_max=[e1,e2,e3];
    e_a_mean2=e_a_mean;
    e_a_max2=e_a_max;
    %     '�������'
    %     [e_a_mean;e_a_max];
    
    %     e1=mean(abs((k_r1-result_test.bus(pq,8))./result_test.bus(pq,8)));
    %     e2=mean(abs((k_r2-result_test.branch(:,14))./result_test.branch(:,14) ));
    %     e3=mean(abs((k_r3-result_test.branch(:,15))./result_test.branch(:,15) ));
    %     e=[e1,e2,e3];
    %     emean=e*100;
    %
    %     e1=max(abs((k_r1-result_test.bus(pq,8))./result_test.bus(pq,8)));
    %     e2=max(abs((k_r2-result_test.branch(:,14))./result_test.branch(:,14) ));
    %     e3=max(abs((k_r3-result_test.branch(:,15))./result_test.branch(:,15) ));
    %     e=[e1,e2,e3];
    %     emax=e*100;
    %     %'������'
    %     [emean;emax];
end

%% �����Ȳ��ԣ�
if TEST==2&&sensitive==1
    case_name_or1=Transfer_node_num_to_consecutive(case_name_or);
    [ref,pv, pq] = bustypes(case_name_or1.bus, case_name_or1.gen);
    
    
    %-------------�޸���ֵǰ�ĵ�һ�μ���--------------------------------------
    Input_test=zeros(input_num,1);
    Input_test(1:length(pq),:)=case_name_or1.bus(pq,3);
    Input_test(length(pq)+1:2*length(pq),:)=case_name_or1.bus(pq,4);
    for i=1:length(pv)
        Input_test(2*length(pq)+i,1)=sum(case_name_or1.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        Input_test(2*length(pq)+length(pv)+i,1)=case_name_or1.gen( pv_pos(i,1),6);
    end
    IPT_test=liftFun(Input_test);
    if Using_M==1
        TPY=M*(IPT_test*IPT_test');
        OPT1=TPY(:,1)/IPT_test(1,1);
    else
        OPT1= M*IPT_test;
    end
    opt1=OPT1(1:output_num,1);
    result_test=runpf(case_name_or);
    output_testPF1=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15)];
    
    
    test_node_pq=test_node_pq_input;
    rate_temp=rize_rate_input;
    % ��x��PQ�ڵ㸺�����Ӻ󣬳����ı仯�����
    case_name_or1.bus(pq(test_node_pq),3)=case_name_or1.bus(pq(test_node_pq),3)*rate_temp;%(rand()*1+0.5);
    
    %-------------�޸���ֵ��ĵڶ��μ���--------------------------------------
    Input_test=zeros(input_num,1);
    Input_test(1:length(pq),:)=case_name_or1.bus(pq,3);
    Input_test(length(pq)+1:2*length(pq),:)=case_name_or1.bus(pq,4);
    for i=1:length(pv)
        Input_test(2*length(pq)+i,1)=sum(case_name_or1.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        Input_test(2*length(pq)+length(pv)+i,1)=case_name_or1.gen( pv_pos(i,1),6);
    end
    IPT_test=liftFun(Input_test);
    if Using_M==1
        TPY=M*(IPT_test*IPT_test');
        OPT1=TPY(:,1)/IPT_test(1,1);
    else
        OPT1= M*IPT_test;
    end
    opt2=OPT1(1:output_num,1);
    result_test=runpf(case_name_or1);
    output_testPF2=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15)];
    
    
    %     figure;
    %     subplot(1,2,1)
    %     plot(output_testPF1)
    %     hold on;
    %     plot(opt1);
    %     legend('IEEE_PF','Kooman_PF');
    %     title('origin')
    %     subplot(1,2,2)
    %     plot(output_testPF2)
    %     hold on;
    %     plot(opt2);
    %     legend('IEEE_PF','Kooman_PF');
    %     title('fixed')
    
    k_r1=opt2(1:length(pq));
    k_r2=opt2(length(pq)+1:length(pq)+length(case_name.branch));
    k_r3=opt2(length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    
%     %---------------------�������ظ�-----------------
%     e1=mean(abs((k_r1-result_test.bus(pq,8))));
%     e2=mean(abs((k_r2-result_test.branch(:,14)) ));
%     e3=mean(abs((k_r3-result_test.branch(:,15)) ));
%     e_a_mean=[e1,e2,e3];
%     
%     e1=max(abs((k_r1-result_test.bus(pq,8))));
%     e2=max(abs((k_r2-result_test.branch(:,14)) ));
%     e3=max(abs((k_r3-result_test.branch(:,15)) ));
%     e_a_max=[e1,e2,e3];
%     [e_a_mean;e_a_max]
    
    %------------------------�����Ⱦ���------------------------------
    case_name_or2=Transfer_node_num_to_consecutive(case_name_or);
    PFResult=runpf(case_name_or2);
    [J,Y1,J2]=makeJac_20200713(PFResult.baseMVA, PFResult.bus, PFResult.branch, PFResult.gen, 1);
    Jca=full(J);
    Ybus=full(Y1);
    S1=J\eye(size(J));
    branch_num=length(case_name_or.branch);
    S_branch=zeros(branch_num,branch_num);
    for i=1:branch_num
        S_branch(PFResult.branch(i,1),PFResult.branch(i,2))=complex(PFResult.branch(i,14),PFResult.branch(i,15));
        S_branch(PFResult.branch(i,2),PFResult.branch(i,1))=complex(PFResult.branch(i,16),PFResult.branch(i,17));
    end
    node_num=length(case_name_or.bus);
    branch_series=1:branch_num;branch_series=branch_series';
    G=formG(J2,branch_series,PFResult.branch(:,1),PFResult.branch(:,2),S_branch/case_name_or.baseMVA,node_num);
    Gfull=full(G);
    %-----------------------ƫ����--------------------------------------
    
    PQdeta=zeros(length(case_name_or2.bus)*2,1);
    PQdeta(pq(test_node_pq),1)=Input_test(test_node_pq,:)*(rate_temp-1);
    PQdeta=PQdeta/case_name_or2.baseMVA;
    Vdeta=S1*PQdeta;
    Vmdeta=Vdeta(length(case_name_or2.bus)+1:2*length(case_name_or2.bus),1);
    RR2=PFResult.bus(:,8)-Vmdeta;
    RR2=RR2(pq);
    LPQdeta=Gfull*S1*PQdeta;
    LPQdeta=LPQdeta*case_name_or.baseMVA;
    LPdeta=LPQdeta(1:branch_num,1);
    LQdeta=LPQdeta(branch_num+1:2*branch_num,1);
    RLP3=PFResult.branch(:,14)-LPdeta;
    RLQ3=PFResult.branch(:,15)-LQdeta;
    R_s=[RR2;RLP3;RLQ3];
    if Figurte_Out_Put
        figure
        range=1:length(pq);
        subplot(3,1,1)
        plot(output_testPF1(range))
        hold on;
        plot(output_testPF2(range))
        plot(opt1(range));
        plot(opt2(range));
        plot(R_s(range));
        
        subplot(3,1,2)
        range=length(pq)+1:length(pq)+branch_num;
        plot(output_testPF1(range));
        hold on;
        plot(output_testPF2(range));
        plot(opt1(range));
        plot(opt2(range));
        plot(R_s(range));
        
        subplot(3,1,3)
        range=length(pq)+branch_num+1:length(pq)+2*branch_num;
        plot(output_testPF1(range));
        hold on;
        plot(output_testPF2(range));
        plot(opt1(range));
        plot(opt2(range));
        plot(R_s(range));
        legend('IEEE_PF_B','IEEE_PF_A','Kooman_PF_B','Kooman_PF_A','SPF');
    end
    
    %-----------------ר������ר��ͼ-------------
    %       figure
    %     range1=1:length(pq);
    %     hold on;
    %     plot(output_testPF2(range1),'--k','linewidth',2)
    %     plot(opt2(range1),'-+k');
    %     plot(R_s(range1),'-*k');
    %     xlabel('PQ�ڵ���')
    %     ylabel('��ѹ����ֵ')
    %     legend('ţ��-����ѷ����','���᷽��������','��ͳ�����Ⱦ�����㷽��');
    %     set(gca,'Fontsize',15)
    %
    %     figure
    %     range2=length(pq)+1:length(pq)+branch_num;
    %     hold on;
    %     plot(output_testPF2(range2),'--k','linewidth',2);
    %     plot(opt2(range2),'-+k');
    %     plot(R_s(range2),'-*k');
    %     xlabel('֧·���')
    %     ylabel('��·�׶��й�����/MW')
    %     legend('ţ��-����ѷ����','���᷽��������','��ͳ�����Ⱦ�����㷽��');
    %     set(gca,'Fontsize',15)
    %
    %     figure
    %     range3=length(pq)+branch_num+1:length(pq)+2*branch_num;
    %     hold on;
    %     plot(output_testPF2(range3),'--k','linewidth',2);
    %     plot(opt2(range3),'-+k');
    %     plot(R_s(range3),'-*k');
    %     xlabel('֧·���')
    %     ylabel('��·�׶��й�����/MW')
    %     legend('ţ��-����ѷ����','���᷽��������','��ͳ�����Ⱦ�����㷽��');
    %     set(gca,'Fontsize',15)
    
    %��������������������������������
    e1=mean(abs(    output_testPF2(range1)-opt2(range1)   ));
    e2=mean(abs(    output_testPF2(range2)-opt2(range2) ));
    e3=mean(abs(    output_testPF2(range3)-opt2(range3) ));
    e_s_mean=[e1,e2,e3];
    
    e1=max(abs( output_testPF2(range1)-opt2(range1)));
    e2=max(abs( output_testPF2(range2)-opt2(range2) ));
    e3=max(abs( output_testPF2(range3)-opt2(range3) ));
    e_s_max=[e1,e2,e3];
%     [e_a_mean;e_a_max];
    e_s_mean2=e_s_mean;
    e_s_max2=e_s_max;
    
    %���������������Ⱦ���������ʽ������������
%     e1=mean(abs(    output_testPF2(range1)-R_s(range1)   ));
%     e2=mean(abs(    output_testPF2(range2)-R_s(range2) ));
%     e3=mean(abs(    output_testPF2(range3)-R_s(range3) ));
%     e_a_mean=[e1,e2,e3];
%     
%     e1=max(abs( output_testPF2(range1)-R_s(range1)));
%     e2=max(abs( output_testPF2(range2)-R_s(range2) ));
%     e3=max(abs( output_testPF2(range3)-R_s(range3) ));
%     e_a_max=[e1,e2,e3];
%     [e_a_mean;e_a_max];
%     
    
    
    
end
%%
if TEST==1&&sensitive==1
    '�����ȷ���'
    case_name1=Transfer_node_num_to_consecutive(case_name_or);
    %-------------�޸���ֵǰ�ĵ�һ�μ���--------------------------------------
    
    num_test=1;
    Input_test=zeros(input_num,num_test);
    Input_test(1:length(pq),:)=rand(length(pq),num_test).*PQ_1(:,1)*P_rate;% -P_rate/2;
    Input_test(length(pq)+1:2*length(pq),:)=rand(length(pq),num_test).*PQ_1(:,2)*Q_rate; %-Q_rate/2;
    Input_test(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),num_test)*PV_P_rate;
    Input_test(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),num_test)*PV_V_rate+1;
    
    temp_iptpq_p=Input_test(1:length(pq),1);
    temp_iptpq_q=Input_test(length(pq)+1:2*length(pq),1);
    temp_iptpv_p=Input_test(2*length(pq)+1:2*length(pq)+length(pv),1);
    temp_iptpv_v=Input_test(2*length(pq)+length(pv)+1:input_num,1);
    
    case_name1.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name1.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    
    result_test=runpf(case_name1);
    output_testPF1=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15)];
    
    IPT_test=liftFun(Input_test);
    if Using_M==1
        TPY=M*(IPT_test*IPT_test');
        OPT1=TPY(:,1)/IPT_test(1,1);
    else
        OPT1= M*IPT_test;
    end
    opt1=OPT1(1:output_num,1);
    
    % --------------��x��PQ�ڵ㸺�����Ӻ󣬳����ı仯����� -------------------
    
    test_node_pq=test_node_pq_input;
    rate_temp=rize_rate_input; %�޸Ĺ��ʵĽڵ�Ĺ��ʷŴ���
    Input_test(test_node_pq,:)= Input_test(test_node_pq,:)*rate_temp;
    
    %-------------�޸���ֵ��ĵڶ��μ���--------------------------------------
    temp_iptpq_p=Input_test(1:length(pq),1);
    temp_iptpq_q=Input_test(length(pq)+1:2*length(pq),1);
    temp_iptpv_p=Input_test(2*length(pq)+1:2*length(pq)+length(pv),1);
    temp_iptpv_v=Input_test(2*length(pq)+length(pv)+1:input_num,1);
    case_name1.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    for j=1:length(pv)
        case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    result_test=runpf(case_name1);
    output_testPF2=[result_test.bus(pq,8);result_test.branch(:,14);result_test.branch(:,15)];
    
    IPT_test=liftFun(Input_test);
    if Using_M==1
        TPY=M*(IPT_test*IPT_test');
        OPT1=TPY(:,1)/IPT_test(1,1);
    else
        OPT1= M*IPT_test;
    end
    opt2=OPT1(1:output_num,1);
    
    %     figure;
    %     subplot(1,2,1)
    %     plot(output_testPF1)
    %     hold on;
    %     plot(opt1);
    %     legend('IEEE_PF','Kooman_PF');
    %     title('origin')
    %     subplot(1,2,2)
    %     plot(output_testPF2)
    %     hold on;
    %     plot(opt2);
    %     legend('IEEE_PF','Kooman_PF');
    %     title('fixed')
    
    k_r1=opt2(1:length(pq));
    k_r2=opt2(length(pq)+1:length(pq)+length(case_name.branch));
    k_r3=opt2(length(pq)+length(case_name.branch)+1:length(pq)+2*length(case_name.branch));
    
    e1=mean(abs((k_r1-result_test.bus(pq,8))));
    e2=mean(abs((k_r2-result_test.branch(:,14)) ));
    e3=mean(abs((k_r3-result_test.branch(:,15)) ));
    e_s_mean=[e1,e2,e3];
    
    e1=max(abs((k_r1-result_test.bus(pq,8))));
    e2=max(abs((k_r2-result_test.branch(:,14)) ));
    e3=max(abs((k_r3-result_test.branch(:,15)) ));
    e_s_max=[e1,e2,e3];
    [e_s_mean;e_s_max];
    e_s_mean1=e_s_mean;
    e_s_max1=e_s_max;
    %-------------ʹ�û�׼�����Ի���������Ⱦ������ƫ����--------------------------------------
    PFResult=runpf(case_name1);
    [J,Y1,J2]=makeJac_20200713(PFResult.baseMVA, PFResult.bus, PFResult.branch, PFResult.gen, 1);
    % [J,Y1]=makeJac(PFResult.baseMVA, PFResult.bus, PFResult.branch, PFResult.gen, 0);
    Jca=full(J);
    Ybus=full(Y1);
    S1=J\eye(size(J));
    branch_num=length(case_name_or.branch);
    S_branch=zeros(branch_num,branch_num);
    for i=1:branch_num
        S_branch(PFResult.branch(i,1),PFResult.branch(i,2))=complex(PFResult.branch(i,14),PFResult.branch(i,15));
        S_branch(PFResult.branch(i,2),PFResult.branch(i,1))=complex(PFResult.branch(i,16),PFResult.branch(i,17));
    end
    node_num=length(case_name_or.bus);
    branch_series=1:branch_num;branch_series=branch_series';
    G=formG(J2,branch_series,PFResult.branch(:,1),PFResult.branch(:,2),S_branch/case_name_or.baseMVA,node_num);
    Gfull=full(G);
    %------------������ƫ��������--------------------------------------------------------------
    PQdeta=zeros(length(case_name1.bus)*2,1);
    PQdeta(pq(test_node_pq),1)=Input_test(test_node_pq,:)*(rate_temp-1);
    PQdeta=PQdeta/case_name1.baseMVA;
    Vdeta=S1*PQdeta;
    Vmdeta=Vdeta(length(case_name1.bus)+1:2*length(case_name1.bus),1);
    RR2=PFResult.bus(:,8)-Vmdeta;
    RR2=RR2(pq);
    LPQdeta=Gfull*S1*PQdeta;
    LPQdeta=LPQdeta*case_name_or.baseMVA;
    LPdeta=LPQdeta(1:branch_num,1);
    LQdeta=LPQdeta(branch_num+1:2*branch_num,1);
    RLP3=PFResult.branch(:,14)-LPdeta;
    RLQ3=PFResult.branch(:,15)-LQdeta;
    R_s=[RR2;RLP3;RLQ3];
    
    % --��ͼ---
    if Figurte_Out_Put
        figure
        range=1:length(pq);
        subplot(3,1,1)
        plot(output_testPF1(range))
        hold on;
        plot(output_testPF2(range))
        plot(opt1(range));
        plot(opt2(range));
        plot(R_s(range));
        
        subplot(3,1,2)
        range=length(pq)+1:length(pq)+branch_num;
        plot(output_testPF1(range));
        hold on;
        plot(output_testPF2(range));
        plot(opt1(range));
        plot(opt2(range));
        plot(R_s(range));
        
        subplot(3,1,3)
        range=length(pq)+branch_num+1:length(pq)+2*branch_num;
        plot(output_testPF1(range));
        hold on;
        plot(output_testPF2(range));
        plot(opt1(range));
        plot(opt2(range));
        plot(R_s(range));
        legend('IEEE_PF_B','IEEE_PF_A','Kooman_PF_B','Kooman_PF_A','SPF');
    end
    
    
    
end


end



