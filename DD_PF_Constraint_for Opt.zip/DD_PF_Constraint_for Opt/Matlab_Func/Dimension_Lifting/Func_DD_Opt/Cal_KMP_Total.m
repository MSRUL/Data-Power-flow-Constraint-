function [M,M_Struct,M_Output,beta_PLS,M_Ridge] = Cal_KMP_Total(Data,IDL_Peremeters,Train_Ops)
%UNTITLED 此处提供此函数的摘要
%   此处提供详细说明
Input=Data.Input;
Output=Data.Output;

rbf_type=IDL_Peremeters.rbf_type;
RisePos=IDL_Peremeters.RisePos;
IDL_Peremeters.type;

Train_Ops;
%%
Un_RisePos=Find_Wihtout_Which([1:size(Input,1)],RisePos);

[Lifted_Vector] = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
Lifted_Vector.XP;
Lifted_Vector.Input_Lifted;
 fprintf('\n【REGRESSION】start');
%%
switch Train_Ops.way
    case 'LS_OR' % Classical Least Squares

%         Using_M=1;
        Using_M=Train_Ops.M_Type;
        if Using_M==1 %Use the Traditional Least Squares Method to Calculate the Matrix M
            W = Lifted_Vector.Input_Lifted*Lifted_Vector.Input_Lifted';
            V = Output*Lifted_Vector.Input_Lifted';
            M = V*pinv(W);
        else %Use the Direct Calculate the Matrix M
            M=Output*pinv(Lifted_Vector.Input_Lifted);
        end
        y_test=M*Lifted_Vector.Input_Lifted;
    
end
Error_temp.mean=mean(mean(abs(y_test-Output)));
Error_temp.max=max(max(abs(y_test-Output)));

%%
M_Struct.MS=M(:,1:size(Lifted_Vector.XP,1));
M_Struct.M1=M(:,1+size(Lifted_Vector.XP,1):end);

M_Output.M_Incompelet=M;
M_Output.M_Struct=M_Struct;

[Output_test] = Case_PF_Accuracy_Test(IDL_Peremeters,M,M_Struct,Data.Input);

fprintf('\n【LS Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Output-Output_test))),max(max(abs(Output-Output_test))));


 fprintf('\n【REGRESSION】end\n\n');
end