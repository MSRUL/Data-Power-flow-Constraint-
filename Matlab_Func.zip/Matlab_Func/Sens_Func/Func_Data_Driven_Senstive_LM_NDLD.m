function [M] = Func_Data_Driven_Senstive_LM_NDLD(Data,DLR_Parameter)
%UNTITLED4 此处提供此函数的摘要
%   此处提供详细说明
%% Parameters Init
DLR_Parameter.Nrbf1=10; % Number of the lifting dimension ; The larger the value, the higher the accuracy, but the more serious the overfitting problem is.
DLR_Parameter.rbf_type='2n+1';  % Chose:  (1)'polyharmonic'  (2)'invmultquad' (3)'invquad'  (4)'3n+1'  (5)'2n+1'
DLR_Parameter.cent=rand(size(Data.Input,1),DLR_Parameter.Nrbf1); % Default
DLR_Parameter.Using_M=0;   % Default:0 ;  Chose: 1/0

%% Trainning Stage
%(1)Training the mapping matrix M (linear regression)
[M] = Cal_M_Koopman_Total(Data,DLR_Parameter);% Matrix M contains the mapping relationship
%(2)Regression accuracy test
% [Output_Test] = Cal_DLR(Data.Input,M,DLR_Parameter);



test_ID=1;
Input_single_Direciton=zeros(size(Data.Input,1),size(Data.Input,1));
for i=1:Input_single_Direciton
    Input_single_Direciton(i,i)=2*Data.Input(i,test_ID);
end
M_sens=M(:,1:size(Data.Input,1))+2*M(:,2+size(Data.Input,1):2*size(Data.Input,1)+1)*Input_single_Direciton;

end