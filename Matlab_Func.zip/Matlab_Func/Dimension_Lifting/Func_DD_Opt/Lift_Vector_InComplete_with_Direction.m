function [XS] = Lift_Vector_InComplete_with_Direction(inputArg_single,rbf_type,cent,RisePos)
%UNTITLED 此处提供此函数的摘要
%   此处提供详细说明

Un_RisePos=Find_Wihtout_Which([1:size(inputArg_single,1)],RisePos);
%%
XC=zeros(length(RisePos),length(Un_RisePos)); % XC: Time variable
for i=1:length(Un_RisePos)
    XC(:,i)=inputArg_single(RisePos,1);
end
lift_inpuit_E=eye(length(Un_RisePos));
x_temp=[XC;lift_inpuit_E];
XS=Lift_Vector_Complete(x_temp,rbf_type,cent); % XS: Time variable(for xc)

end