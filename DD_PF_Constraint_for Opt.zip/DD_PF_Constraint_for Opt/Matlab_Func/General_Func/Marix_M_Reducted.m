function [M_Reducted] = Marix_M_Reducted(M,X,Y,standard_way)
%Marix_M_Reducted Use with [fuction]: Data_Column_vector_standardization
%
M_Reducted=M;
switch standard_way
    case 'meanvalue'
        for i =1:size(M_Reducted,1)
            M_Reducted(i,:)=M_Reducted(i,:)./X.Mean';
            M_Reducted(i,:)=M_Reducted(i,:)*Y.Mean(i)';
        end
    case '0-1lize'
        ;
end
end