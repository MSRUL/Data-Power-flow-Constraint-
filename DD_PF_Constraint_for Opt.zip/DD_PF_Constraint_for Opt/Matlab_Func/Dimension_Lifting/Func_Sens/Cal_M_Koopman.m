function [M,M_Inverse] = Cal_M_Koopman(inputData,OutputData,rbf_type,rbf_type_Inverse,cent_input,cent_output)
%UNTITLED 此处显示有关此函数的摘要

%% Lift the Input
Xp = Lift_Vector_Complete(inputData,rbf_type,cent_input);

%% Lift the Output
Yp = Lift_Vector_Complete(OutputData,rbf_type_Inverse,cent_output);

%%
Using_M=0;  %是否使用�?小二乘法的最基本形式
if Using_M==1
    W = Xp*Xp';
    V = OutputData*Xp';
    M = V*pinv(W);
    
    W = Yp*Yp';
    V = inputData*Yp';
    M_Inverse = V*pinv(W);
else
    M=OutputData*pinv(Xp);
    M_Inverse=inputData*pinv(Yp);
end
%% ---------time cost test--------------
% tic
% Xp = Lift_Vector_Complete(inputData,rbf_type,cent_input);
% W = Xp*Xp';
% V = OutputData*Xp';
% M = V*pinv(W);
% toc
% % ---------time cost test--------------
end

