function [Data_Record] = Voltage_Regulation_Simple(Data_Record,M,M_Sens_DDGS,AdjIndex,DLR_Parameter,Parameters_Index)
% Step by Step to Regulate the Voltage.
% ZYX 20220531
%%
% AdjIndex.Voltage.max;
% AdjIndex.Voltage.min;
% AdjIndex.adjust_P_step;
% AdjIndex.adjust_Q_step;
% AdjIndex.PV_Q_Limit_Rate;
% 
% Parameters_Index.INclude_PV_S;
% Parameters_Index.Pos_P_in_Inventer;
% Parameters_Index.Pos_Q_in_Inventer;
% 
% Data_Record.Input;
% Data_Record.Output;

DLR_Parameter_PF=DLR_Parameter.PF;
DLR_Parameter_Sens=DLR_Parameter.Sen;

pq=Parameters_Index.pq;

%%
%%
% Adj_T=0; % init the Transformer Tab Adjust start
Adj_Q=1; %  init the Reactive Power if PV Inventer Adjust start
Adj_P=0; %  init the Active Power if PV Inventer Adjust start
%%

OUTPUT_Record=Data_Record.Output;
INPUT_Record=Data_Record.Input;
Adj_Input=Data_Record.Input(:,end);
% M_V_Rank=Senstive_M;
numof_PV_inventor=[1,1,1]; 

switch AdjIndex.Mode  % 'Variable_SensMatrix'
    case 'Fix_SensMatrix'
        M_V_Rank=M_Sens_DDGS.Direct_Linear_Sens;
    case 'Variable_SensMatrix'
        Adj_Input_temp=Data_Record.Input(1:length(pq)*2,:)-Data_Record.Input([Parameters_Index.Pos_P_in_Inventer,Parameters_Index.Pos_Q_in_Inventer],:);
        M_V_Rank = Cal_Sens_DDGS(Adj_Input_temp,M_Sens_DDGS.M_BZ,M_Sens_DDGS.Direct_Linear_Sens,DLR_Parameter_Sens,M_Sens_DDGS.Num);
end

%%
Over_Voltage=find(Data_Record.Output(:,end)>AdjIndex.Voltage.max);

%%
P_exhausted=[];
Q_exhausted=[];
while(length(Over_Voltage)>0) % the number of over voltage bus is not 0
    

    if Adj_P&&length(Over_Voltage)>0  %Start to Adject the Active Power if PV Inventer
%         for i=1:length(Over_Voltage)
            temp_i=find(OUTPUT_Record(:,end)==max(OUTPUT_Record(:,end)));
            i=find(Over_Voltage==temp_i);
            [numof_PV_inventor]=find(  abs(M_V_Rank(Over_Voltage(i),Parameters_Index.Pos_P_in_SensMatrix))==max(abs(M_V_Rank(Over_Voltage(i),Parameters_Index.Pos_P_in_SensMatrix))) );  %Find the most sensitive bus with PV Inventer Active Power
            if length(numof_PV_inventor)>1
                stophere=1;
            else
                ;
            end

            B_direction=-1;
            if Adj_Input(Parameters_Index.Pos_P_in_Inventer(numof_PV_inventor),1)+B_direction*AdjIndex.adjust_P_step>=0 %after the Adjustment wheather the input still meet its limit
                Adj_Input(Parameters_Index.Pos_P_in_Inventer(numof_PV_inventor),1)=Adj_Input(Parameters_Index.Pos_P_in_Inventer(numof_PV_inventor),1)+B_direction*AdjIndex.adjust_P_step;
            else
                M_V_Rank(:,Parameters_Index.Pos_P_in_SensMatrix(numof_PV_inventor))=0;
                fprintf('\tThe Active power of inventer on bus %d has meet its limit\n',numof_PV_inventor)
                P_exhausted=[P_exhausted;numof_PV_inventor];
            end
    end
    if ~Adj_P
            temp_i=find(OUTPUT_Record(:,end)==max(OUTPUT_Record(:,end)));
            i=find(Over_Voltage==temp_i(1,1));
            if Adj_Q
                [numof_PV_inventor]=find(  abs(M_V_Rank(Over_Voltage(i),Parameters_Index.Pos_Q_in_SensMatrix))==max(abs(M_V_Rank(Over_Voltage(i),Parameters_Index.Pos_Q_in_SensMatrix))) );  %Find the most sensitive bus with PV Inventer Reactive Power
            end
            if length(numof_PV_inventor)>1  %if is over 1 ,it means that all the PV inventer Reactive power meets the limit
                % Transformer Tab involved %
                % Transformer Tab involved %                 if Device_Info.Transformer_Tab_state
                % Transformer Tab involved %                     if Adj_Input(Pos_In_OutPut.Pos_TransTab,1)<max(Pos_In_OutPut.Transformer_Tab) %Transformer has adjustable margin
                % Transformer Tab involved %                         Adj_Input(Pos_In_OutPut.Pos_TransTab,1)=Adj_Input(Pos_In_OutPut.Pos_TransTab,1)+Device_Info.Transformer_Tab_Step;
                % Transformer Tab involved %                         Adj_Input(1:Pos_TransTab-1,1)=Input_Standard(1:Pos_TransTab-1,end); % Init other input except the Transformer Tab
                % Transformer Tab involved %                         [Senstive_M] = Koopman_Senstive_Matric(Adj_Input,rbf_type,cent_input_compelete,M_V);
                % Transformer Tab involved %                         M_V_Rank=Senstive_M;
                % Transformer Tab involved %                     end
                % Transformer Tab involved %                 else
                Adj_P=1; %Start to Adjust the Active Power of PV Inventer (Here the Reactive Power and the transformer Tab is nolonger avaliable )
                Adj_Q=0;
                % Transformer Tab involved %                 end
            end
            if ~Adj_P % if the Active Power not Start Yet
                B_direction=-1; %Some of the Direction is Untrustfull ,so we determaine it by the low of Traditional relationship
                %% (1)PV Inverter Output Constraint
                PV_Q_Limit_Rate=AdjIndex.PV_Q_Limit_Rate;
                if (Adj_Input(Parameters_Index.Pos_Q_in_Inventer(numof_PV_inventor),1)^2+Adj_Input(Parameters_Index.Pos_Q_in_Inventer(numof_PV_inventor),1)^2)<Parameters_Index.INclude_PV_S(numof_PV_inventor)^2 ...
                        && abs(Adj_Input(Parameters_Index.Pos_Q_in_Inventer(numof_PV_inventor),1))<Parameters_Index.INclude_PV_S(numof_PV_inventor)*PV_Q_Limit_Rate
                    Adj_Input(Parameters_Index.Pos_Q_in_Inventer(numof_PV_inventor),1)=Adj_Input(Parameters_Index.Pos_Q_in_Inventer(numof_PV_inventor),1)+B_direction*AdjIndex.adjust_Q_step; 
                else
                    M_V_Rank(:,Parameters_Index.Pos_Q_in_SensMatrix(numof_PV_inventor))=0;
                    fprintf( '\tThe Active power of inventer on bus %d has meet its limit\n',numof_PV_inventor);
                    Q_exhausted=[Q_exhausted;numof_PV_inventor];
                end
            end
%         end
    end

    switch AdjIndex.PFMode
        case 'KPM'
            Voltage_Output=Cal_DLR(Adj_Input,M.KPM,DLR_Parameter_PF);
        case 'LPF'
            Voltage_Output=M.LPF*Adj_Input;
    end

    %----------------------------------
    %-------Option1--start------Koopman PF ----------------------------------
    OUTPUT_Record=[OUTPUT_Record,Voltage_Output];
    INPUT_Record=[INPUT_Record,Adj_Input];
    Over_Voltage=find(Voltage_Output>AdjIndex.Voltage.max);
    %-------Option1--start------Koopman PF ----------------------------------
    %-------Option2--end------NR PF ----------------------------------
%     [Output_Standard]=NR_PF_Cal(case_name,Adj_Input,INclude_PV_node_Pos,INclude_PV_S,1);
%     OUTPUT_Record=[OUTPUT_Record,Output_Standard.Vm];
%     INPUT_Record=[INPUT_Record,Adj_Input];
%     Over_Voltage=find(Output_Standard.Vm>Voltage.max);
    %-------Option2--end------NR PF ----------------------------------
    %% Update the Sensitive 【test】

    Adj_Input_temp=Adj_Input(1:length(pq)*2,:)-Adj_Input([Parameters_Index.Pos_P_in_Inventer,Parameters_Index.Pos_Q_in_Inventer],:);
    switch AdjIndex.Mode  % 'Variable_SensMatrix'
        case 'Fix_SensMatrix'
            M_V_Rank;  %Not Updated 
        case 'Variable_SensMatrix'
            M_V_Rank = Cal_Sens_DDGS(Adj_Input_temp,M_Sens_DDGS.M_BZ,M_Sens_DDGS.Direct_Linear_Sens,DLR_Parameter_Sens,M_Sens_DDGS.Num);
            M_V_Rank(:,Parameters_Index.Pos_Q_in_SensMatrix(Q_exhausted))=0;
    end
end

Data_Record.Input=[Data_Record.Input,INPUT_Record];
Data_Record.Output=[Data_Record.Output,OUTPUT_Record];

end