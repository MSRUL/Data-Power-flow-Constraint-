function [Print_Item,Info] = Print_Chinese_Words(Input_controled,Input_Standard,INclude_PV_node,Pos_In_OutPut)
%UNTITLED2 此处显示有关此函数的摘要
%   此处显示详细说明





Contrled_Item=Input_controled-Input_Standard;
    %----------光伏无功功率调节�?-------------------------------------
    contrled_PV_Q_Pos=find(Contrled_Item(Pos_In_OutPut.Pos_Q_in_Input,:)~=0);
    str_PV_Q='Reactive Power of PV Inventer Node';
    for i=1:length(contrled_PV_Q_Pos)
         str_PV_Q=strcat(str_PV_Q,num2str(INclude_PV_node(contrled_PV_Q_Pos(i))),' , ');
    end
    str_PV_Q=strcat(str_PV_Q,'\n The Adjust step is');
    for i=1:length(contrled_PV_Q_Pos)
         str_PV_Q=strcat(str_PV_Q,num2str( Contrled_Item(Pos_In_OutPut.Pos_PV_Q_Inventer_Start+contrled_PV_Q_Pos(i))),'kVar');
    end
%     fprintf('%s\n',str_PV_Q)
    %---------变压器分接头调节�?--------------------------------------
    str_Tras_Tab='\n\nTransformer Tab';
    str_Tras_Tab=strcat(str_Tras_Tab,num2str(Contrled_Item(Pos_In_OutPut.Pos_TransTab,:)));
%     fprintf('%s\n',str_Tras_Tab)
    %-----------光伏有功功率调节�?------------------------------------
    contrled_PV_P_Pos=find(Contrled_Item(Pos_In_OutPut.Pos_P_in_Input,:)~=0);
    str_PV_P='\n\nActive Power of PV Inventer';
    for i=1:length(contrled_PV_P_Pos)
         str_PV_P=strcat(str_PV_P,num2str(INclude_PV_node(contrled_PV_P_Pos(i))),' , ');
    end
    str_PV_P=strcat(str_PV_P,',  \nThe Adjust step is ');
    for i=1:length(contrled_PV_P_Pos)
         str_PV_P=strcat(str_PV_P,num2str( Contrled_Item(Pos_In_OutPut.Pos_PV_P_Inventer_Start+contrled_PV_P_Pos(i))),'kW');
    end
%     fprintf('%s\n',str_PV_P)
    Print_Item.str_PV_Q=str_PV_Q;
    Print_Item.str_Tras_Tab=str_Tras_Tab;
    Print_Item.str_PV_P=str_PV_P;
    
    Info.PV_Q_num_and_adj=[INclude_PV_node(contrled_PV_Q_Pos);Contrled_Item(Pos_In_OutPut.Pos_PV_Q_Inventer_Start+contrled_PV_Q_Pos)'];
    Info.PV_P_num_and_adj=[INclude_PV_node(contrled_PV_P_Pos);Contrled_Item(Pos_In_OutPut.Pos_PV_P_Inventer_Start+contrled_PV_P_Pos)'];
    Info.TransTab_adj=Contrled_Item(Pos_In_OutPut.Pos_TransTab,:);
    
end

