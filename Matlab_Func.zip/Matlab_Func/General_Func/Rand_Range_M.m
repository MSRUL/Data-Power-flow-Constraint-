function [outputArg1] = Rand_Range_M(DR,UR)

outputArg1=rand(size(DR)).*(UR-DR)+DR;

end