function [Data_reducted] = Data_Column_vector_standard_reduction(Data)
% Data_Column_vector_standard_reduction Use with [fuction]: Data_Column_vector_standardization
% ZYX_20200301

switch Data.standard_way
    case 'meanvalue'
        Data_reducted=Data.Standarded;
        for i =size(inputData,2)
            Data_reducted(:,i)=Data_reducted(:,i).*Data.Mean;
        end
    case '0-1lize'
        Data_reducted=Data.Standarded;
        for i =size(inputData,2)
            Data_reducted(:,i)=Data_reducted(:,i).*(Data.Max-Data.Min)+Data.Min;
        end
end
end