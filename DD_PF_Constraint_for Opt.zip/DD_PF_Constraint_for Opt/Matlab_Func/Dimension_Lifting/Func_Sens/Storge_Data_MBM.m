function [] = Storge_Data_MBM(Objective_type,case_chose,Qno0,path_last,Result_CPLEX)
% MBM Model Based Method
if Qno0
        switch Objective_type
            case 'Min Adjustment'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_deltaQ_case116_Qno0.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_deltaQ_case109_Qno0.mat'),'Result_CPLEX');
                end
            case 'Min Loss'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case116_Qno0.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case109_Qno0.mat'),'Result_CPLEX');
                end
            case 'Hybrid'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case116_Qno0.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case109_Qno0.mat'),'Result_CPLEX');
                end
            case 'Min_Voltage_deviation_rate'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case116_Qno0.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case109_Qno0.mat'),'Result_CPLEX');
                end
            case   'Min_VDR_and_Min_Adj'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDRandQAdj_case116_Qno0.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDRandQAdj_case109_Qno0.mat'),'Result_CPLEX');
                end
            case   'DG_Consumption'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case116_Qno0.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case109_Qno0.mat'),'Result_CPLEX');
                end
        end
    else
        switch Objective_type
            case 'Min Adjustment'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_deltaQ_case116.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_deltaQ_case109.mat'),'Result_CPLEX');
                end
            case 'Min Loss'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case116.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_PLoss_case109.mat'),'Result_CPLEX');
                end
            case 'Hybrid'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case116.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_Distflow_min_Hyb11_case109.mat'),'Result_CPLEX');
                end
            case 'Min_Voltage_deviation_rate'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case116.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDR_case109.mat'),'Result_CPLEX');
                end
            case 'Min_VDR_and_Min_Adj'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDRandQAdj_case116.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_min_VDRandQAdj_case109.mat'),'Result_CPLEX');
                end
            case   'DG_Consumption'
                switch case_chose
                    case 'case116'
                        save(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case116.mat'),'Result_CPLEX');
                    case 'case109'
                        save(strcat(path_last,'Result_CPLEX_DLPF_max_DG_Consumption_case109.mat'),'Result_CPLEX');
                end
        end
    end
end

