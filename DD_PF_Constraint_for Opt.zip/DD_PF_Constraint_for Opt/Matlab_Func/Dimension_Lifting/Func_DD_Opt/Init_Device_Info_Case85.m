function [Device_Info] = Init_Device_Info_Case85(case_name,have_PV)
%% This Func is only fit to case69  case69
if have_PV
    if size(case_name.bus,1)~=85
        fprintf('\n !!! Function of :''Init_Device_Info'', is Wrong! this func is only fit to case85');
        return ;
    end
end
%% Case Parameters
[ref,pv, pq,pv_pos,ref_pos,pv_total] = Case_Info(case_name);
Device_Info.ref=ref;
Device_Info.pv=pv;
Device_Info.pq=pq;
Device_Info.pv_pos=pv_pos;
Device_Info.ref_pos=ref_pos;
Device_Info.pv_total=pv_total;

line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
Device_Info.Branch_Num=Branch_Num;
Bus_Num=size(case_name.bus,1);
Device_Info.Bus_Num=Bus_Num;

%% Photovoltaic , Capacitor , Transformer Tab  Information
% have_PV=1;
if have_PV
    %-----------------several cases use the same parameters , DO NOT DELET!!!!!!
    Device_Info.INclude_PV_node=2:4:82;  %Bus ID with Photovoltaic %��Different Case Difference 20220815��
    Device_Info.INclude_PV_node_str={'2','6','10','14','18','22','26','30','34','38','42','46','50','54','58',...
        '62','66','70','74','78','82'};%��Different Case Difference 20220815��
    
    Device_Info.INclude_PV_S=ones(size(Device_Info.INclude_PV_node))*600;  %Photovoltaic Capcity%��Different Case Difference 20220815��
    Device_Info.INclude_PV_S=Device_Info.INclude_PV_S/1000;

    Device_Info.INclude_PV_node_Pos=zeros(size(Device_Info.INclude_PV_node));   %Position of photovoltaic in PQbus
    for i=1:length(Device_Info.INclude_PV_node)
        Device_Info.INclude_PV_node_Pos(1,i)=(find(pq==Device_Info.INclude_PV_node(i)));
    end
else
    Device_Info.INclude_PV_node=[];  %Bus ID with Photovoltaic
    Device_Info.INclude_PV_S=[];  %Photovoltaic Capcity
    Device_Info.INclude_PV_node_Pos=[];
    %     fprintf('No PhotoVoltaik in Grid! \n');
end

Device_Info.PV_rate=1;

Device_Info.INclude_PV_S= Device_Info.INclude_PV_S*Device_Info.PV_rate;

Device_Info.input_Cbank=[0,20,40,60,80];  %Capacitor bank capacity
Device_Info.input_Cbank=Device_Info.input_Cbank/1000;
Device_Info.input_Cbank_state=0;   %Weather Considering the Capacitor 1:Yes;  0:No

Device_Info.Transformer_Tab_Step=0.0125;
Device_Info.Transformer_Tab=0.9625:Device_Info.Transformer_Tab_Step:1.0375;
Device_Info.Transformer_Tab=1;
Device_Info.Transformer_Tab_state=0;   %Weather Considering the Capacitor 1:Yes;  0:No

%%  Input Vector Sise Number
Device_Info.Input_Num=size(pq,1)*2+size(pv,1)*2+1+Device_Info.input_Cbank_state+length(Device_Info.INclude_PV_node)*2+Device_Info.Transformer_Tab_state;
Device_Info.Standard_Num=size(pq,1)*2+size(pv,1)*2+1+length(Device_Info.INclude_PV_node)*2;
% The Active and Reactive PQLoad, Active Power of PV Load, Voltage magnitude of PV bus, Voltage magnitude of slack bus, number of capacity of Capacitor, The Active and Reactive Photovoltaic�� Tab of Transformer

Device_Info.Input_Net_Num=size(pq,1)*2+size(pv,1)*2+1+Device_Info.input_Cbank_state+Device_Info.Transformer_Tab_state;

InputItem='OR';
if have_PV ;InputItem=strcat(InputItem,'DGnum.',num2str(length(Device_Info.INclude_PV_node))); end
if Device_Info.input_Cbank_state ;InputItem=strcat(InputItem,'CBank.'); end
if Device_Info.Transformer_Tab_state ;InputItem=strcat(InputItem,'TransTab.'); end
Device_Info.InputItem=InputItem;



end

