function [RecordRank] = TestRank(testnum,input_num,num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,rbf_type,cent_input_compelete)
%UNTITLED8 此处显示有关此函数的摘要
%   此处显示详细说明
RecordRank=[];
for i_test=1:testnum
    if mod(i_test,1000)==0
        i_test
    end
    input_Cbank=Device_Info.input_Cbank;
    Transformer_Tab=Device_Info.Transformer_Tab;
    INclude_PV_S=Device_Info.INclude_PV_S;
    %%
    
    [ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
    pv_pos=zeros(length(pv),2);
    pv_total=[];
    for i=1:length(pv)
        temp_pos=find(case_name.gen(:,1)==pv(i,1));
        if isempty(temp_pos)
            ;
        else
            pv_pos(i,1)=min(temp_pos);
            pv_pos(i,2)=max(temp_pos);
        end
        pv_total=[pv_total;temp_pos];
    end
    ref_pos=find(case_name.gen(:,1)==ref);
    
    %%
    temp_range_input_Cbank_num=length(input_Cbank);
    temp_range_input_TransTab_num=length(Transformer_Tab);
    
    
    Input=zeros(input_num,num_inpuit);
    num=num_inpuit;
    
    Input(1:length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_P_M+Tranning_Range.PQ_P_B).*case_name_or_simp.bus(pq,3);
    Input(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_Q_M+Tranning_Range.PQ_Q_B).*Input(1:length(pq),:);
    for i=1:length(pv)
        Input(2*length(pq)+i,:)=(rand(1,num)*Tranning_Range.PV_P_M+Tranning_Range.PV_P_B)*sum(case_name_or_simp.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,:)=case_name_or_simp.gen( pv_pos(i,1),6)*(rand(1,num)*Tranning_Range.PV_V_M+Tranning_Range.PV_V_B);
    end
    Input(2*length(pq)+2*length(pv)+1,:)=case_name_or_simp.gen( ref_pos,6)*(rand(1,num)*Tranning_Range.REF_V_M+Tranning_Range.REF_V_B);
    temp_C_bank=ceil(rand(1,num)*temp_range_input_Cbank_num);
    if Device_Info.input_Cbank_state
        Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state,:)=-input_Cbank(temp_C_bank);
    end
    
    if length(INclude_PV_S)>0
        temp_PV_P_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_P_M+Tranning_Range.PhotoVoltake_P_B).*INclude_PV_S';
        temp_S=ones(size(temp_PV_P_Out)).*INclude_PV_S';
        max_temp_PV_Q_Out=sqrt(temp_S.^2-temp_PV_P_Out.^2);
        Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S),:)=temp_PV_P_Out;
        temp_PV_Q_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_Q_M+Tranning_Range.PhotoVoltake_Q_B).*INclude_PV_S';
        temp_PV_Q_Out=min(temp_PV_Q_Out,max_temp_PV_Q_Out); % limit the Inverter Q power to fit the total S limit
        Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2,:)=temp_PV_Q_Out;
    end
    temp_TransTab=ceil(rand(1,num)*temp_range_input_TransTab_num);
    if Device_Info.Transformer_Tab_state
        Input(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state,:)=Transformer_Tab(temp_TransTab);
    end
    
    %% Input non-full rank test
    pos=find(Input(:,1)==0);
    Input(pos,:)=[];
    % Input(2,:)=Input(1,:);
    %%
    Xp = Lift_Vector_Complete(Input,rbf_type,cent_input_compelete(1:size(Input,1),:));
    W = Xp*Xp';
    RecordRank=[RecordRank;rank(W),rank(Xp),rank(Input)];
end
length(find(RecordRank(:,1)<RecordRank(1,2)))/length(RecordRank(:,1))
end

