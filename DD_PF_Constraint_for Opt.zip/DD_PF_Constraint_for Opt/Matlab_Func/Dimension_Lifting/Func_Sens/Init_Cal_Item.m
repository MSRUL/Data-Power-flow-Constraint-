function [TestItem] = Init_Cal_Item(Item_Name) %'Vm' 'Va' 'LP' 'LQ' 'Ploss'
%UNTITLED6 此处显示有关此函数的摘要
%   此处显示详细说明
TestItem.PQ_Vm=0;
TestItem.Va=0;     
TestItem.LP=0;
TestItem.LQ=0;
TestItem.PLoss=0;
switch Item_Name
    case 'Vm'
        TestItem.PQ_Vm=1;
    case 'Va'
        TestItem.Va=1; 
    case 'LP'
        TestItem.LP=1;
    case 'LQ'
        TestItem.LQ=1;
    case 'Ploss'
        TestItem.PLoss=1;
end
end

