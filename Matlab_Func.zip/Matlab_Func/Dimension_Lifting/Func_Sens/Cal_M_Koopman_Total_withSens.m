function [M] = Cal_M_Koopman_Total_withSens(Data,DLR_Parameter)
%ZYX 20220415
%  The equivalent processing method of least squares with the first derivative
% Only Be used in 2n+1
%% Lift the Input
Xp = Lift_Vector_Complete_Total(Data.Input,DLR_Parameter);
%%
Input_LaMi=(Data.Input+[Data.Input(:,2:end),Data.Input(:,1)])/2;

Input_Deff=Data.Input-[Data.Input(:,2:end),Data.Input(:,1)];
Output_Deff=Data.Output-[Data.Output(:,2:end),Data.Output(:,1)];

[Xs] = Cal_xs_PFDerivation(Input_LaMi,Input_Deff,DLR_Parameter);

%%
Y_Super=[Data.Output,Output_Deff];
X_Super=[Xp,Xs];

%%
if DLR_Parameter.Using_M==1
    W = X_Super*X_Super';
    V = Y_Super*X_Super';
    M = V*pinv(W);
else
    M=Y_Super*pinv(X_Super);
end


end