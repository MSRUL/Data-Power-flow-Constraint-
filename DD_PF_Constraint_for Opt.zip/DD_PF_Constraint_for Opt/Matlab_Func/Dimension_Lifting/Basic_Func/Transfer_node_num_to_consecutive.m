function [mpc_output] = Transfer_node_num_to_consecutive(mpc)
%UNTITLED14 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

bus=mpc.bus;
gen=mpc.gen;
branch=mpc.branch;
% gencost=mpc.gencost;

mpc_output=mpc;


bus_num=size(bus,1);
BUS_N=zeros(bus_num,2);
BUS_N(:,1)=bus(:,1);
BUS_N(:,2)=1:bus_num;


for i=1:bus_num
    pos=find(BUS_N(:,1)==bus(i,1));
    re_node=BUS_N(pos,2);
    mpc_output.bus(i,1)=re_node;
end
for i=1:size(gen,1)
    pos=find(BUS_N(:,1)==gen(i,1));
    re_node=BUS_N(pos,2);
    mpc_output.gen(i,1)=re_node;
end
for i=1:size(branch,1)
    pos=find(BUS_N(:,1)==branch(i,1));
    re_node=BUS_N(pos,2);
    mpc_output.branch(i,1)=re_node;
    pos=find(BUS_N(:,1)==branch(i,2));
    re_node=BUS_N(pos,2);
    mpc_output.branch(i,2)=re_node;
    
end
% for i=1:length(gencost)
%     pos=find(BUS_N(:,1)==gencost(i,1));
%     re_node=BUS_N(pos,2);
%     mpc_output.gencost(i,1)=re_node;
% end

end

