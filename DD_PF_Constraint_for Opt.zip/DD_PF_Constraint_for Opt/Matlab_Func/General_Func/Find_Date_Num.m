function [Dayrange,Dayrange_L,Dayrange_R] = Find_Date_Num(month,day)
%Find_Date_Num Input date output hour number
%   ZYX 20210519
month_day=[31,28,31,30,31,30,31,31,30,31,30,31];
month_day_A=zeros(size(month_day));
month_day_A(1)=month_day(1);
for i=2:12
    month_day_A(i)=month_day_A(i-1)+month_day(i);
end
if month==1
    Dayrange=(day-1)*24+1:(day-1)*24+24;
else
    Dayrange=month_day_A(month-1)*24+(day-1)*24+1:month_day_A(month-1)*24+(day-1)*24+24;
end
Dayrange_L=Dayrange(1,1);
Dayrange_R=Dayrange(1,end);


end

