function [M] = Cal_M_Koopman_Total(Data,DLR_Parameter)
%ZYX 20220415
%   此处提供详细说明

%% Lift the Input
Xp = Lift_Vector_Complete_Total(Data.Input,DLR_Parameter);
%%
if DLR_Parameter.Using_M==1
    W = Xp*Xp';
    V = Data.Output*Xp';
    M = V*pinv(W);
else
    M=Data.Output*pinv(Xp);
end

end