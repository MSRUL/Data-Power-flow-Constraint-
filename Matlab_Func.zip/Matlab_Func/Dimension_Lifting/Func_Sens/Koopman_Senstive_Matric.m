function [Senstive_M] = Koopman_Senstive_Matric(Input,rbf_type,cent_input,M)
%Koopman_Senstive_Matric 求解Koopman训练得到的M矩阵的灵敏度关系（输出对输入求导）
%   此处显示详细说明
Senstive_M=M(:,1:size(Input,1));
for i=1:size(Senstive_M,1)
    for j=1:size(Input,1)
        for k=1:size(cent_input,2)
            switch rbf_type
                case 'polyharmonic'
                    temp_item=M(i,size(Input,1)+k);
                    temp_item1=(Input(j,1)-cent_input(j,k));
                    temp_item2=sqrt(sum((Input-cent_input(j)).^2 ));
                    temp_item3=log( exp(1) * sqrt(sum((Input-cent_input(j)).^2 )) );
                    Senstive_M(i,j)= Senstive_M(i,j)+temp_item* temp_item1 /temp_item2*temp_item3;
                    %              没有升维部分的灵敏度   升维后的M矩阵系数       第j个升维变量的基底差
                otherwise
                    stophere=1;
                    '没有编写其他类型升维函数的灵敏度矩阵计算方法'
            end
        end
    end
end
end

