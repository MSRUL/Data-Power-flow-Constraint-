function [outputArg1,outputArg2] = Func_PF(Vol)
%UNTITLED2 此处提供此函数的摘要
%   此处提供详细说明
casename=case33bw;
[Ybus] = makeYbus(casename);
G_bus=full(real(Ybus));
P=casename.bus(:,3);

U_temp=zeros(length(Vol));

for i =1:length(Vol)
    for j =1:length(Vol)
        U_temp(i,j)=Vol(j)*(Vol(j)-Vol(i));
    end
end



end