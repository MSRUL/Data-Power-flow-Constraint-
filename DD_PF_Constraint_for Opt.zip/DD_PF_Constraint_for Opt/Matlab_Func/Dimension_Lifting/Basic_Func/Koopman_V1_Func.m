function [emean,emax] = Koopman_V1_Func(case_name_input,Figurte_Out_Put,FUN_select_input,TEST_input,temp_range_input,Nrbf_input,num_test_input,num_input,PQV_range_input,TEST_OPtion)
%UNTITLED4 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%Koopman_PF_V1
% �����޸���ά������ѡ������
% ����ѡ��������ݷ�Χ
% ��������PQ�ڵ��PQ��PV�ڵ��PV
% �������PQ�ڵ��sita,

Figurte_Out_Put;

%case24_ieee_rts
%case118
%case33bw

case_name_or=case_name_input;
case_name=Transfer_node_num_to_consecutive(case_name_or);  % �������нڵ��ţ�ʹ�������

A_result=runpf(case_name);

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);

pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;
pos_num_pv_p=[3,8];
pos_gen_pq=2:3;
pos_gen_p=2;
pos_gen_v=6;



P_rate=PQV_range_input(1);
Q_rate=P_rate/3;
PV_P_rate=PQV_range_input(2);
PV_V_rate=PQV_range_input(3);

input_num=length(pq)*2+length(pv)*2;
output_num=length(pq)*2+length(pv);
case_name.bus(pq,pos_num_pq_pq)=0;
case_name.gen([pv_total;ref_pos],[pos_gen_p,pos_gen_v])=0;

% case_name.bus([pv;pq],pos_num_pq_pq)=0; %����matpowe�е�PV�ڵ����Դ�һ��
% PQ���ɣ�����������ڳ�����������ʵ�ǲ�������̼���ģ�����PQ���ɵ�P���ڼ���ǰ��PV�ڵ��P���PQ���ɵ�Q���ڳ����������PQ�ڵ��Q����
% �����ϣ�PV�ڵ��ϵ�PQ���ɣ���Ȼ����PV�ڵ��ṩ�ġ�
% ���������ļ����У�������ɿ���������һ���̶�ֵ�����ǲ�������Ϊ����������㣬��Ϊ������������������Ա������������ĳ������̽���������⡣
% ��Ȼ�������в�����Koopman��ʽʱ�������������������������Ͽ��Բ�һ�£������ۺϿ��ǵ��ڳ����ξ����α���������⣬���Ǻܿ�ȡ���п�����ɽϴ����




%% **********************��ά������ѡȡ*******
FUN_select=FUN_select_input;
%**************************************************
if FUN_select==1
    basisFunction = 'rbf';
    % RBF centers
    Nrbf = Nrbf_input;
    cent = rand(input_num,Nrbf);
    cent(1:length(pq),:)=cent(1:length(pq),:)*P_rate;
    cent(length(pq)+1:2*length(pq),:)=cent(length(pq)+1:2*length(pq),:)*Q_rate;
    cent(2*length(pq)+1:2*length(pq)+length(pv),:)=cent(2*length(pq)+1:2*length(pq)+length(pv),:)*PV_P_rate;
    cent(2*length(pq)+length(pv)+1:input_num,:)=cent(2*length(pq)+length(pv)+1:input_num,:)*PV_V_rate+1;
    rbf_type = 'polyharmonic'; % 'thinplate' 'gauss''invquad'  'invmultquad'  'polyharmonic'
    % Lifting mapping - RBFs + the state itself
    liftFun = @(xx)( [xx;rbf_self_use(xx,cent,rbf_type)] );
    cent2 = rand(output_num,Nrbf);
    cent2(1:length(pq),:)=cent(1:length(pq),:).*A_result.bus(pq,8);
    cent2(length(pq)+1:2*length(pq),:)=cent(length(pq)+1:2*length(pq),:).*A_result.bus(pq,9);
    cent2(2*length(pq)+1:2*length(pq)+length(pv),:)=cent(2*length(pq)+1:2*length(pq)+length(pv),:).*A_result.bus(pv,9);
    % Lifting mapping - RBFs + the state itself
    liftFun2 = @(xx)( [xx;rbf_self_use(xx,cent2,rbf_type)] );
    Nlift = Nrbf + input_num;
end
if FUN_select==2
    liftFun = @(x)( [ x ; ones(1,size(x,2)) ; x(1:end-1,:).*(x(2:end,:)) ; x(1,:).*x(end,:) ; x.*x ]  ) ;
end
%**************************************************
%% ***************�����������ݵ�ѡȡ***********
TEST=TEST_input;
%**************************************************
if TEST==1
    num=num_input;
    Input=zeros(input_num,num);
    Input(1:length(pq),:)=rand(length(pq),num)*P_rate;% -P_rate/2;
    Input(length(pq)+1:2*length(pq),:)=rand(length(pq),num)*Q_rate; %-Q_rate/2;
    Input(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),num)*PV_P_rate;
    Input(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),num)*PV_V_rate+1;
    TEST=1;
end
%**************************************************
if TEST==2
    num=num_input;
    %     Input(1:length(pq),:)=rand(length(pq),num).*case_name_or.bus(pq,3)*2;
    %     Input(length(pq)+1:2*length(pq),:)=rand(length(pq),num).*case_name_or.bus(pq,4)*2;
    %     for i=1:length(pv)
    %         Input(2*length(pq)+i,:)=rand(1,num)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2))*2;  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
    % %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
    %         Input(2*length(pq)+length(pv)+i,:)=case_name_or.gen( pv_pos(i,1),6);
    %     end
    
    temp_range=temp_range_input;
    temp_range1=1-temp_range/2;
    Input(1:length(pq),:)=(rand(length(pq),num)*temp_range+temp_range1).*case_name_or.bus(pq,3);
    Input(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*temp_range+temp_range1).*case_name_or.bus(pq,4);
    for i=1:length(pv)
        Input(2*length(pq)+i,:)=(rand(1,num)*temp_range+temp_range1)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,:)=case_name_or.gen( pv_pos(i,1),6);
    end
end
%**************************************************
if TEST==3
    num=num_input*2;
    Input=zeros(input_num,num);
    Input(1:length(pq),1:num/2)=rand(length(pq),num/2)*P_rate;% -P_rate/2;
    Input(length(pq)+1:2*length(pq),1:num/2)=rand(length(pq),num/2)*Q_rate; %-Q_rate/2;
    Input(2*length(pq)+1:2*length(pq)+length(pv),1:num/2)=rand(length(pv),num/2)*PV_P_rate;
    Input(2*length(pq)+length(pv)+1:input_num,1:num/2)=rand(length(pv),num/2)*PV_V_rate+1;
    
    temp_range=temp_range_input;
    temp_range1=1-temp_range/2;
    Input(1:length(pq),(num/2+1):num)=(rand(length(pq),num/2)*temp_range+temp_range1).*case_name_or.bus(pq,3);
    Input(length(pq)+1:2*length(pq),(num/2+1):num)=(rand(length(pq),num/2)*temp_range+temp_range1).*case_name_or.bus(pq,4);
    for i=1:length(pv)
        Input(2*length(pq)+i,(num/2+1):num)=(rand(1,num/2)*temp_range+temp_range1)*sum(case_name_or.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
        %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
        Input(2*length(pq)+length(pv)+i,(num/2+1):num)=case_name_or.gen( pv_pos(i,1),6);
    end
    
    
end
%**************************************************

%% %*********�����������*********************

Output=zeros(output_num,num);
SS=[];
tic

for i=1:num
    temp_iptpq_p=Input(1:length(pq),i);
    temp_iptpq_q=Input(length(pq)+1:2*length(pq),i);
    temp_iptpv_p=Input(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input(2*length(pq)+length(pv)+1:input_num,i);
    
    
    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,:)=case_name_or.gen(ref_pos,:);
    
    [result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    output1=result.bus(pq,8);
    output2=result.bus(pq,9);
    output3=result.bus(pv,9);
    
    Output(:,i)=[output1;output2;output3];
end
toc
Input=Input(:,SS);
Output=Output(:,SS);

if FUN_select==1
    Xp = liftFun(Input);
    Yp = liftFun2(Output);
end
if FUN_select==2
    Xp = liftFun(Input);
    Yp = liftFun(Output);
end


W = Xp*Xp';
V = Yp*Xp';
M = V*pinv(W);



% ---------С����-----------

% tic
% for i=1:num
% ipt1=Input(:,i);
% IPT1=liftFun(ipt1);
% TPY=M*(IPT1*IPT1');
% OPT1=TPY(:,1)/IPT1(1,1);
% opt1=OPT1(1:length(pq),1);
% end
% toc

%% *************��֤��������************

if TEST==1||TEST==3
    num_test=num_test_input;
    OPT_PF=zeros(num_test,output_num);
    OPT_kpm=zeros(num_test,output_num);
    
    
    
    for i=1:num_test
        
        Input_test=zeros(input_num,1);
        Input_test(1:length(pq),:)=rand(length(pq),1)*P_rate; %-P_rate/2;
        Input_test(length(pq)+1:2*length(pq),:)=rand(length(pq),1)*Q_rate; %-Q_rate/2;
        Input_test(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),1)*PV_P_rate;
        Input_test(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),1)*PV_V_rate+1;
        
        temp_iptpq_p=Input_test(1:length(pq),1);
        temp_iptpq_q=Input_test(length(pq)+1:2*length(pq),1);
        temp_iptpv_p=Input_test(2*length(pq)+1:2*length(pq)+length(pv),1);
        temp_iptpv_v=Input_test(2*length(pq)+length(pv)+1:input_num,1);
        case_name1=case_name;
        
        case_name1.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
        %     case_name1.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
        for j=1:length(pv)
            case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
            case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
        end
        
        result_test=runpf(case_name1);
        output_testPF=[result_test.bus(pq,8);result_test.bus(pq,9);result_test.bus(pv,9)];
        OPT_PF(i,:)=output_testPF';
        
        IPT_test=liftFun(Input_test);
        TPY=M*(IPT_test*IPT_test');
        OPT1=TPY(:,1)/IPT_test(1,1);
        opt1=OPT1(1:output_num,1);
        OPT_kpm(i,:)=opt1';
        
    end
    
    OPT_PF_pq_Va=OPT_PF(:,1:length(pq));
    OPT_kpm_pq_Va=OPT_kpm(:,1:length(pq));
    
    OPT_PF_pq_Vm=OPT_PF(:,length(pq)+1:2*length(pq));
    OPT_kpm_pq_Vm=OPT_kpm(:,length(pq)+1:2*length(pq));
    %
    OPT_PF_pv_Vm=OPT_PF(:,2*length(pq)+1:2*length(pq)+length(pv));
    OPT_kpm_pv_Vm=OPT_kpm(:,2*length(pq)+1:2*length(pq)+length(pv));
    
    
    
    
    OPT_PF_pq_Va=reshape(OPT_PF_pq_Va,num_test*length(pq),1);
    OPT_kpm_pq_Va=reshape(OPT_kpm_pq_Va,num_test*length(pq),1);
    
    OPT_PF_pq_Vm=reshape(OPT_PF_pq_Vm,num_test*length(pq),1);
    OPT_kpm_pq_Vm=reshape(OPT_kpm_pq_Vm,num_test*length(pq),1);
    
    OPT_PF_pv_Vm=reshape(OPT_PF_pv_Vm,num_test*length(pv),1);
    OPT_kpm_pv_Vm=reshape(OPT_kpm_pv_Vm,num_test*length(pv),1);
    
    
    if Figurte_Out_Put
        figure;
        subplot(3,1,1)
        plot(OPT_PF_pq_Va);
        hold on;
        plot(OPT_kpm_pq_Va);
        legend('����������','Koopman')
        title('PQ�ڵ��ѹ��ֵ')
        subplot(3,1,2)
        plot(OPT_PF_pq_Vm);
        hold on;
        plot(OPT_kpm_pq_Vm);
        legend('����������','Koopman')
        title('PQ�ڵ��ѹ���')
        subplot(3,1,3)
        plot(OPT_PF_pv_Vm);
        hold on;
        plot(OPT_kpm_pv_Vm);
        legend('����������','Koopman')
        title('PV�ڵ��ѹ��ֵ')
    end
    
    
    % '������';
    % e_pq_p=mean(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
    % e_pq_q=mean(abs((OPT_PF_pq_Vm-OPT_kpm_pq_Vm)./OPT_PF_pq_Vm));
    % e_pv_sita=mean(abs((OPT_PF_pv_Vm-OPT_kpm_pv_Vm)./OPT_PF_pv_Vm));
    % emean=[e_pq_p,e_pq_q,e_pv_sita];
    %
    %
    % e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
    % e_pq_q=max(abs((OPT_PF_pq_Vm-OPT_kpm_pq_Vm)./OPT_PF_pq_Vm));
    % e_pv_sita=max(abs((OPT_PF_pv_Vm-OPT_kpm_pv_Vm)./OPT_PF_pv_Vm));
    % emax=[e_pq_p,e_pq_q,e_pv_sita];
    % % [emean;emax];
    
    %'�������';
    e_pq_p=mean(abs(OPT_kpm_pq_Va-OPT_PF_pq_Va));
    e_pq_q=mean(abs(OPT_PF_pq_Vm-OPT_kpm_pq_Vm));
    e_pv_sita=mean(abs(OPT_PF_pv_Vm-OPT_kpm_pv_Vm));
    emean=[e_pq_p,e_pq_q,e_pv_sita];
    
    e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)));
    e_pq_q=max(abs((OPT_PF_pq_Vm-OPT_kpm_pq_Vm)));
    e_pv_sita=max(abs((OPT_PF_pv_Vm-OPT_kpm_pv_Vm)));
    emax=[e_pq_p,e_pq_q,e_pv_sita];
    %[emean;emax];
end
%% ԭʼ���ݼ���
if TEST==2||TEST==3
    if TEST_OPtion==1
        case_name_or1=Transfer_node_num_to_consecutive(case_name_or);
        [ref,pv, pq] = bustypes(case_name_or1.bus, case_name_or1.gen);
        
        
        
        Input_test=zeros(input_num,1);
        Input_test(1:length(pq),:)=case_name_or1.bus(pq,3);
        Input_test(length(pq)+1:2*length(pq),:)=case_name_or1.bus(pq,4);
        for i=1:length(pv)
            Input_test(2*length(pq)+i,1)=sum(case_name_or1.gen( pv_pos(i,1): pv_pos(i,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
            Input_test(2*length(pq)+length(pv)+i,1)=case_name_or1.gen( pv_pos(i,1),6);
        end
        
        IPT_test=liftFun(Input_test);
        TPY=M*(IPT_test*IPT_test');
        OPT1=TPY(:,1)/IPT_test(1,1);
        opt1=OPT1(1:output_num,1);
        
        result_test=runpf(case_name_or);
        output_testPF=[result_test.bus(pq,8);result_test.bus(pq,9);result_test.bus(pv,9)];
        
        if Figurte_Out_Put
            figure;
            subplot(3,1,1)
            range=1:length(pq);
            plot(output_testPF(range))
            hold on;
            plot(opt1(range));
            legend('IEEE_PF','Kooman_PF');
            title('PQ�ڵ��ѹ��ֵ')
            subplot(3,1,2)
            range=1+length(pq):2*length(pq);
            plot(output_testPF(range))
            hold on;
            plot(opt1(range));
            legend('IEEE_PF','Kooman_PF');
            title('PQ�ڵ��ѹ���')
            subplot(3,1,3)
            range=2*length(pq)+1:2*length(pq)+length(pv);
            plot(output_testPF(range))
            hold on;
            plot(opt1(range));
            legend('IEEE_PF','Kooman_PF');
            title('PV�ڵ��ѹ���')
        end
        
        
        
        k_r1=opt1(1:length(pq));
        k_r2=opt1(length(pq)+1:2*length(pq));
        k_r3=opt1(2*length(pq)+1:2*length(pq)+length(pv));
        
        %������
        %     e1=mean(abs((k_r1-result_test.bus(pq,8))./result_test.bus(pq,8)));
        %     e2=mean(abs((k_r2-result_test.bus(pq,9))./result_test.bus(pq,9) ));
        %     e3=mean(abs((k_r3-result_test.bus(pv,9))./result_test.bus(pv,9) ));
        %     e=[e1,e2,e3];
        %     emean=e*100;
        %     e1=max(abs((k_r1-result_test.bus(pq,8))./result_test.bus(pq,8)));
        %     e2=max(abs((k_r2-result_test.bus(pq,9))./result_test.bus(pq,9) ));
        %     e3=max(abs((k_r3-result_test.bus(pv,9))./result_test.bus(pv,9) ));
        %     e=[e1,e2,e3];
        %     emax=e*100;
        
        %�������
        e1=mean(abs((k_r1-result_test.bus(pq,8))));
        e2=mean(abs((k_r2-result_test.bus(pq,9)) ));
        e3=mean(abs((k_r3-result_test.bus(pv,9)) ));
        emean=[e1,e2,e3];
        
        e1=max(abs((k_r1-result_test.bus(pq,8))));
        e2=max(abs((k_r2-result_test.bus(pq,9)) ));
        e3=max(abs((k_r3-result_test.bus(pv,9)) ));
        emax=[e1,e2,e3];
        %[emean;emax];
    end
    if TEST_OPtion==2
        num_test=num_test_input;
        OPT_PF=zeros(num_test,output_num);
        OPT_kpm=zeros(num_test,output_num);
        
        
        
        for i=1:num_test
            
            temp_range=temp_range_input;
            temp_range1=1-temp_range/2;
            Input_test=zeros(input_num,1);
            Input_test(1:length(pq),1)=(rand(length(pq),1)*temp_range+temp_range1).*case_name_or.bus(pq,3);
            Input_test(length(pq)+1:2*length(pq),1)=(rand(length(pq),1)*temp_range+temp_range1).*case_name_or.bus(pq,4);
            for j=1:length(pv)
                Input_test(2*length(pq)+j,1)=(rand(1,1)*temp_range+temp_range1)*sum(case_name_or.gen( pv_pos(j,1): pv_pos(j,2),2));  %����PV�ڵ��ϵ��й����� ����Ϊһ��PV�ڵ��ϻ��ж��������������൱�ڽ����з������������ʼӺͣ�
                %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
                Input_test(2*length(pq)+length(pv)+j,1)=case_name_or.gen( pv_pos(j,1),6);
            end
%             Input_test=zeros(input_num,1);
%             Input_test(1:length(pq),:)=rand(length(pq),1)*P_rate; %-P_rate/2;
%             Input_test(length(pq)+1:2*length(pq),:)=rand(length(pq),1)*Q_rate; %-Q_rate/2;
%             Input_test(2*length(pq)+1:2*length(pq)+length(pv),:)=rand(length(pv),1)*PV_P_rate;
%             Input_test(2*length(pq)+length(pv)+1:input_num,:)=rand(length(pv),1)*PV_V_rate+1;
            
            temp_iptpq_p=Input_test(1:length(pq),1);
            temp_iptpq_q=Input_test(length(pq)+1:2*length(pq),1);
            temp_iptpv_p=Input_test(2*length(pq)+1:2*length(pq)+length(pv),1);
            temp_iptpv_v=Input_test(2*length(pq)+length(pv)+1:input_num,1);
            case_name1=case_name;
            
            case_name1.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
            %     case_name1.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
            for j=1:length(pv)
                case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
                case_name1.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
            end
            
            result_test=runpf(case_name1);
            output_testPF=[result_test.bus(pq,8);result_test.bus(pq,9);result_test.bus(pv,9)];
            OPT_PF(i,:)=output_testPF';
            
            IPT_test=liftFun(Input_test);
            TPY=M*(IPT_test*IPT_test');
            OPT1=TPY(:,1)/IPT_test(1,1);
            opt1=OPT1(1:output_num,1);
            OPT_kpm(i,:)=opt1';
            
        end
        
        OPT_PF_pq_Va=OPT_PF(:,1:length(pq));
        OPT_kpm_pq_Va=OPT_kpm(:,1:length(pq));
        
        OPT_PF_pq_Vm=OPT_PF(:,length(pq)+1:2*length(pq));
        OPT_kpm_pq_Vm=OPT_kpm(:,length(pq)+1:2*length(pq));
        %
        OPT_PF_pv_Vm=OPT_PF(:,2*length(pq)+1:2*length(pq)+length(pv));
        OPT_kpm_pv_Vm=OPT_kpm(:,2*length(pq)+1:2*length(pq)+length(pv));
        
        
        
        
        OPT_PF_pq_Va=reshape(OPT_PF_pq_Va,num_test*length(pq),1);
        OPT_kpm_pq_Va=reshape(OPT_kpm_pq_Va,num_test*length(pq),1);
        
        OPT_PF_pq_Vm=reshape(OPT_PF_pq_Vm,num_test*length(pq),1);
        OPT_kpm_pq_Vm=reshape(OPT_kpm_pq_Vm,num_test*length(pq),1);
        
        OPT_PF_pv_Vm=reshape(OPT_PF_pv_Vm,num_test*length(pv),1);
        OPT_kpm_pv_Vm=reshape(OPT_kpm_pv_Vm,num_test*length(pv),1);
        
        
        if Figurte_Out_Put
            figure;
            subplot(3,1,1)
            plot(OPT_PF_pq_Va);
            hold on;
            plot(OPT_kpm_pq_Va);
            legend('����������','Koopman')
            title('PQ�ڵ��ѹ��ֵ')
            subplot(3,1,2)
            plot(OPT_PF_pq_Vm);
            hold on;
            plot(OPT_kpm_pq_Vm);
            legend('����������','Koopman')
            title('PQ�ڵ��ѹ���')
            subplot(3,1,3)
            plot(OPT_PF_pv_Vm);
            hold on;
            plot(OPT_kpm_pv_Vm);
            legend('����������','Koopman')
            title('PV�ڵ��ѹ��ֵ')
        end
        
        
        % '������';
        % e_pq_p=mean(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
        % e_pq_q=mean(abs((OPT_PF_pq_Vm-OPT_kpm_pq_Vm)./OPT_PF_pq_Vm));
        % e_pv_sita=mean(abs((OPT_PF_pv_Vm-OPT_kpm_pv_Vm)./OPT_PF_pv_Vm));
        % emean=[e_pq_p,e_pq_q,e_pv_sita];
        %
        %
        % e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)./OPT_kpm_pq_Va));
        % e_pq_q=max(abs((OPT_PF_pq_Vm-OPT_kpm_pq_Vm)./OPT_PF_pq_Vm));
        % e_pv_sita=max(abs((OPT_PF_pv_Vm-OPT_kpm_pv_Vm)./OPT_PF_pv_Vm));
        % emax=[e_pq_p,e_pq_q,e_pv_sita];
        % % [emean;emax];
        
        %'�������';
        e_pq_p=mean(abs(OPT_kpm_pq_Va-OPT_PF_pq_Va));
        e_pq_q=mean(abs(OPT_PF_pq_Vm-OPT_kpm_pq_Vm));
        e_pv_sita=mean(abs(OPT_PF_pv_Vm-OPT_kpm_pv_Vm));
        emean=[e_pq_p,e_pq_q,e_pv_sita];
        
        e_pq_p=max(abs((OPT_kpm_pq_Va-OPT_PF_pq_Va)));
        e_pq_q=max(abs((OPT_PF_pq_Vm-OPT_kpm_pq_Vm)));
        e_pv_sita=max(abs((OPT_PF_pv_Vm-OPT_kpm_pv_Vm)));
        emax=[e_pq_p,e_pq_q,e_pv_sita];
        %[emean;emax];
        
        
    end
end


end

