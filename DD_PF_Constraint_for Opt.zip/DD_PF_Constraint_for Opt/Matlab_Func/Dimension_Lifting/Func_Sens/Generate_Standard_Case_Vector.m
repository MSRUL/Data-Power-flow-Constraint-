function [Input_Vector] = Generate_Standard_Case_Vector(case_name,Device_Info,PV_Rate)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
%%
[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

%%
temp_rand_rate=zeros(length(Device_Info.INclude_PV_S),1);
if strcmp(PV_Rate,'RAND_Num')
   temp_rand_rate(:,1)=rand(length(Device_Info.INclude_PV_S),1);
else
     if length(Device_Info.INclude_PV_S)>0 % If have DG, Rand Generated around PV_Rate
        temp_rand_rate(:,1)=normrnd(PV_Rate,0.05,[length(Device_Info.INclude_PV_S) 1]);
    end
end

%%
Input_Vector=zeros(Device_Info.Input_Num,1);

Input_Vector(1:length(pq),:)=case_name.bus(pq,3);
Input_Vector(length(pq)+1:2*length(pq),:)=case_name.bus(pq,4);
for i=1:length(pv)
    Input_Vector(2*length(pq)+i,:)=sum(case_name.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
    Input_Vector(2*length(pq)+length(pv)+i,:)=case_name.gen( pv_pos(i,1),6);
end
Input_Vector(2*length(pq)+2*length(pv)+1,:)=case_name.gen( ref_pos,6);
temp_C_bank=1;
if Device_Info.input_Cbank_state
    Input_Vector(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state,:)=-Device_Info.input_Cbank(temp_C_bank);
end
if length(Device_Info.INclude_PV_S)>0 % If have DG, Rand Generated around PV_Rate
    temp_PV_P_Out=Device_Info.INclude_PV_S'.*temp_rand_rate;
    Input_Vector(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(Device_Info.INclude_PV_S),:)=temp_PV_P_Out;
    temp_PV_Q_Out=zeros(length(Device_Info.INclude_PV_S),1);
    Input_Vector(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(Device_Info.INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(Device_Info.INclude_PV_S)*2,:)=temp_PV_Q_Out;
end

if Device_Info.Transformer_Tab_state
    Input_Vector(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(Device_Info.INclude_PV_S)*2+Device_Info.Transformer_Tab_state,:)=Device_Info.Transformer_Tab;
end

end

