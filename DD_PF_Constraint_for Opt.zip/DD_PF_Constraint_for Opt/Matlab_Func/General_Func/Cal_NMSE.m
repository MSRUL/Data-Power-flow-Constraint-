function [NMSE] = Cal_NMSE(input_Standard,input_Test)
%UNTITLED3 此处提供此函数的摘要
%   此处提供详细说明
temp_S=input_Standard.^2;
temp_S=sum(temp_S(:));
temp_T=(input_Standard-input_Test).^2;
temp_T=sum(temp_T(:));
NMSE=temp_T/temp_S;
end