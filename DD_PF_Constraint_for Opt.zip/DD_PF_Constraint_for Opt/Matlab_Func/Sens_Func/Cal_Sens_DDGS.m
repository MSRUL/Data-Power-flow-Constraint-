function [DDGS] = Cal_Sens_DDGS(Input,M_BZ,Direct_Linear_Sens,DLR_Parameterx,Num)
%Calculate the senstive Matrix of Input state ( DDGS )

B_sen=zeros(Num.nx,Num.n_Lifted,size(M_BZ,1));
for i=1:size(M_BZ,1)
    B_sen(:,:,i)=reshape(M_BZ(i,:),Num.n_Lifted,Num.nx)';
end

Temp_X_Laga_lifted = Lift_Vector_Complete_Total(Input,DLR_Parameterx);


Sens_Dif_3=zeros(size(Direct_Linear_Sens,1),size(Direct_Linear_Sens,2),size(Input,2));
for i =1:size(M_BZ,1)
    Sens_Dif_3(i,:,:)=B_sen(:,:,i)*Temp_X_Laga_lifted;
end
DDGS=Direct_Linear_Sens-Sens_Dif_3;

end