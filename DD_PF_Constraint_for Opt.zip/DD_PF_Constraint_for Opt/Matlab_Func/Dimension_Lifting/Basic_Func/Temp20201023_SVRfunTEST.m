
clear all;clc;
% Zscore Normalization
data=zscore(csvread('GaussaianData.csv'));
% Input -> x, Output -> y
x=data(:,1:end-1);
y=data(:,end);
X=x;
Y=[y,y];
Y=[y,y];
%%

maxItr=150;
kernel_type='g';
Alpha=SVR_Rge_Mul(X,Y,kernel_type,maxItr);
F_o = SVR_Predic(X,Alpha,kernel_type);

%%
mean(abs(y-F_o(:,1)))
figure
hold on
scatter3(x(:,1),x(:,2),y)
scatter3(x(:,1),x(:,2),F_o(:,1),'*')
hold off
xlabel({'X_1'});
ylabel({'X_2'});
view([-46.4 -0.40]);
legend1 = legend('Actual Values','Predicted Values');