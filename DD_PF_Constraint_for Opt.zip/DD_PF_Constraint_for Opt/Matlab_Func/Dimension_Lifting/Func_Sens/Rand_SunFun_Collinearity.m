function [Radn_Col] = Rand_SunFun_Collinearity(Base_Rand,Col_Index,datanum,range_M,range_B)
% ZYX20220824
%%
Index=1;
while Index
    temp=Base_Rand*normrnd(1,Col_Index.BaseRand_Tolerance,[1,1]);
    if temp<=1 && temp>=0  % Ensure the generated data in the excepted range  (range_B-range_M,range_B+range_M)
        Base_Rand=temp;
        Index=0;
    end
end

%%
Radn_Col_base=Base_Rand*range_M+range_B;
%%
Radn_Col=zeros(datanum,1);
for i=1:datanum
    Index=1;
    while Index
        temp=Radn_Col_base*(normrnd(1,Col_Index.Sigma,[1,1]));  % Generate Data base on the 'Base_Rand'
        if temp<=range_B+range_M && temp>=range_B-range_M  % Ensure the generated data in the excepted range  (range_B-range_M,range_B+range_M)
            Radn_Col(i,1)=temp;
            Index=0;
        end
    end
end
end