function [DataResults] = Cal_Results_DDLPF(M_DDLPF,case_name,Data_DDLPF)
%UNTITLED3 '计算DDLPF结果'
%   此处显示详细说明
%%
M_DDLPF.XVa;
M_DDLPF.XVm;
M_DDLPF.XPL;
M_DDLPF.XQL;
%%
P_injection=Data_DDLPF.P_injection';
Q_injection=Data_DDLPF.Q_injection';
Vm=Data_DDLPF.Vm';
Va=Data_DDLPF.Va';
PL=Data_DDLPF.PL';
QL=Data_DDLPF.QL';
PLoss=Data_DDLPF.PLoss';
data=Data_DDLPF;
%% Case Info
[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
line_active=find(case_name.branch(:,11)==1);
Bus_Num=size(case_name.bus,1);
Branch_Num=length(line_active);
Num_PQ_Bus = size(pq,1);
Num_PV_Bus = size(pv,1);
%%
X_Line=[M_DDLPF.XPL(:,1:2*Bus_Num);M_DDLPF.XQL(:,1:2*Bus_Num)];
C_Line = [M_DDLPF.XPL(:,2*Bus_Num + 1);M_DDLPF.XQL(:,2*Bus_Num + 1)];

X11 = [M_DDLPF.XVa([pq; pv; ref], [pq; pv; ref; pq + Bus_Num]);...
    M_DDLPF.XVm(pq, [pq; pv; ref; pq + Bus_Num])]; %Already Known injection power Parts
X12 = [M_DDLPF.XVa([pq; pv; ref], [pv; ref] + Bus_Num);...
    M_DDLPF.XVm(pq, [pv; ref] + Bus_Num)];% The Reactive Bus of PV ,Ref bus Parts
X21 = M_DDLPF.XVm([pv; ref], [pq; pv; ref; pq + Bus_Num]);
X22 = M_DDLPF.XVm([pv; ref], [pv; ref] + Bus_Num);
C1 = [M_DDLPF.XVa([pq; pv; ref],2*Bus_Num + 1);M_DDLPF.XVm(pq,2*Bus_Num + 1)];
C2 = M_DDLPF.XVm([pv; ref],2*Bus_Num + 1);
%%
P_temp = P_injection;%All The active power is known
P_temp(:, ref) = Va(:, ref);

%% calculate the results by data-driven linearized equations
for i = 1:size(P_injection,1)
    %% Voltage Results
    Y2 = Vm(i, [pv; ref])';
    a1 = [P_temp(i, [pq; pv; ref])'; Q_injection(i, pq)'];%The Already Known injection power
    a2 = X22 \ (Y2 - X21 * a1 - C2);% Calculate the Reactive Bus of PV ,Ref bus.
    
    Q_pv = a2(1:Num_PV_Bus);
    Q_ref = a2(Num_PV_Bus + 1:Num_PV_Bus + 1);
    Y1 = X11 * a1 + X12 * a2 + C1;

    P1=P_temp(i,:)';
    Q1=zeros(Bus_Num,1);
    Q1(pq,1)=Q_injection(i, pq);
    Q1([pv;ref],1)=a2;
    
    Vm_temp = zeros(Bus_Num, 1);
    Vm_temp([pv; ref]) = Vm(i, [pv; ref]);
    Vm_temp(pq) = Y1(Bus_Num + 1: Bus_Num + Num_PQ_Bus);
    Va_temp = zeros(Bus_Num, 1);
    Va_temp(ref) = Va(i, ref);
    Va_temp([pq; pv]) = Y1(1: Num_PQ_Bus + Num_PV_Bus) / pi * 180;
    P_temp(i, ref) = Y1(Num_PQ_Bus + Num_PV_Bus + 1);
    Q_temp = Q_injection(i, :);
    Q_temp([pv; ref]) = [Q_pv; Q_ref]';
    %% Branch Power Flow Results
    a_pq=[P1;Q1];% Bus injection power based on the above calculation
    Y_line=X_Line*a_pq+C_Line;
    PLF=Y_line(1:Branch_Num,:);
    QLF=Y_line((1+Branch_Num):(2*Branch_Num),:);
    %-----Check-----
    Q_test=[Q_injection(i, pq)';Q_injection(i, pv)';Q_injection(i, ref)'];
    a_or=[P1;Q_test];
    Y_line_test=X_Line*a_or+C_Line;
    PLF_test=Y_line_test(1:Branch_Num,:);
    QLF_test=Y_line_test((1+Branch_Num):(2*Branch_Num),:);
    data.PLF_fitting_test(i, :)=PLF_test;
    data.QLF_fitting_test(i, :)=QLF_test;
    %     mean(mean(abs(PLF-PLF_test)))
    %     mean(mean(abs(QLF-QLF_test)))
%     mean(abs(data.PLF_fitting_test- data.PF))
%     mean(abs(data.QLF_fitting_test- data.QF))
    %--------------
    %% Storge Data
    DataResults.Vm(:,i) = Vm_temp;
    DataResults.Va(:,i) = Va_temp;
    DataResults.P_injection(:,i) = P_temp(i, :)';%All The active power is known
    DataResults.Q_injection(:,i) = Q_temp';
    DataResults.PL(:,i) = PLF';
    DataResults.QL(:,i) = QLF';
    DataResults.PLF_test(:,i) = PLF_test';
    DataResults.QLF_test(:,i) = QLF_test';
end
end

