function [FUN_select] = Defined_Lift_FuncType(rbf_type)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
switch rbf_type
    case 'polyharmonic'
        FUN_select=1;
    case 'invquad'
        FUN_select=1;
    case 'invmultquad'
        FUN_select=1;
    case 'sin1'
        FUN_select=1;
    case 'sin2'
        FUN_select=1;
    case '3n+1'
        FUN_select=2;
    case '2second order'
        FUN_select=3;
    case 'MIX polyh and 3n+1'
        FUN_select=4;
    case 'MIX polyh and invquad'
        FUN_select=5;
    case 'MIX polyh and invmultquad'
        FUN_select=6;
    case 'MIX invquad and invmultquad'
        FUN_select=7;
    case 'MIX polyh invquad invmultquad'
        FUN_select=8;
    case 'MIX polyh invquad invmultquad 3n+1'
        FUN_select=9;
    otherwise
        stophere=1;
end
end

