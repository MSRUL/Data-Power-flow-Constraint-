function [OUTPUT_Record,INPUT_Record,Senstive_M_Record] = Senstive_KPM_Power_Loss_Control(Input_controled,M_V,M_Ploss,cent_input,Pos_In_OutPut,Voltage,adjust_LOSS_Q_step)
%Senstive_KPM_Power_Loss_Control Use the Koopman Sensitivity Matirx to Regulate the Ner Power Loss
%% Init the Variable
Adj_Input=Input_controled;
M_Ploss_OR=M_Ploss;
%% Iteration of convergence of power loss
Adj_Input_Lifted=Lift_Dem_Fun_Tradi(Adj_Input,'polyharmonic',cent_input);
KPM_Output_Ploss=M_Ploss_OR*Adj_Input_Lifted;


KPM_Output_Vm=M_V*Adj_Input_Lifted;
%  [Senstive_M_Loss] = Koopman_Senstive_Matric(Adj_Input,'polyharmonic',cent_input,M_Ploss_OR);
 [Senstive_M_Loss] = Koopman_Senstive_Matric_Try(Adj_Input,'polyharmonic',cent_input,M_Ploss,adjust_LOSS_Q_step,Pos_In_OutPut.Pos_Q_in_Input);
%%
Pos_In_OutPut.Pos_P_in_Input;
Pos_In_OutPut.Pos_Q_in_Input;
Iter=0;
Iter_Max=100;
Senstive_M_Record=[];Senstive_M_Record=[Senstive_M_Record;Senstive_M_Loss];
INPUT_Record=[];INPUT_Record=[INPUT_Record,Adj_Input];
OUTPUT_Record=[];OUTPUT_Record=[OUTPUT_Record,KPM_Output_Ploss];
figure;
while Iter<Iter_Max
    Adj_Input_Before=Adj_Input;
    M_Ploss_temp=KPM_Output_Ploss;
    Adj_Done=1;
    while Adj_Done
        [numof_PV_inventor]=find(  abs(Senstive_M_Loss(1,Pos_In_OutPut.Pos_Q_in_Input))==max(abs( abs(Senstive_M_Loss(1,Pos_In_OutPut.Pos_Q_in_Input)) ) ));
        if length(numof_PV_inventor)>1
           ; 
        end
        if Senstive_M_Loss(1,Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor)>=0  %Determain the direction of sensitive
            B_direction=-1; %If the Input would Rise the Output��Then��Put the direction to minus
        else
            B_direction=1;
        end
        % Calculate
        Adj_Input_temp=Adj_Input;
        Adj_Input_temp(Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)=Adj_Input(Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)+B_direction*adjust_LOSS_Q_step;
        Adj_Input_Lifted=Lift_Dem_Fun_Tradi(Adj_Input_temp,'polyharmonic',cent_input);
        KPM_Output_Vm=M_V*Adj_Input_Lifted;
        KPM_Output_Ploss=M_Ploss_OR*Adj_Input_Lifted;
        Over_Voltage=find(KPM_Output_Vm>Voltage.max);
        Below_Voltage=find(KPM_Output_Vm<Voltage.min);
        if length(Over_Voltage)+length(Below_Voltage)>0 %Check the Voltage limit violation After Adjustment 
            Adj_Input=Adj_Input_Before;
            Senstive_M_Loss(1,Pos_In_OutPut.Pos_PV_Q_Inventer_Start+numof_PV_inventor)=0; 
        else
            Adj_Done=0;
            Adj_Input=Adj_Input_temp;
            INPUT_Record=[INPUT_Record,Adj_Input];
            OUTPUT_Record=[OUTPUT_Record,KPM_Output_Ploss];
%             [Senstive_M_Loss] = Koopman_Senstive_Matric(Adj_Input,'polyharmonic',cent_input,M_Ploss_OR);
             [Senstive_M_Loss] = Koopman_Senstive_Matric_Try(Adj_Input,'polyharmonic',cent_input,M_Ploss,adjust_LOSS_Q_step,Pos_In_OutPut.Pos_Q_in_Input);
            Senstive_M_Record=[Senstive_M_Record;Senstive_M_Loss];
        end
    end
    Iter=Iter+1;
    plot(OUTPUT_Record);title('Ploss Change Trend')
end
Senstive_M_Record=Senstive_M_Record(:,Pos_In_OutPut.Pos_Q_in_Input);
figure;plot(Senstive_M_Record);title('Sensitive Matrix Q2Ploss')
Adj_Input=zeros(size(INPUT_Record));
for i=2:size(INPUT_Record,2)
    Adj_Input(:,i)=INPUT_Record(:,i)-INPUT_Record(:,i-1);
end

figure;plot(INPUT_Record(Pos_In_OutPut.Pos_Q_in_Input,:)');title('Input PV Inventer Change Trend')
Adj_Input_PV_Inverter_Q=Adj_Input(Pos_In_OutPut.Pos_Q_in_Input,:);

figure;plot(Adj_Input_PV_Inverter_Q');
legend('1','2','3','4','5','6','7','8','9','10','11','12')
figure;plot(Adj_Input_PV_Inverter_Q(:,1));hold on;plot(Adj_Input_PV_Inverter_Q(:,end))

end

