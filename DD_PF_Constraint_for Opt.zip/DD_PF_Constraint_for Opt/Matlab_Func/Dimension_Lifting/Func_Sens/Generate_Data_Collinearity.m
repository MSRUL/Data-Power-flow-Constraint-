function [Input_KPM,Output_KMP,Data_DDLPF] = Generate_Data_Collinearity(input_num,test_input_num,num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,TestItem,Col_Index)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明


%%
input_Cbank=Device_Info.input_Cbank;
Transformer_Tab=Device_Info.Transformer_Tab;
INclude_PV_node_Pos=Device_Info.INclude_PV_node_Pos;
INclude_PV_S=Device_Info.INclude_PV_S;
%%

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;
pos_gen_p=2;
pos_gen_v=6;
Bus_Num=size(case_name.bus,1);
line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
%%
% input_Cbank=temp_range_input_Cbank/1000;
temp_range_input_Cbank_num=length(input_Cbank);
temp_range_input_TransTab_num=length(Transformer_Tab);

%%  Data of KPM DD_PF
Input_KPM=zeros(input_num,num_inpuit);
num=num_inpuit;








%% Collinearity 
% Col_Index; %【Collinearity Index】

for i_Roll=1:num
    %【Collinearity Index】
    Base_RandSigma=rand();  % The data Rise/Fall at the same base step it oneshot
    %=============== PQ P ==================
    Radn_PQ_P = Rand_SunFun_Collinearity(Base_RandSigma,Col_Index,length(pq),Tranning_Range.PQ_P_M,Tranning_Range.PQ_P_B);
    Input_KPM(1:length(pq),i_Roll)=Radn_PQ_P.*case_name_or_simp.bus(pq,3);

    %=============== PQ Q ==================  
    switch Tranning_Range.Q_Load_Mode
        case 'fai' %Determine Q by the known P and rand fai
            Radn_PQ_Q = Rand_SunFun_Collinearity(Base_RandSigma,Col_Index,length(pq),Tranning_Range.PQ_Q_M,Tranning_Range.PQ_Q_B);
            Input_KPM(length(pq)+1:2*length(pq),i_Roll)=Radn_PQ_Q.*Input_KPM(1:length(pq),i_Roll);

        case 'Q' % Determine the Q directly
            Radn_PQ_Q = Rand_SunFun_Collinearity(Base_RandSigma,Col_Index,length(pq),Tranning_Range.PQ_Q_Direc_M,Tranning_Range.PQ_Q_Direc_B);
            Input_KPM(length(pq)+1:2*length(pq),i_Roll)=Radn_PQ_Q.*case_name_or_simp.bus(pq,4);
    end
    for i=1:length(pv)
        Radn_PV_P = Rand_SunFun_Collinearity(Base_RandSigma,Col_Index,1,Tranning_Range.PV_P_M,Tranning_Range.PV_P_B);
        Input_KPM(2*length(pq)+i,i_Roll)=Radn_PV_P*sum(case_name_or_simp.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
        
        Radn_PV_V = Rand_SunFun_Collinearity(Base_RandSigma,Col_Index,1,Tranning_Range.PV_P_M,Tranning_Range.PV_P_B);
        Input_KPM(2*length(pq)+length(pv)+i,i_Roll)=case_name_or_simp.gen( pv_pos(i,1),6)*Radn_PV_V;
    end

    Input_KPM(2*length(pq)+2*length(pv)+1,i_Roll)=case_name_or_simp.gen( ref_pos,6)*(rand(1,1)*Tranning_Range.REF_V_M+Tranning_Range.REF_V_B); %Ref Voltage is not neet to Collinearity
    temp_C_bank=ceil(rand(1,1)*temp_range_input_Cbank_num);

    if Device_Info.input_Cbank_state
        Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state,i_Roll)=-input_Cbank(temp_C_bank);
    end
    if length(INclude_PV_S)>0

        Radn_DG_P = Rand_SunFun_Collinearity(Base_RandSigma,Col_Index,length(INclude_PV_S),Tranning_Range.PhotoVoltake_P_M,Tranning_Range.PhotoVoltake_P_B);
        temp_PV_P_Out=Radn_DG_P.*INclude_PV_S';
        temp_S=ones(size(temp_PV_P_Out)).*INclude_PV_S';
        max_temp_PV_Q_Out=sqrt(temp_S.^2-temp_PV_P_Out.^2);
        Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S),i_Roll)=temp_PV_P_Out;

        Radn_DG_Q = Rand_SunFun_Collinearity(Base_RandSigma,Col_Index,length(INclude_PV_S),Tranning_Range.PhotoVoltake_Q_M,Tranning_Range.PhotoVoltake_Q_B);
        temp_PV_Q_Out=Radn_DG_Q.*INclude_PV_S';
        temp_PV_Q_Out=min(temp_PV_Q_Out,max_temp_PV_Q_Out); % limit the Inverter Q power to fit the total S limit
        Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2,i_Roll)=temp_PV_Q_Out;
    end
    temp_TransTab=ceil(rand(1,1)*temp_range_input_TransTab_num);
    if Device_Info.Transformer_Tab_state
        Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state,i_Roll)=Transformer_Tab(temp_TransTab);
    end
end

%%  Data of DD_LPF 《Data-driven power flow linearization: A regression approach》
Data_DDLPF.P_injection=zeros(Bus_Num,num_inpuit);
Data_DDLPF.Q_injection=zeros(Bus_Num,num_inpuit);
Data_DDLPF.Vm=zeros(Bus_Num,num_inpuit);
Data_DDLPF.Va=zeros(Bus_Num,num_inpuit);
Data_DDLPF.PL=zeros(Branch_Num,num_inpuit);
Data_DDLPF.QL=zeros(Branch_Num,num_inpuit);
Data_DDLPF.PLoss=zeros(1,num_inpuit);
%%
% Output=zeros(output_num,num);
SS=[];

for i=1:num
    temp_iptpq_p=Input_KPM(1:length(pq),i);
    temp_iptpq_q=Input_KPM(length(pq)+1:2*length(pq),i);
    if length(INclude_PV_node_Pos)>0
        temp_iptpq_p(INclude_PV_node_Pos)=temp_iptpq_p(INclude_PV_node_Pos)-Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S),i);
        temp_iptpq_q(INclude_PV_node_Pos)=temp_iptpq_q(INclude_PV_node_Pos)-Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2,i);
    end
    temp_iptpv_p=Input_KPM(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input_KPM(2*length(pq)+length(pv)+1:2*length(pq)+2*length(pv),i);
    temp_iptref_v=Input_KPM(2*length(pq)+2*length(pv)+1,i);

    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,6)=temp_iptref_v;


    if Device_Info.input_Cbank_state
        temp_C_bank=Input_KPM(2*length(pq)+2*length(pv)+1+Device_Info.input_Cbank_state,i);
        case_name.bus(ref,4)=temp_C_bank;
    end
    if Device_Info.Transformer_Tab_state
        temp_TranTab=Input_KPM(2*length(pq)+length(pv)+1+Device_Info.input_Cbank_state+length(INclude_PV_S)*2+Device_Info.Transformer_Tab_state,i);
        case_name.branch(1,9)=temp_TranTab;
    end

    [result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    output1=result.bus(pq,8);
    output2=result.branch(line_active,14);
    output3=result.branch(line_active,15);
    output4=result.bus(pq,9);
    output5=result.bus(pv,9);
    output_PLOSS=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));

    %     Output(:,i)=[output1;output2;output3;output4;output5;output_PLOSS];
    %     Output(:,i)=[output1;output_PLOSS];

    output_temp=[];

    if TestItem.PQ_Vm
        output_temp=[output_temp;output1];
    end
    if TestItem.Va
        output_temp=[output_temp;output4;output5];
    end
    if TestItem.LP
        output_temp=[output_temp;output2];
    end
    if TestItem.LQ
        output_temp=[output_temp;output3];
    end
    if TestItem.PLoss
        output_temp=[output_temp;output_PLOSS];
    end

    Output_KMP(:,i)=output_temp;
    %% DDLPF Data (Not distinguish the input and output)
    %     [MVAbase, bus, gen, ~] = runpf(result);
    Sbus = makeSbus(result.baseMVA,result.bus, result.gen);
    Data_DDLPF.P_injection(:,i)=real(Sbus);
    Data_DDLPF.Q_injection(:,i)=imag(Sbus);
    Data_DDLPF.Vm(:,i)=result.bus(:,8);
    Data_DDLPF.Va(:,i)=result.bus(:,9);
    Data_DDLPF.PL(:,i)=result.branch(line_active,14);
    Data_DDLPF.QL(:,i)=result.branch(line_active,15);
    Data_DDLPF.PLoss(:,i)=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));
end
%% Only keep the results of power flow convergence
Input_KPM=Input_KPM(1:test_input_num,SS);
Output_KMP=Output_KMP(:,SS);

end

