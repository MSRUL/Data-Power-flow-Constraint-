function [Sens_KPM] = Sens_Matrix_KPM(Input,Step,M,DLR_Para,pq)
% ZYX 20220613 Calculate the senstive matrix by Dimension lifting linear regression power flow calculation.
% Add the power injection by step and record the voltage difference
% 20200612 Only the PQ Type Bus
% The Unit of input variable of "Step" is MVA

% Not Support the PV Type Bus
%%
%% Init
Sens_KPM.P2V=zeros(length(pq),length(pq));
Sens_KPM.Q2V=zeros(length(pq),length(pq));

%% OR Voltage
    Input_Temp=Input;
    V_OR= Cal_DLR(Input_Temp,M,DLR_Para);


%% Active Power Injection to Voltage
for i=1:length(pq)
    Input_Temp=Input;
    Input_Temp(i,1)=Input_Temp(i,1)+Step;
    V_step= Cal_DLR(Input_Temp,M,DLR_Para);

    Sens_KPM.P2V(:,i)=-(V_step-V_OR)/Step;  % nagtive means the power injection.
end
%% Reactive Power Injection to Voltage
for i=1:length(pq)
    
    Input_Temp=Input;
    Input_Temp(i+length(pq),1)=Input_Temp(i+length(pq),1)+Step;
    V_step= Cal_DLR(Input_Temp,M,DLR_Para);
    Sens_KPM.Q2V(:,i)=-(V_step-V_OR)/Step;  % nagtive means the power injection.
    
end
end