function [Result_CPLEX] = CPLEX_SLPF_Optimization(casename_OR,Input_Cal,Constraint,Objective_Info)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明
%%
INclude_PV_node=Constraint.INclude_PV_node;
Voltage=Constraint.Voltage;

%%
% casename_NR=case33bw;
Bus_Num=size(casename_OR.bus,1);
[baseMVA, bus, gen ,branch] = deal(casename_OR.baseMVA, casename_OR.bus, casename_OR.gen, casename_OR.branch);
[ref,pv, pq,pv_pos,ref_pos,pv_total] = Case_Info(casename_OR);

%%
Results_S=runpf(casename_OR);
V_base=Results_S.bus(pq,8);

[~,~, ~,SensiM]=makeJac_20200713(Results_S.baseMVA, Results_S.bus, Results_S.branch, Results_S.gen, 1);
S=SensiM.VM(pq,[pq;Bus_Num+pq]);

PQ_Load_OR=[Results_S.bus(pq,3);Results_S.bus(pq,4)];

PQ_Load_test=Input_Cal(1:length(PQ_Load_OR*2),1);
V=V_base+S*(-1*(PQ_Load_test-PQ_Load_OR))/casename_OR.baseMVA;  %"-1" means power injection



%% Input Parameter

PVinverter_P=Constraint.PVinverter_P/baseMVA;
INclude_PV_S=Constraint.INclude_PV_S/baseMVA;
PVinverter_Q=Constraint.PVinverter_Q/baseMVA;
%% Init variable

PV_P= sdpvar(size(INclude_PV_node,2),1);
PV_Q = sdpvar(size(INclude_PV_node,2),1);
Vol = sdpvar(size(casename_OR.bus,1),1);
Pbus = sdpvar(size(casename_OR.bus,1),1);
Qbus = sdpvar(size(casename_OR.bus,1),1);
BranchFlow_DLPF_Loss= sdpvar(size(branch,1),1);

%% Init DLPF Constraint

P_Load=[0;Input_Cal(pq,1)/baseMVA];
Q_Load=[0;Input_Cal(length(pq)+pq,1)/baseMVA];

%% DLPF Constraint

Constraints=[];
for i=1:size(casename_OR.bus,1)

    if ismember(i,INclude_PV_node)
        pos_PV_num=find(INclude_PV_node==i);
        Constraints=[Constraints;Pbus(i,1)==P_Load(i,1)-PV_P(pos_PV_num,1)];% The P_Load is positive number()
        Constraints=[Constraints;Qbus(i,1)==Q_Load(i,1)-PV_Q(pos_PV_num,1)];
    else
        Constraints=[Constraints;Pbus(i,1)==P_Load(i,1)];
        Constraints=[Constraints;Qbus(i,1)==Q_Load(i,1)];
    end

end
Constraints=[Constraints;Pbus(ref,1)==0];
Constraints=[Constraints;Qbus(ref,1)==0];

Constraints=[Constraints;Vol(pq,1)==V_base+S*(-1*([Pbus(pq,1);Qbus(pq,1)]*baseMVA-PQ_Load_OR))/baseMVA;];  %"-1" means power injection

% V_base+S*(-1*([Pbus(pq,1);Qbus(pq,1)]-PQ_Load_OR))/baseMVA
%% Voltage Magnitude and Angle Constraint
Constraints=[Constraints;Vol(ref,1)==gen(ref_pos,6)];
% Constraints=[Constraints;Vol(pv,1)==bus(pv,VM)];
Constraints=[Constraints;Voltage.min<=Vol(pq,1)<=Voltage.max];

%% Photovoltaic Inverter Power
for i=1:size(PV_P,1)
    PV_Q_Limit_Rate=1;
    if strcmp(Objective_Info.type,'DG_Consumption')||strcmp(Objective_Info.Opt_Variable,'Active_Power')
        Constraints=[Constraints; 0<=PV_P(i,1)<=PVinverter_P(i,1)];  %PV inverter Active Power limint
        Constraints=[Constraints; PV_Q(i,1)==PVinverter_Q(i,1)];  %PV inverter Active Power limint
%         Constraints=[Constraints; abs(PV_Q(i,1))<=INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Reactive Power limint
        Constraints=[Constraints; norm([PV_P(i,1);PV_Q(i,1)])<=INclude_PV_S(i,1)];  %PV inverter Reactive Power limint
    else
        Constraints=[Constraints; PV_P(i,1)==PVinverter_P(i,1)];  %PV inverter Active Power limint
        Constraints=[Constraints; abs(PV_Q(i,1))<=INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Reactive Power limint
        Constraints=[Constraints; norm([PV_P(i,1);PV_Q(i,1)])<=INclude_PV_S(i,1)];  %PV inverter Reactive Power limint
    end
end

%% Objective
switch Objective_Info.type
    case 'Min Adjustment'
        switch Objective_Info.Opt_Variable
            case 'Reactive_Power'
                objective=sum(abs(PV_Q-Constraint.PVinverter_Q)); %
            case 'Active_Power'
                objective=sum(abs(PV_P-Constraint.PVinverter_P)); %
        end
    case 'Min Loss'
        objective=sum(BranchFlow_DLPF_Loss);
    case 'Hybrid'
         objective=Objective_Info.Hybrid_Index(1)*sum(BranchFlow_DLPF_Loss)+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q-Constraint.PVinverter_Q));
    case 'Min_Voltage_deviation_rate'
         objective=sum(abs(Objective_Info.Voltage_Tatget-Vol));
    case 'Min_VDR_and_Min_Adj'
         objective=Objective_Info.Hybrid_Index(1)*sum(abs(Objective_Info.Voltage_Tatget-Vol))+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q-Constraint.PVinverter_Q));
    case 'DG_Consumption'
        objective=-sum(abs(PV_P));
end
varargout=optimize(Constraints,objective);
varargout.info
%%
Result_CPLEX.PV_P=value(PV_P)*baseMVA;
Result_CPLEX.PV_Q=value(PV_Q)*baseMVA;

Result_CPLEX.Voltage=value(Vol);
Result_CPLEX.Vm_PQ=value(Vol(pq));

Result_CPLEX.PV_Q_Adj=value(PV_Q)*baseMVA-PVinverter_Q*baseMVA;
Result_CPLEX.PV_P_Adj=value(PV_P)*baseMVA-PVinverter_P*baseMVA;

Result_CPLEX.objective=value(objective);
Result_CPLEX.Opt_Info=varargout.info;
Result_CPLEX.solvertime=varargout.solvertime;
% figure;
% subplot(3,1,1);plot(Result_CPLEX.PV_P); hold on;plot(PVinverter_P*baseMVA)
% subplot(3,1,2);plot(Result_CPLEX.PV_Q); hold on;plot(PVinverter_Q*baseMVA)
% subplot(3,1,3);plot(Result_CPLEX.Voltage); hold on;plot(value(Vol))


end











