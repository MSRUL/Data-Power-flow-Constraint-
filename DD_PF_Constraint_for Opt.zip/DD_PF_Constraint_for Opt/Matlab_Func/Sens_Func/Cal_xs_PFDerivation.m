function [Xs,X_state] = Cal_xs_PFDerivation(Input,Input_Deff,DLR_Parameter)
% ZYX 20220421 [Intermediate variable calculation]  use for obtain the sensitivity by derivation of the power flow equation
% X_state is free of Input_LaMi
% Xs is depends on the Input & Input_LaMi


switch DLR_Parameter.rbf_type
    case '2n+1' % Quadratic function(without the interaction between variables)
        Xs=zeros(size(Input,1)*2+1,size(Input,2));
        X_state=zeros(2*size(Input,1)+1,size(Input,1),size(Input,2));
        for i_datanum=1:size(Input,2)
            temp1=zeros(size(Input,1),size(Input,1));
            for i =1:size(Input,1)
                temp1(i,i)=2*Input(i,i_datanum);
            end
            X_state(:,:,i_datanum)=[eye(size(Input,1));zeros(1,size(Input,1));temp1];
            Xs(:,i_datanum)=X_state(:,:,i_datanum)*Input_Deff(:,i_datanum);
        end
    case'3n+1'
        Xs=zeros(size(Input,1)*3+1,size(Input,2));
        X_state=zeros(size(Input,1)*3+1,size(Input,1),size(Input,2));
        for i_datanum=1:size(Input,2)
            temp1=zeros(size(Input,1),size(Input,1));% square term
            for i =1:size(Input,1)
                temp1(i,i)=2*Input(i,i_datanum);
            end
            temp2=zeros(size(Input,1),size(Input,1));% product of variables
            for i =1:size(Input,1)
                if i>=2
                    if i==size(Input,1)
                        temp2(end,i)=Input(i-1,i_datanum);
                        temp2(1,i)=Input(1,i_datanum);
                    else
                        temp2(i-1,i)=Input(i-1,i_datanum);
                        temp2(i,i)=Input(i+1,i_datanum);
                    end
                else
                    temp2(end,i)=Input(end,i_datanum);
                    temp2(i,i)=Input(i+1,i_datanum);
                end 
            end
            X_state(:,:,i_datanum)=[eye(size(Input,1));zeros(1,size(Input,1));temp2;temp1];
            Xs(:,i_datanum)=X_state(:,:,i_datanum)*Input_Deff(:,i_datanum);
        end
    case 'Cubic_3NP1'
        Xs=zeros(size(Input,1)*3+1,size(Input,2));
        X_state=zeros(size(Input,1)*3+1,size(Input,1),size(Input,2));
        for i_datanum=1:size(Input,2)
            temp1=zeros(size(Input,1),size(Input,1));
            for i =1:size(Input,1)
                temp1(i,i)=2*Input(i,i_datanum);
            end
            temp2=zeros(size(Input,1),size(Input,1));
            for i =1:size(Input,1)
                temp2(i,i)=3*Input(i,i_datanum)*Input(i,i_datanum);
            end
            X_state(:,:,i_datanum)=[eye(size(Input,1));zeros(1,size(Input,1));temp1;temp2];
            Xs(:,i_datanum)=X_state(:,:,i_datanum)*Input_Deff(:,i_datanum);
        end

end
end