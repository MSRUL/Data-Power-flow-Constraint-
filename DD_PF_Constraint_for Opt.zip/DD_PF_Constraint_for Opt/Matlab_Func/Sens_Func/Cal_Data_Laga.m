function [Data_Laga] = Cal_Data_Laga(Data,Peremeters)
%UNTITLED2 此处提供此函数的摘要
%   此处提供详细说明
%% Init
Input=Data.Input;
Output=Data.Output;
%% Data squence
switch Peremeters.data_squence
    case 'OR'
        Input=Input;
        Output=Output;
        Input_Diff=Input(:,2:end)-Input(:,1:end-1);
        Output_Diff=Output(:,2:end)-Output(:,1:end-1);
    case 'Closest'
        Input_Diff=Input(:,2:end);
        Output_Diff=Output(:,2:end);
        for i =1:size(Input_Diff,2)
            temp=1;
            Min_L=1000000;
            for j=1:size(Input_Diff,2)
                if i~=j
                   temp_L=sqrt(norm(Input(:,i)-Input(:,j)));
                    if temp_L<Min_L
                        Min_L=temp_L;
                        temp=j;
                    end
                end
            end
            Input_Diff(:,i)=Input(:,temp)-Input(:,i);
            Output_Diff(:,i)=Output(:,temp)-Output(:,i);
        end
    case 'Farest'
        Input_Diff=Input(:,2:end);
        Output_Diff=Output(:,2:end);
        for i =1:size(Input_Diff,2)
            temp=1;
            Max_L=0;
            for j=1:size(Input_Diff,2)
                if i~=j
                   temp_L=sqrt(norm(Input(:,i)-Input(:,j)));
                    if temp_L>Max_L
                        Max_L=temp_L;
                        temp=j;
                    end
                end
            end
            Input_Diff(:,i)=Input(:,temp)-Input(:,i);
            Output_Diff(:,i)=Output(:,temp)-Output(:,i);
        end
end
Output_Slope_Diff=Output_Diff;
Dirrection=Input_Diff(:,:); %The constant part is not included
Dirrection_Magnifi=1;
for i =1:size(Input_Diff,2)    
    Dirrection(:,i)=Input_Diff(:,i)/norm(Input_Diff(:,i))*Dirrection_Magnifi;
    Output_Slope_Diff(:,i)=Output_Diff(:,i)/norm(Input_Diff(:,i));
end
[Input_Lagrangian_Median] = Lagrangian_Median_Value(Input(:,1:end-1),Input(:,2:end),Peremeters.Order);

Data_Laga.Input_Diff=Input_Diff;
Data_Laga.Output_Diff=Output_Diff;
Data_Laga.Input_Lagrangian_Median=Input_Lagrangian_Median;

Data_Laga.Dirrection=Dirrection;
Data_Laga.Output_Slope_Diff=Output_Slope_Diff;

end