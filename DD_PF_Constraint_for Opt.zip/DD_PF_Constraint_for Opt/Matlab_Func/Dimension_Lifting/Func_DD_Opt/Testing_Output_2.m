function [OPT1,OPT2] = Testing_Output_2(Input,Output,M,cent_input,RisePos)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明

OPT1=zeros(size(Output));

for i=1:size(Input,2)
    IPT_test=Lift_Dem_Fun_Tradi(Input(:,i),'polyharmonic',cent_input);
    OPT1(:,i)=M*IPT_test;

end

end
