function [y,dy] = function_temp_test(x)
%UNTITLED5 此处提供此函数的摘要
%   此处提供详细说明
y=x.*x+2*x+3;
dy=2*x+2;
end