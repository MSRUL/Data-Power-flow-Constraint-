function [outputArg1] = Rand_Range(DR,UR,size1,size2)

outputArg1=rand(size1,size2)*(UR-DR)+DR;

end