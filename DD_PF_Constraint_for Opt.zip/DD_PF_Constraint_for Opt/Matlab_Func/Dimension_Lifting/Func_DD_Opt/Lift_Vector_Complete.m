function [Lifted_Vector] = Lift_Vector_Complete(inputArg1,rbf_type,cent)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
FUN_select = Defined_Lift_FuncType(rbf_type);

switch FUN_select
    case 1
        lifted_inpuit = Lift_Dem_Fun_Tradi(inputArg1,rbf_type,cent);
    case 2% 3N+1形式
        lifted_inpuit = Lift_Dem_Fun_3NP1(inputArg1);
    case 3% 完整的二次型空间
        lifted_inpuit = Lift_Func(inputArg1);
    case 4
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',cent);
        lifted_inpuit2 =  Lift_Dem_Fun_3NP1(inputArg1);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 5
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 6
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 7
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:)];
    case 8 % polyharmonic+invquad+invmultquad,!!!DIMENSION *1.5!!!!
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent3);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:);lifted_inpuit3(size(inputArg1,1)+1:end,:)];
    case 9 % polyharmonic+invquad+invmultquad+3np1,!!!DIMENSION DOUBLE!!!!
        halfcent1=cent(:,1:size(cent,2)/2);
        halfcent2=cent(:,1:size(cent,2)/2+1:size(cent,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(inputArg1,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(inputArg1,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(inputArg1,'invmultquad',halfcent3);
        lifted_inpuit4 =  Lift_Dem_Fun_3NP1(inputArg1);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(inputArg1,1)+1:end,:);lifted_inpuit3(size(inputArg1,1)+1:end,:);lifted_inpuit4(size(inputArg1,1)+1:end,:)];
end
Lifted_Vector=[lifted_inpuit];
% Lifted_Vector=[inputArg1;lifted_inpuit];
end

%%
