function [M,M_Struct,M_Output,beta_PLS,M_Ridge] = Cal_KMP_Total(Data,IDL_Peremeters,Train_Ops)
%UNTITLED 此处提供此函数的摘要
%   此处提供详细说明
Input=Data.Input;
Output=Data.Output;

rbf_type=IDL_Peremeters.rbf_type;
RisePos=IDL_Peremeters.RisePos;
IDL_Peremeters.type;

Train_Ops;
%%
Un_RisePos=Find_Wihtout_Which([1:size(Input,1)],RisePos);

[Lifted_Vector] = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
Lifted_Vector.XP;
Lifted_Vector.Input_Lifted;
 fprintf('\n【REGRESSION】start');
%%
switch Train_Ops.way
    case 'LS_OR' % Classical Least Squares

%         Using_M=1;
        Using_M=Train_Ops.M_Type;
        if Using_M==1 %Use the Traditional Least Squares Method to Calculate the Matrix M
            W = Lifted_Vector.Input_Lifted*Lifted_Vector.Input_Lifted';
            V = Output*Lifted_Vector.Input_Lifted';
            M = V*pinv(W);
        else %Use the Direct Calculate the Matrix M
            M=Output*pinv(Lifted_Vector.Input_Lifted);
        end
        y_test=M*Lifted_Vector.Input_Lifted;
    case 'LS_OR_pu' % Classical Least Squares with data standardization
        %% Data standardization
        standard_way='meanvalue';  % 'meanvalue' '0-1lize'
        X_lifted_pu = Data_Column_vector_standardization(Lifted_Vector.Input_Lifted,standard_way);
        Y_pu = Data_Column_vector_standardization(Output,standard_way);

        %% Train
        Using_M=Train_Ops.M_Type;
        if Using_M==1 %Use the Traditional Least Squares Method to Calculate the Matrix M
            W = X_lifted_pu.Standarded*X_lifted_pu.Standarded';
            V = Y_pu.Standarded*X_lifted_pu.Standarded';
            M = V*pinv(W);
        else %Use the Direct Calculate the Matrix M
            M=Y_pu.Standarded*pinv(X_lifted_pu.Standarded);
        end
        y_temp1=M*X_lifted_pu.Standarded;
        %% Test
        y_temp2=y_temp1;
        for i =1:size(y_temp2,2)
            y_temp2(:,i)=y_temp2(:,i)./Y_pu.Mean;
        end

        [M_Reducted] = Marix_M_Reducted(M,X_lifted_pu,Y_pu,standard_way);
        y_test=M_Reducted*Lifted_Vector.Input_Lifted;

    case 'LS_Opt' % Optimized full least squares method

        Options.Pos_OR_VarOpt=Un_RisePos;
        Options.Opt_Var_Type='Qua_All';  %'Qua_Part'  'Qua_All'

        Options.Cons.Qua_Postive=0;  % The coefficient of quadratic Parts are set as postive
        Options.Cons.Sens_in_Obj=1;  % First-order sensitivity is included in the optimization objective function
        Options.Cons.alph=0.5;

        Options.solver='gurobi';
        [M,~] = Mmatrix_Opti2(Lifted_Vector.Input_Lifted,Output,Options,IDL_Peremeters);
        y_test=M*Lifted_Vector.Input_Lifted;

end
Error_temp.mean=mean(mean(abs(y_test-Output)));
Error_temp.max=max(max(abs(y_test-Output)));


%%
M_Struct.MS=M(:,1:size(Lifted_Vector.XP,1));
M_Struct.M1=M(:,1+size(Lifted_Vector.XP,1):end);

M_Output.M_Incompelet=M;
M_Output.M_Struct=M_Struct;


%% Accuracy Test (Regression Accuracy)(Use the Training Data)
% Output_test=zeros(size(Output));
% switch IDL_Peremeters.type
%     case 'IDL'
%         Lifted_Vector = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
%         Output_test=M*Lifted_Vector.Input_Lifted;
%     case 'IDL_withSM'
%         Cent.Part2=IDL_Peremeters.cent.Part2; % The basic part
%         Cent.Part1=IDL_Peremeters.cent.Part1;% The additional part
%         Output_test=zeros(size(Output));
%         for test_ID=1:size(Input,2)
%             Lifted_Vector = Lift_Vector_Incomplete_Total(Input(:,test_ID),IDL_Peremeters);
%             Output_test(:,test_ID)=M_Struct.MS*Lifted_Vector.XS*Input(Un_RisePos,test_ID)+M_Struct.M1*Lift_Vector_Complete(Input(RisePos,test_ID),rbf_type,Cent.Part2);
%         end
%     case 'IDL_QuaModified'
%         Lifted_Vector = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
%         Output_test=M*Lifted_Vector.Input_Lifted;
%     case 'IDL_QuaModified_withSM'
%         Cent.Part2=IDL_Peremeters.cent.Part2; % The basic part
%         Cent.Part1=IDL_Peremeters.cent.Part1;% The additional part
%         for test_ID=1:size(Input,2)
%             Lifted_Vector = Lift_Vector_Incomplete_Total(Input(:,test_ID),IDL_Peremeters);
%             Input_2NP1= Lift_Dem_Fun_2NP1(Input(Un_RisePos,test_ID));
%             Output_test(:,test_ID)=M_Struct.MS*Lifted_Vector.XS*Input_2NP1+M_Struct.M1*Lift_Vector_Complete(Input(RisePos,test_ID),rbf_type,Cent.Part2);
%         end
%     case 'IDL_QuaModified_withSM_3Np1'
%         cent = IDL_Peremeters.cent;
%         IDL_Peremeters.cent=cent;
%         Lifted_Vector = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
%         Output_test=M*Lifted_Vector.Input_Lifted;
%     case 'IDLSM2'
%         Lifted_Vector = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
%         Output_test=M*Lifted_Vector.Input_Lifted;
%     case 'IDLSM3'
%         Lifted_Vector = Lift_Vector_Incomplete_Total(Data.Input,IDL_Peremeters);
%         Output_test=M*Lifted_Vector.Input_Lifted;
% end
[Output_test] = Case_PF_Accuracy_Test(IDL_Peremeters,M,M_Struct,Data.Input);

fprintf('\n【LS Error】Average Error： %f  ，Maximum Error： %f  .',mean(mean(abs(Output-Output_test))),max(max(abs(Output-Output_test))));


%%
% PLS 偏最小二乘估计方法【'主要用于解决数据共线性后引起的矩阵近奇异问题，对于提高回归精度的效果有限'】
%______TRaining________________________________
XM=Lifted_Vector.Input_Lifted;
num_PLS=50;
[~,~,~,~,beta_PLS,PCTVAR] = plsregress(XM',Output',num_PLS);
% max(cumsum(100*PCTVAR(2,:)))
%______TEST________________________________
yfit = [ones(size(XM',1),1) XM']*beta_PLS;
Y_PLS=yfit';
fprintf('\n【PLS Parameter Info】num_PLS： %d  .',num_PLS);
fprintf('\n【PLS Error】Average Error： %f  ，Maximum Error： %f  .', ...
    mean(mean(abs(Y_PLS-Output))),max(max(abs(Y_PLS-Output))));

%% Ridge
M_Ridge=zeros(size(Output,1),size(Lifted_Vector.Input_Lifted,1));
k_ridge=1;
for i=1:size(Output,1)
    B1=ridge(Output(i,:)',Lifted_Vector.Input_Lifted',k_ridge);
    M_Ridge(i,:)=B1;
end
Output_Test_ridge=M_Ridge*Lifted_Vector.Input_Lifted;
fprintf('\n【Ridge Error】Average Error： %f  ，Maximum Error： %f  .', ...
    mean(mean(abs(Output_Test_ridge-Output))),max(max(abs(Output_Test_ridge-Output))));



%% SVR 支持向量机回归【'主要用于解决部分节点量测数据存在较大偏差的问题'】
% %______TRaining________________________________
% kernel_type='g';  %'g':%gaussian Kernel  'l':linear Kernel  'p':poly3 Kernel
% maxItr=10;
% Alpha_SVR=SVR_Rge_Mul(Lifted_Vector.Input_Lifted',Output',kernel_type,maxItr);
% %______TEST________________________________
% F_o = SVR_Predic(inputData',Alpha_SVR,kernel_type);
% Y_SVR=F_o';
% fprintf('\n【SVR Parameter Info】kernel_type： %s  ，maxItr： %d  .',kernel_type,maxItr);
% fprintf('\n【SVR Error】Average Error： %f  ，Maximum Error： %f  .', ...
%     mean(mean(abs(Y_SVR-Output))),max(max(abs(Y_SVR-Output))));

 fprintf('\n【REGRESSION】end\n\n');
end