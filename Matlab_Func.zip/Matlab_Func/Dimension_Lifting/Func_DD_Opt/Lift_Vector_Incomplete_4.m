function [XM,XP] = Lift_Vector_Incomplete_4(inputArg1,rbf_type,Cent,RisePos)
%Lift_Vector_Incomplete_2 :Midified from Lift_Vector_Incomplete
% the senstive of control variable is the function of others.

%% Init part
Un_RisePos=Find_Wihtout_Which([1:size(inputArg1,1)],RisePos);
%%  Part 1
XP=zeros(size(RisePos,2)+2*size(Un_RisePos,2)+1+size(Cent.Part1,2),size(inputArg1,2));
for j=1:size(inputArg1,2)
    XS = Lift_Vector_InComplete_with_Direction_ControlVariableQua(inputArg1(:,j),rbf_type,Cent.Part1,RisePos);% XS: Time variable(for disturbance variable)
    Input_2NP1= [ inputArg1(Un_RisePos,j) ; ones(1,size(inputArg1(Un_RisePos,j),2)) ; inputArg1(Un_RisePos,j).*inputArg1(Un_RisePos,j) ]  ;
    XP(:,j)=XS*Input_2NP1;
end

%%  Part 2 
FUN_select = Defined_Lift_FuncType(rbf_type);

lift_inpuit=inputArg1(RisePos,:);
% lifted_inpuit=( [lift_inpuit;rbf_self_use(lift_inpuit,cent,rbf_type)] );
switch FUN_select
    case 1
        lifted_inpuit = Lift_Dem_Fun_Tradi(lift_inpuit,rbf_type,Cent.Part2);
    case 2% 3N+1褰㈠紡
        lifted_inpuit = Lift_Dem_Fun_3NP1(lift_inpuit);
    case 3% 瀹屾暣鐨勪簩娆″瀷绌洪棿
        lifted_inpuit = Lift_Func(lift_inpuit);
    case 4
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',Cent.Part2);
        lifted_inpuit2 =  Lift_Dem_Fun_3NP1(lift_inpuit);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 5
        halfcent1=Cent.Part2(:,1:size(Cent.Part2,2)/2);
        halfcent2=Cent.Part2(:,1:size(Cent.Part2,2)/2+1:size(Cent.Part2,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 6
        halfcent1=Cent.Part2(:,1:size(Cent.Part2,2)/2);
        halfcent2=Cent.Part2(:,1:size(Cent.Part2,2)/2+1:size(Cent.Part2,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 7
        halfcent1=Cent.Part2(:,1:size(Cent.Part2,2)/2);
        halfcent2=Cent.Part2(:,1:size(Cent.Part2,2)/2+1:size(Cent.Part2,2));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent2);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:)];
    case 8
        halfcent1=Cent.Part2(:,1:size(Cent.Part2,2)/2);
        halfcent2=Cent.Part2(:,1:size(Cent.Part2,2)/2+1:size(Cent.Part2,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent3);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:);lifted_inpuit3(size(lift_inpuit,1)+1:end,:)];
    case 9 % polyharmonic+invquad+invmultquad+3np1,!!!DIMENSION DOUBLE!!!!
        halfcent1=Cent.Part2(:,1:size(Cent.Part2,2)/2);
        halfcent2=Cent.Part2(:,1:size(Cent.Part2,2)/2+1:size(Cent.Part2,2));
        halfcent3=rand(size(halfcent1));
        lifted_inpuit1 = Lift_Dem_Fun_Tradi(lift_inpuit,'polyharmonic',halfcent1);
        lifted_inpuit2 = Lift_Dem_Fun_Tradi(lift_inpuit,'invquad',halfcent2);
        lifted_inpuit3 = Lift_Dem_Fun_Tradi(lift_inpuit,'invmultquad',halfcent3);
        lifted_inpuit4 =  Lift_Dem_Fun_3NP1(lift_inpuit);
        lifted_inpuit=[lifted_inpuit1;lifted_inpuit2(size(lift_inpuit,1)+1:end,:);lifted_inpuit3(size(lift_inpuit,1)+1:end,:);lifted_inpuit4(size(lift_inpuit,1)+1:end,:)]; 
end
%% Combnination of Part 1 and 2
% Lifted_Vector=[inputArg1(Un_RisePos,:);inputArg1(RisePos,:);lifted_inpuit];
XM=[XP;lifted_inpuit];
end

