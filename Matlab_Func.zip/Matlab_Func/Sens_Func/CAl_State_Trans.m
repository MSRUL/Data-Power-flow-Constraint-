function [X_New,Num] = CAl_State_Trans(Data_Laga,DLR_Parameterx)
%ZYX 20220427 
Data_Laga.Input_Diff;
Data_Laga.Output_Diff;
Data_Laga.Input_Lagrangian_Median;
%%
X_lifted = Lift_Vector_Complete_Total(Data_Laga.Input_Lagrangian_Median,DLR_Parameterx);

%%
n=size(Data_Laga.Input_Diff,2);
n_Lifted=size(X_lifted,1);
nx=size(Data_Laga.Input_Diff,1);

Num.n=n;
Num.n_Lifted=n_Lifted;
Num.nx=nx;
%%
X_New=zeros(n_Lifted*nx,n);

for i=1:n
    for i_nx=1:nx
        range_temp=(i_nx-1)*n_Lifted+1:i_nx*n_Lifted;
        X_New(range_temp,i)=X_lifted(:,i)*Data_Laga.Input_Diff(i_nx,i);
    end
end

end