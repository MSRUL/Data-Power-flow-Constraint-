function [Sens_KPM] = Sens_Matrix_KPM_Total(Input,Step,M,DLR_Para,data_Range)
% ZYX 20220613 Calculate the senstive matrix by Dimension lifting linear regression power flow calculation.
% Add the power injection by step and record the voltage difference
% 20200612 Only the PQ Type Bus
% The Unit of input variable of "Step" is MVA

% Not Support the PV Type Bus
%%
%% Init
Sens_KPM=zeros(size(M,1),length(data_Range));

%% OR Voltage
    Input_Temp=Input;
    V_OR= Cal_DLR(Input_Temp,M,DLR_Para);

%% Active Power Injection to Voltage
for i=1:length(data_Range)
    Input_Temp=Input;
    Input_Temp(i,1)=Input_Temp(i,1)+Step;
    V_step= Cal_DLR(Input_Temp,M,DLR_Para);

    Sens_KPM(:,i)=-(V_step-V_OR)/Step;  % nagtive means the power injection.
end

end