function [Input_Net_Vector] = Generate_Standard_Case_Net_Vector(case_name,Device_Info)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
%%
[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

%%

IPT_pv_p=zeros(length(pv),1);
IPT_pv_v=zeros(length(pv),1);

IPT_pqNet_p=case_name.bus(pq,3);
IPT_pqNet_q=case_name.bus(pq,4);

if length(Device_Info.INclude_PV_node_Pos)>0
    %%
    temp_PV_P_Out=Device_Info.INclude_PV_S';
    temp_PV_Q_Out=zeros(size(temp_PV_P_Out)); % limit the Inverter Q power to fit the total S limit
    %%
    IPT_pqNet_p(Device_Info.INclude_PV_node_Pos,:)=IPT_pqNet_p(Device_Info.INclude_PV_node_Pos,:)-temp_PV_P_Out;
    IPT_pqNet_q(Device_Info.INclude_PV_node_Pos,:)=IPT_pqNet_q(Device_Info.INclude_PV_node_Pos,:)-temp_PV_Q_Out;
end
Input_Net_Vector=[IPT_pqNet_p;IPT_pqNet_q];

for i=1:length(pv)
    IPT_pv_p(i,:)=sum(case_name.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
    IPT_pv_v(i,:)=case_name.gen( pv_pos(i,1),6);
end
Input_Net_Vector=[Input_Net_Vector;IPT_pv_p;IPT_pv_v];

IPT_ref_v=case_name.gen( ref_pos,6);
Input_Net_Vector=[Input_Net_Vector;IPT_ref_v];

temp_C_bank=1;
if Device_Info.input_Cbank_state
    temp_Cbank=-Device_Info.input_Cbank(temp_C_bank);
    Input_Net_Vector=[Input_Net_Vector;temp_Cbank];
end

if Device_Info.Transformer_Tab_state
    Input_Net_Vector=[Input_Net_Vector;Device_Info.Transformer_Tab];
end


end

