function [outputArg1] = Lift_Func(x)
%UNTITLED10 ��ά����
%   ���ױ���

[N,nc]=size(x);
outputArg1=zeros(N+1+(N-1)*N/2+N,nc);

outputArg1(1:N,:)=x;
outputArg1(1+N,:)=1;

startnum=N+1;
k=0;
for i=1:N
    for j=i+1:N
        k=k+1;
        outputArg1(startnum+k,:)=x(i,:).*x(j,:);
    end
end
outputArg1((N+1+(N-1)*N/2+1):(N+1+(N-1)*N/2+N),:)=x.*x;

end

