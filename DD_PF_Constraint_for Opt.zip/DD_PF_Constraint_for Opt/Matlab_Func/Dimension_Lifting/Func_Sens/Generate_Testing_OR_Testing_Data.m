function [Input,Output,OPT1] = Generate_Testing_OR_Testing_Data(input_num,test_input_num,output_num,num_inpuit,Tranning_Range,temp_range_input_Cbank,INclude_PV_node_Pos,case_name,case_name_or_simp,Range,M,cent)
%UNTITLED5 此处显示有关此函数的摘要
%   此处显示详细说明

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;

line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);

input_Cbank=temp_range_input_Cbank/1000;
temp_range_input_Cbank_num=length(input_Cbank);

Input=zeros(input_num,num_inpuit);
num=num_inpuit;

Input(1:length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_P_M+Tranning_Range.PQ_P_B).*case_name_or_simp.bus(pq,3);
Input(length(pq)+1:2*length(pq),:)=(rand(length(pq),num)*Tranning_Range.PQ_Q_M+Tranning_Range.PQ_Q_B).*Input(1:length(pq),:);
for i=1:length(pv)
    Input(2*length(pq)+i,:)=(rand(1,num)*Tranning_Range.PV_P_M+Tranning_Range.PV_P_B)*sum(case_name_or_simp.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
    %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
    Input(2*length(pq)+length(pv)+i,:)=case_name_or_simp.gen( pv_pos(i,1),6)*(rand(1,num)*Tranning_Range.PV_V_M+Tranning_Range.PV_V_B);
end
Input(2*length(pq)+2*length(pv)+1,:)=case_name_or_simp.gen( ref_pos,6)*(rand(1,num)*Tranning_Range.REF_V_M+Tranning_Range.REF_V_B);
temp_C_bank=ceil(rand(1,num)*temp_range_input_Cbank_num);
Input(2*length(pq)+length(pv)+1+1:input_num,:)=-temp_range_input_Cbank(temp_C_bank);

if Range==5
    Input(INclude_PV_node_Pos,:)=(rand(length(INclude_PV_node_Pos),num)*Tranning_Range.PhotoVoltake_P_M+Tranning_Range.PhotoVoltake_P_B).*case_name_or_simp.bus(pq(INclude_PV_node_Pos),3);
    Input(length(pq)+INclude_PV_node_Pos,:)=(rand(length(INclude_PV_node_Pos),num)*Tranning_Range.PhotoVoltake_Q_M+Tranning_Range.PhotoVoltake_Q_B).*Input(INclude_PV_node_Pos,:);
end
%%
Output=zeros(output_num,num);
OPT1=Output;
SS=[];

for i=1:num
    temp_iptpq_p=Input(1:length(pq),i);
    temp_iptpq_q=Input(length(pq)+1:2*length(pq),i);
    temp_iptpv_p=Input(2*length(pq)+1:2*length(pq)+length(pv),i);
    temp_iptpv_v=Input(2*length(pq)+length(pv)+1:input_num,i);
    temp_iptref_v=Input(2*length(pq)+2*length(pv)+1,i);
    temp_C_bank=Input(2*length(pq)+2*length(pv)+1+1,i);
    case_name.bus(pq,pos_num_pq_pq)=[temp_iptpq_p,temp_iptpq_q];
    %     case_name.bus(pv,pos_num_pv_p)=[temp_iptpv_p,temp_iptpv_v];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=temp_iptpv_p(j,1)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=temp_iptpv_v(j,1);
    end
    case_name.gen(ref_pos,6)=temp_iptref_v;
    case_name.bus(ref,4)=temp_C_bank;
        
    [result,sccuess]=runpf(case_name);
    
    output1=result.bus(pq,8);
    output2=result.branch(line_active,14);
    output3=result.branch(line_active,15);
    output4=result.bus(pq,9);
    output5=result.bus(pv,9);
    
    output_PLOSS=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));
    
    Output(:,i)=[output1;output2;output3;output4;output5;output_PLOSS];
    if sccuess
        SS=[SS,i];
        IPT_test=Lift_Dem_Fun_Tradi(Input(:,i),'polyharmonic',cent);
        OPT1(:,i)=M*IPT_test;
    end
end

Input=Input(1:test_input_num,SS);
Output=Output(:,SS);
OPT1=OPT1(:,SS);
end

