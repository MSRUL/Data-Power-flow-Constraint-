function [combine,same,A_mins_B,B_mins_A] = Logic_cal_2Vector(A,B)
% ZYX  20220531
% Computes a logical operation on two arrays
combine=[A;B];
combine=unique(combine);

same=[];
for i=1:length(A)
    for j=1:length(B)
        if A(i,1)==B(j,1)
            same=[same;A(i,1)];
        end
    end
end

A_mins_B=A;
pos=[];
for i=1:length(same)
    temp=find(A==same(i,1));
    pos=[pos;temp];
end
A_mins_B(pos)=[];

B_mins_A=B;
pos=[];
for i=1:length(same)
    temp=find(B==same(i,1));
    pos=[pos;temp];
end
B_mins_A(pos)=[];

end