function [] = Test_The_Constraint_Satisfacation(node_now,progeny_Matric)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

 node_now=17;  % The test Node
%% Determine parameter information around the test node
temp_progeny_node=find(progeny_Matric(node_now,:)==1);
Down_stream_line_ID=zeros(size(temp_progeny_node));

for j=1:size(temp_progeny_node,2)
    node_down=temp_progeny_node(1,j);
    Down_stream_line_ID(1,j) = find_line_num(casename_NR,line_active,node_now,node_down);
end
node_up=find(progeny_Matric(:,node_now)==1);
Up_stream_line_ID= find_line_num(casename_NR,line_active,node_up,node_now);
%% branch flow Constraint

if ismember(node_now,INclude_PV_node)
    pos_PV_num=find(INclude_PV_node==node_now);
    temp1=sum(value(Pline(Down_stream_line_ID,1)));
    temp2=value(Pline(Up_stream_line_ID,1))-R_ij(node_up,node_now)*value(i_square(Up_stream_line_ID,1))-(P_Load(node_now,1)-PVinverter_P(pos_PV_num,1));
else
    temp1=sum(value(Pline(Down_stream_line_ID,1)));
    temp2=value(Pline(Up_stream_line_ID,1))-R_ij(node_up,node_now)*value(i_square(Up_stream_line_ID,1))-P_Load(node_now,1);
end
fprintf('֧·����Լ����  %f,  %f\n',temp1,temp2);
%%
temp1=value(v_square(node_now,1));
temp2=value(v_square(node_up,1))-2*(R_ij(node_up,node_now)*value(Pline(Up_stream_line_ID,1))+X_ij(node_up,node_now)*value(Qline(Up_stream_line_ID,1)))+(R_ij(node_up,node_now)^2+X_ij(node_up,node_now)^2)*value(i_square(Up_stream_line_ID,1));
fprintf('��ѹ����Լ��.��ʽԼ����  %f,  %f\n',temp1,temp2);

%%

temp1=(value(Pline(Up_stream_line_ID,1))^2+value(Qline(Up_stream_line_ID,1))^2)/value(v_square(node_up,1));
temp2=value(i_square(Up_stream_line_ID,1));
fprintf('����׶�ĵ���Լ��,����ʽԼ����  %f,  %f\n',temp1,temp2)






%%






end

