function [] = Results_Comparison_KPM_Opt(results_NR,Output_Test_Incompelet,Result_OPT_KPM,CPLEX_MBM_Results,CPLEX_DDM_Results,Objective_Info,Pos_In_OutPut,case_chose)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ,CPLEX_MBM_Results,CPLEX_DDM_Results
%   �˴���ʾ��ϸ˵��
path_base = mfilename('fullpath');i=findstr(path_base,'\');path_base=path_base(1:i(end));
path_last=path_base(1:i(end-1)); %�˴����������m�ļ�ִ��
path_last2=path_base(1:i(end-2)); %�˴����������m�ļ�ִ��
word_size=14;
switch Objective_Info.type
    case 'Min Loss'
        %% Compare with SOCP Results (Min Power Loss)
        figure;plot(results_NR.bus(Pos_In_OutPut.pq,8));title(case_chose);xlabel('�ڵ���');ylabel('�ڵ��ѹp.u.')
        hold on;plot(Result_OPT_KPM.Vm_PQ)
        hold on;plot(Result_OPT_KPM.Vm_PQ_NRCheck,'--');
        hold on;plot(CPLEX_MBM_Results.PQ_Vm_Result)
        hold on;plot(CPLEX_MBM_Results.Vm_PQ_NRCheck,'--');
        legend('������׼ֵ','Koopman�Ż����','Koopman�Ż����NRУ��','SOCP�Ż����','SOCP�Ż����NRУ��')
        set(gcf,'unit','centimeters','position',[1,1,13,10])
        set(gca,'FontSize',word_size);
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q,CPLEX_MBM_Results.PV_Q];
        bar(Opt_Variable_Result_PV_Q)
        legend('Koopman Opt','SOCP Opt')
        xlabel('PV inventer ID');ylabel('Reactive Power / MVar')
        title('Results Comparison ��Reactive Power of Photovoltaic��')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,1,13,10])
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q_Adj,CPLEX_MBM_Results.PV_Q_Adj];
        bar(Opt_Variable_Result_PV_Q)
        legend('Koopman Opt','SOCP Opt')
        xlabel('PV inventer ID');ylabel('Reactive Power / MVar')
        title('Adjustment ��Reactive Power of Photovoltaic��')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,15,13,10])
        
        figure;
        bar([Result_OPT_KPM.PLoss_KPMCheck,Result_OPT_KPM.PLoss_NRCheck,CPLEX_MBM_Results.objective,CPLEX_MBM_Results.PLoss_NRCheck]);
        title('����');
        xlabel({'Koopman�Ż����','Koopman�Ż����NRУ��','SOCP�Ż����','SOCP�Ż����NRУ��'});
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[1,15,13,10])
    case 'Hybrid'
        %% Compare with SOCP Results (Min Power Loss)
        figure;plot(results_NR.bus(Pos_In_OutPut.pq,8));title(case_chose);xlabel('�ڵ���');ylabel('�ڵ��ѹp.u.')
        hold on;plot(Result_OPT_KPM.Vm_PQ)
        hold on;plot(Result_OPT_KPM.Vm_PQ_NRCheck,'--');
        hold on;plot(CPLEX_MBM_Results.PQ_Vm_Result)
        hold on;plot(CPLEX_MBM_Results.Vm_PQ_NRCheck,'--');
        legend('������׼ֵ','Koopman�Ż����','Koopman�Ż����NRУ��','SOCP�Ż����','SOCP�Ż����NRУ��')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[1,1,13,10])
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q,CPLEX_MBM_Results.PV_Q];
        bar(Opt_Variable_Result_PV_Q)
        legend('Koopman Opt','SOCP Opt')
        xlabel('PV inventer ID');ylabel('Reactive Power / MVar')
        title('Results Comparison ��Reactive Power of Photovoltaic��')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,1,13,10])
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q_Adj,CPLEX_MBM_Results.PV_Q_Adj];
        bar(Opt_Variable_Result_PV_Q)
        legend('Koopman Opt','SOCP Opt')
        xlabel('PV inventer ID');ylabel('Reactive Power / MVar')
        title('Adjustment ��Reactive Power of Photovoltaic��')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,15,13,10])
        
        figure;
        bar([Result_OPT_KPM.PLoss_KPMCheck,Result_OPT_KPM.PLoss_NRCheck,CPLEX_MBM_Results.objective,CPLEX_MBM_Results.PLoss_NRCheck]);
        title('����');
        xlabel({'Koopman�Ż����','Koopman�Ż����NRУ��','SOCP�Ż����','SOCP�Ż����NRУ��'});
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[1,15,13,10])
    case 'Min Adjustment'
        %% Compare with DLPF Results (Min sum(abs(PV_Q)))
        figure;
        plot(results_NR.bus(Pos_In_OutPut.pq,8),'Color','k');xlabel('Bus ID');ylabel('\itV\rm_m / p.u.')
        hold on;plot(Result_OPT_KPM.Vm_PQ)
        hold on;plot(Result_OPT_KPM.Vm_PQ_NRCheck,'+-');
        hold on;plot(CPLEX_MBM_Results.PQ_Vm_Result)
        hold on;plot(CPLEX_MBM_Results.Vm_PQ_NRCheck,'*-');
        hold on;plot(CPLEX_DDM_Results.PQ_Vm_Result)
        hold on;plot(CPLEX_DDM_Results.Vm_PQ_NRCheck,'o-');
        legend('Case','PM','PM-Check','DLPF','DLPF-Check','DDLPF','DDLPF-Check')
%         if strcmp(case_chose,'case116')||strcmp(case_chose,'case109')
%             title('IEEE33');
%         else
%             title('IEEE69');
%         end
        set(gca,'FontSize',word_size);
        set(gca,'FontName','Times New Roman');
        set(gcf,'unit','centimeters','position',[1,1,13,10])
        
        fprintf('\nKoopman�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)));
        fprintf('DLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)));
        fprintf('DDLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)));
        fprintf('\nKoopman�Ż���������DLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nKoopman�Ż���������DDLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nTotal Cpmparaition Values:\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
         
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q,CPLEX_MBM_Results.PV_Q,CPLEX_DDM_Results.PV_Q];
        bar(Opt_Variable_Result_PV_Q)
        legend('PM','DLPF','DDLPF')
        xlabel('Bus ID');ylabel('DG reactive power injection /MVar')
        title('Results Comparison ')
        set(gca,'FontSize',word_size);
         set(gca,'FontName','Times New Roman');
        set(gcf,'unit','centimeters','position',[15,1,13,10])
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q_Adj,CPLEX_MBM_Results.PV_Q_Adj,CPLEX_DDM_Results.PV_Q_Adj];
        bar(Opt_Variable_Result_PV_Q)
         legend('PM','DLPF','DDLPF')
        xlabel('DG inventer ID');ylabel('\itQ\rm_D_G  Adjustment / MVar')
%         title('Adjustment (Reactive Power of Photovoltaic)')
        set(gca,'FontSize',word_size);
         set(gca,'FontName','Times New Roman');
        set(gcf,'unit','centimeters','position',[15,15,13,10])
        %% Patent Use
%         figure;
%         Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q_Adj,CPLEX_MBM_Results.PV_Q_Adj];
%         bar(Opt_Variable_Result_PV_Q)
%         legend('������������','DLPFģ�ͷ���')
%         xlabel('����ڵ���ID');ylabel('�޹�����/ MVar')
%         title('�޹����ʵ�����')
%         set(gcf,'unit','centimeters','position',[15,15,13,10])
    case 'Min_Voltage_deviation_rate'
        %% Compare with DLPF Results (Min sum(abs(PV_Q)))
       figure;
        plot(results_NR.bus(Pos_In_OutPut.pq,8),'Color','k');
        xlabel('Bus ID');ylabel('\itV\rm_m / p.u.')
        hold on;plot(Result_OPT_KPM.Vm_PQ)
        hold on;plot(Result_OPT_KPM.Vm_PQ_NRCheck,'+-');
        hold on;plot(CPLEX_MBM_Results.PQ_Vm_Result)
        hold on;plot(CPLEX_MBM_Results.Vm_PQ_NRCheck,'*-');
        hold on;plot(CPLEX_DDM_Results.PQ_Vm_Result)
        hold on;plot(CPLEX_DDM_Results.Vm_PQ_NRCheck,'o-');
        legend('Case','PM','PM-Check','DLPF','DLPF-Check','DDLPF','DDLPF-Check')
%         if strcmp(case_chose,'case116')||strcmp(case_chose,'case109')
%             title('IEEE33');
%         else
%             title('IEEE69');
%         end
        set(gca,'FontSize',word_size);
        set(gca,'FontName','Times New Roman');
        set(gcf,'unit','centimeters','position',[1,1,13,10])
        
        fprintf('\nKoopman�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)));
        fprintf('DLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)));
        fprintf('DDLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)));
        fprintf('\nKoopman�Ż���������DLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nKoopman�Ż���������DDLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nTotal Cpmparaition Values:\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
         
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q,CPLEX_MBM_Results.PV_Q,CPLEX_DDM_Results.PV_Q];
        bar(Opt_Variable_Result_PV_Q)
        legend('PM','DLPF','DDLPF')
        xlabel('Bus ID');ylabel('DG reactive power injection /MVar')
        title('Results Comparison ')
        set(gca,'FontSize',word_size);
         set(gca,'FontName','Times New Roman');
        set(gcf,'unit','centimeters','position',[15,1,13,10])
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q_Adj,CPLEX_MBM_Results.PV_Q_Adj,CPLEX_DDM_Results.PV_Q_Adj];
        bar(Opt_Variable_Result_PV_Q)
         legend('PM','DLPF','DDLPF')
        xlabel('DG inventer ID');ylabel('\itQ\rm_D_G  Adjustment / MVar')
%         title('Adjustment (Reactive Power of Photovoltaic)')
        set(gca,'FontSize',word_size);
         set(gca,'FontName','Times New Roman');
        set(gcf,'unit','centimeters','position',[15,15,13,10])
        %% Patent use
%          figure;plot(results_NR.bus(Pos_In_OutPut.pq,8));title(case_chose);xlabel('�ڵ���');ylabel('�ڵ��ѹp.u.')
%         hold on;plot(Result_OPT_KPM.Vm_PQ,'*-')
%         hold on;plot(Result_OPT_KPM.Vm_PQ_NRCheck,'+-');
%         hold on;plot(CPLEX_MBM_Results.PQ_Vm_Result,'o-')
%         hold on;plot(CPLEX_MBM_Results.Vm_PQ_NRCheck,'--');
%         legend('������׼ֵ','�������Ż����','�������Ż����У��ֵ','DLPF����Լ���Ż����','DLPF����Լ���Ż����У��')
%         set(gcf,'unit','centimeters','position',[1,1,13,10])
%         
%         figure;
%         Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q,CPLEX_MBM_Results.PV_Q];
%         bar(Opt_Variable_Result_PV_Q)
%         legend('�������Ż����','DLPF����Լ���Ż����')
%         xlabel('�ֲ�ʽ��Դ���');ylabel('�ֲ�ʽ��Դ����޹����� /MVar')
%         set(gcf,'unit','centimeters','position',[15,1,13,10])
%         
%         figure;
%         Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q_Adj,CPLEX_MBM_Results.PV_Q_Adj];
%         bar(Opt_Variable_Result_PV_Q)
%         legend('�������Ż����','DLPF����Լ���Ż����')
%         xlabel('�ֲ�ʽ��Դ���');ylabel('�ֲ�ʽ��Դ�޹����ʵ����� / MVar')
%         set(gcf,'unit','centimeters','position',[15,15,13,10])
        %%
        Vol_Target=Objective_Info.Voltage_Tatget(1,1);
        VDR_KPM_Cal=mean(abs(Result_OPT_KPM.Vm_PQ-ones(size(Result_OPT_KPM.Vm_PQ))*Vol_Target));
        VDR_KPM_NRCheck=mean(abs(Result_OPT_KPM.Vm_PQ_NRCheck-ones(size(Result_OPT_KPM.Vm_PQ_NRCheck))*Vol_Target));
        VDR_DLPF_Cal=mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-ones(size(CPLEX_MBM_Results.PQ_Vm_Result))*Vol_Target));
        VDR_DLPF_NRCheck=mean(abs(CPLEX_MBM_Results.Vm_PQ_NRCheck-ones(size(CPLEX_MBM_Results.Vm_PQ_NRCheck))*Vol_Target));
        VDR_DDLPF_Cal=mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-ones(size(CPLEX_DDM_Results.PQ_Vm_Result))*Vol_Target));
        VDR_DDLPF_NRCheck=mean(abs(CPLEX_DDM_Results.Vm_PQ_NRCheck-ones(size(CPLEX_DDM_Results.Vm_PQ_NRCheck))*Vol_Target));
        temp=[VDR_KPM_Cal,VDR_KPM_NRCheck,VDR_DLPF_Cal,VDR_DLPF_NRCheck,VDR_DDLPF_Cal,VDR_DDLPF_NRCheck];
        figure;bar(temp);
        set(gca,'FontSize',word_size);
        
        for ii=1:length(temp)
            temp_text=num2str(temp(ii));
            text(ii,temp(ii)+0.001,temp_text(1:7),'VerticalAlignment','bottom','HorizontalAlignment','center','FontSize',word_size,'FontName','Times New Roman');
        end
        axis([0 7 0 0.04])
        
%         applyhatch(gcf,'\-x.');
%         legend('�������Ż����','�������Ż����У��ֵ','DLPF����Լ���Ż����','DLPF����Լ���Ż����У��')
        set(gca,'XTicklabel',{'PM','PM-Check','DLPF','DLPF-Check','DDLPF','DDLPF-Check'})
        ylabel('VDR / p.u.')
        set(gca,'FontName','Times New Roman');
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[1,15,22,8])
    case 'Min_VDR_and_Min_Adj'
        %% Compare with DLPF Results (Min sum(abs(PV_Q)))
        figure;
        plot(results_NR.bus(Pos_In_OutPut.pq,8),'Color','k');title(case_chose);xlabel('�ڵ���');ylabel('�ڵ��ѹp.u.')
        hold on;plot(Result_OPT_KPM.Vm_PQ,'--')
        hold on;plot(Result_OPT_KPM.Vm_PQ_NRCheck,'+-');
        hold on;plot(CPLEX_MBM_Results.PQ_Vm_Result,'o-')
        hold on;plot(CPLEX_MBM_Results.Vm_PQ_NRCheck,'*-');
        hold on;plot(CPLEX_DDM_Results.PQ_Vm_Result,'.-')
        hold on;plot(CPLEX_DDM_Results.Vm_PQ_NRCheck,'x-');
        set(gca,'FontSize',word_size);
        
        legend('������׼ֵ','Koopman�Ż����','Koopman�Ż����NRУ��','DLPF�Ż����','DLPF�Ż����NRУ��','DDLPF�Ż����','DDLPF�Ż����NRУ��')
        set(gcf,'unit','centimeters','position',[1,1,13,10])
        fprintf('\nKoopman�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)));
        fprintf('DLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)));
        fprintf('DDLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)));
        fprintf('\nKoopman�Ż���������DLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nKoopman�Ż���������DDLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nTotal Cpmparaition Values:\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
        
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q,CPLEX_MBM_Results.PV_Q,CPLEX_DDM_Results.PV_Q];
        bar(Opt_Variable_Result_PV_Q)
        legend('Koopman Opt','DLPF Opt','DDLPF Opt')
        xlabel('Bus ID');ylabel('PV reactive power injection /MVar')
        title('Results Comparison ')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,1,13,10])
        
        figure;
        Opt_Variable_Result_PV_Q=[Result_OPT_KPM.PV_Q_Adj,CPLEX_MBM_Results.PV_Q_Adj,CPLEX_DDM_Results.PV_Q_Adj];
        bar(Opt_Variable_Result_PV_Q)
        legend('Koopman Opt','DLPF Opt','DDLPF Opt')
        xlabel('PV inventer ID');ylabel('Reactive Power / MVar')
        title('Adjustment ��Reactive Power of Photovoltaic��')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,15,13,10])

    case 'DG_Consumption'
        figure;
        plot(results_NR.bus(Pos_In_OutPut.pq,8),'Color','k');title(case_chose);xlabel('�ڵ���');ylabel('�ڵ��ѹp.u.')
        hold on;plot(Result_OPT_KPM.Vm_PQ,'--')
        hold on;plot(Result_OPT_KPM.Vm_PQ_NRCheck,'+-');
        hold on;plot(CPLEX_MBM_Results.PQ_Vm_Result,'o-')
        hold on;plot(CPLEX_MBM_Results.Vm_PQ_NRCheck,'*-');
        hold on;plot(CPLEX_DDM_Results.PQ_Vm_Result,'.-')
        hold on;plot(CPLEX_DDM_Results.Vm_PQ_NRCheck,'x-');
        set(gca,'FontSize',word_size);
        
        legend('������׼ֵ','Koopman�Ż����','Koopman�Ż����NRУ��','DLPF�Ż����','DLPF�Ż����NRУ��','DDLPF�Ż����','DDLPF�Ż����NRУ��')
        set(gcf,'unit','centimeters','position',[1,1,13,10])
        fprintf('\nKoopman�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)));
        fprintf('DLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)));
        fprintf('DDLPF�Ż������\nƽ����ѹ���:%f\n ����ѹ���:%f\n',mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)));
        fprintf('\nKoopman�Ż���������DLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nKoopman�Ż���������DDLPF�İٷֱȣ�\nƽ����ѹ���:%.4f%%\n ����ѹ���:%.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
        fprintf('\nTotal Cpmparaition Values:\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n%.4f  %.4f  %.4f%%  %.4f  %.4f%%\n',...
            mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),mean(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/mean(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck)),max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_MBM_Results.PQ_Vm_Result-CPLEX_MBM_Results.Vm_PQ_NRCheck))*100,...
            max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck)),max(abs(Result_OPT_KPM.Vm_PQ-Result_OPT_KPM.Vm_PQ_NRCheck))/max(abs(CPLEX_DDM_Results.PQ_Vm_Result-CPLEX_DDM_Results.Vm_PQ_NRCheck))*100 );
         
        figure;
        Opt_Variable_Result_PV_P=[Result_OPT_KPM.PV_P,CPLEX_MBM_Results.PV_P,CPLEX_DDM_Results.PV_P];
        bar(Opt_Variable_Result_PV_P)
        legend('Koopman Opt','DLPF Opt','DDLPF Opt')
        xlabel('Bus ID');ylabel('PV Active power injection /MW')
        title('Results Comparison ')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,1,13,10])
        
        figure;
        Opt_Variable_Result_PV_P=[Result_OPT_KPM.PV_P_Adj,CPLEX_MBM_Results.PV_P_Adj,CPLEX_DDM_Results.PV_P_Adj];
        bar(Opt_Variable_Result_PV_P)
        legend('Koopman Opt','DLPF Opt','DDLPF Opt')
        xlabel('PV inventer ID');ylabel('Active Power / MW')
        title('Adjustment ��Reactive Power of Photovoltaic��')
        set(gca,'FontSize',word_size);
        set(gcf,'unit','centimeters','position',[15,15,13,10])
end
end

