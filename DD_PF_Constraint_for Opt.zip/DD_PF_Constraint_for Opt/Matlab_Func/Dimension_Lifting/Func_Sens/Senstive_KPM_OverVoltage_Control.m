function [OUTPUT_Record,INPUT_Record,Senstive_M_Record] = Senstive_KPM_OverVoltage_Control(Input_Standard,case_name,pq,pv,INclude_PV_S,INclude_PV_node_Pos,M_V,Senstive_M,Over_Voltage,TransTab_step,cent_input,adjust_Q_step,adjust_P_step,KPM_Output,Voltage)
%Senstive_KPM_OverVoltage_Control Use Koopman Sensitive Matric to solve the Voltage violation problems
%   
OUTPUT_Record=KPM_Output;
Adj_Input=Input_Standard;
INPUT_Record=Adj_Input;
M_V_Rank=Senstive_M;
Senstive_M_Record=zeros(size(Senstive_M,1),size(Senstive_M,2),1);
count_term=0;
% zeros(size(M_V));
% M_V_Rank(:,INclude_PV_node_Pos)=M_V(:,INclude_PV_node_Pos);
% M_V_Rank(:,size(pq,1)+INclude_PV_node_Pos)=M_V(:,size(pq,1)+INclude_PV_node_Pos);

Pos_P_in_Input=2*length(pq)+length(pv)+1+1+1:2*length(pq)+length(pv)+1+1+length(INclude_PV_S);
Pos_Q_in_Input=2*length(pq)+length(pv)+1+1+length(INclude_PV_S)+1:2*length(pq)+length(pv)+1+1+length(INclude_PV_S)*2;
Pos_PV_P_Inventer_Start=2*length(pq)+length(pv)+1+1;
Pos_PV_Q_Inventer_Start=2*length(pq)+length(pv)+1+1+length(INclude_PV_S);
Pos_TransTab=2*length(pq)+length(pv)+1+1+length(INclude_PV_S)*2+1;

Adj_T=0; % init the Transformer Tab Adjust start
Adj_Q=1; %  init the Reactive Power if PV Inventer Adjust start
Adj_P=0; %  init the Active Power if PV Inventer Adjust start
numof_PV_inventor=[1,1,1]; 
while(length(Over_Voltage)>0) % the number of over voltage bus is not 0
    if Adj_P&&length(Over_Voltage)>0  %Start to Adject the Active Power if PV Inventer
        for i=1:length(Over_Voltage)
            [numof_PV_inventor]=find(  abs(M_V_Rank(Over_Voltage(i),Pos_P_in_Input))==max(abs(M_V_Rank(Over_Voltage(i),Pos_P_in_Input))) );  %Find the most sensitive bus with PV Inventer Active Power
            if length(numof_PV_inventor)>1
                stophere=1;
            else
                ;
            end
            if M_V_Rank(Over_Voltage(i),Pos_PV_Q_Inventer_Start+numof_PV_inventor)>=0  %Determain the direction of sensitive
                B_direction=-1;
            else
                B_direction=1;
            end
            B_direction=-1;
            if Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)+B_direction*adjust_P_step>=0 %after the Adjustment wheather the input still meet its limit
                Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)=Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)+B_direction*adjust_P_step;
            else
                M_V_Rank(:,Pos_PV_P_Inventer_Start+numof_PV_inventor)=0;
                fprintf('The reactive power of inventer on node %d has meet its limit',INclude_PV_node_Pos(numof_PV_inventor))
            end
        end
    end
    if ~Adj_P
        for i=1:length(Over_Voltage)
            Over_Voltage(i);
            Over_Voltage(i);
            if Adj_Q
                [numof_PV_inventor]=find(  abs(M_V_Rank(Over_Voltage(i),Pos_Q_in_Input))==max(abs(M_V_Rank(Over_Voltage(i),Pos_Q_in_Input))) );  %Find the most sensitive bus with PV Inventer Reactive Power
            end
            if length(numof_PV_inventor)>1  %if is over 1 ,it means that all the PV inventer Reactive power meets the limit
                
                if Adj_Input(Pos_TransTab,1)+TransTab_step.step<=TransTab_step.max %Transformer has adjustable margin
                    Adj_Input(Pos_TransTab,1)=Adj_Input(Pos_TransTab,1)+TransTab_step.step;
                    Adj_Input(1:Pos_TransTab-1,1)=Input_Standard(1:Pos_TransTab-1,1); % Init other input except the Transformer Tab
                    M_V_Rank=Senstive_M;
                    break
                else
                    Adj_P=1; %Start to Adjust the Active Power of PV Inventer
                    Adj_Q=0;
                    break
                end
            end
            if ~Adj_P % if the Active Power not Start Yet
                if M_V_Rank(Over_Voltage(i),Pos_PV_Q_Inventer_Start+numof_PV_inventor)>=0  %判断�?大影响点是正还是�?,作为正负系数加入调节量中
                    B_direction=-1;
                else
                    B_direction=1;
                end
                B_direction=-1; %Some of the Direction is Untrustfull ,so we determaine it by the low of Traditional relationship
                %% (1)PV Inverter Output Constraint
                PV_Q_Limit_Rate=0.5;
                if (Adj_Input(Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)^2+Adj_Input(Pos_PV_P_Inventer_Start+numof_PV_inventor,1)^2)<INclude_PV_S(numof_PV_inventor)^2 ...
                        && abs(Adj_Input(Pos_PV_Q_Inventer_Start+numof_PV_inventor,1))<INclude_PV_S(numof_PV_inventor)*PV_Q_Limit_Rate
                    Adj_Input(Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)=Adj_Input(Pos_PV_Q_Inventer_Start+numof_PV_inventor,1)+B_direction*adjust_Q_step; 
                    % abs(M_V_Rank(Over_Voltage(i),Pos_PV_Q_Inventer_Start+numof_PV_inventor))/max(max(abs(M_V_Rank(Over_Voltage,Pos_Q_in_Input)))); %To Avoid the two Adjustment has different direction make the two step useless and lead to the Endless loop
                else
                    M_V_Rank(:,Pos_PV_Q_Inventer_Start+numof_PV_inventor)=0;
                    fprintf( 'The %dth PV inverter total output power Limit has been meet\n',numof_PV_inventor);
                end
            end
        end
    end
    Adj_Input_Lifted=Lift_Dem_Fun_Tradi(Adj_Input,'polyharmonic',cent_input);
    KPM_Output=M_V*Adj_Input_Lifted;
    %----------------------------------
%         [Senstive_M_Adj] = Koopman_Senstive_Matric(Adj_Input,'polyharmonic',cent_input,M_V);
%         [x1,y1]=find(M_V_Rank~=0);
%         for i=1:size(x1,1)
%             M_V_Rank(x1(i),y1(i))=Senstive_M_Adj(x1(i),y1(i));
%         end
%         count_term=count_term+1;
%         Senstive_M_Record(:,:,count_term)=Senstive_M_Adj;
    %----------------------------------
    %-------Option1--start------Koopman PF ----------------------------------
    OUTPUT_Record=[OUTPUT_Record,KPM_Output];
    INPUT_Record=[INPUT_Record,Adj_Input];
    Over_Voltage=find(KPM_Output>Voltage.max);
    %-------Option1--start------Koopman PF ----------------------------------
    %-------Option2--end------NR PF ----------------------------------
%     [Output_Standard]=NR_PF_Cal(case_name,Adj_Input,INclude_PV_node_Pos,INclude_PV_S,1);
%     OUTPUT_Record=[OUTPUT_Record,Output_Standard.Vm];
%     INPUT_Record=[INPUT_Record,Adj_Input];
%     Over_Voltage=find(Output_Standard.Vm>Voltage.max);
    %-------Option2--end------NR PF ----------------------------------
    
end

% size(OUTPUT_Record,2) %迭代调压次数
end

