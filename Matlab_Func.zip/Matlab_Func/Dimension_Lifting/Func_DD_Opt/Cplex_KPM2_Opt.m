function [Result_OPT_KPM] = Cplex_KPM2_Opt(Input,M_Incompelet,Pos_Info,cent_input_incompelet,Voltage,INclude_PV_S ,Objective_Info)
%UNTITLED2 Use the Koopman to Tranning the M Matrix. (In this Part , The Dimension of Control Variable is not Lifted)
% Use the Matrix M to Optimazition by the CPLEX
%% Fixed Parameters
% Pos_OutPut.RisePos;
% Un_RisePos=Find_Wihtout_Which([1:RisePos.input_num],Pos_OutPut.RisePos); % Position of the Unrised Vector ��Control Variable��

%% Variables
PV_P= sdpvar(length(Pos_Info.Pos_P_in_Inventer),1);
PV_Q = sdpvar(length(Pos_Info.Pos_Q_in_Inventer),1);
Vm_PQ = sdpvar(length(Pos_Info.pq),1);
P_Loss = sdpvar(1,1);

%%
Input_temp=Lift_Dem_Fun_Tradi_2(Input,'polyharmonic',cent_input_incompelet,Pos_Info.RisePos);
% temp1=M_Incompelet*Input_temp;hold on;plot(temp1(1:end-1));
Inout_temp_to_Rise=Input_temp(1+length(Pos_Info.Pos_P_in_Inventer)*2:length(Input_temp));
%% Constraints

%% (1)Koopman PF 
M11=M_Incompelet(1:length(Pos_Info.pq),1:length(Pos_Info.Pos_P_in_Inventer));  %Active Power of Photovoltaic
M12=M_Incompelet(1:length(Pos_Info.pq),1+length(Pos_Info.Pos_P_in_Inventer):length(Pos_Info.Pos_P_in_Inventer)*2); %Reactive Power of Photovoltaic
M13=M_Incompelet(1:length(Pos_Info.pq),1+length(Pos_Info.Pos_P_in_Inventer)*2:length(Input_temp)); %Other lifting dimension variables

% ------------------temp test---------start
% Vm_PQ_test=M11*Input(Pos_Info.Pos_P_in_Inventer,1)+M12*Input(Pos_Info.Pos_Q_in_Inventer,1)+M13*Inout_temp_to_Rise;
% figure;plot(Vm_PQ_test);
% ------------------temp test---------end
Constraints=[];

Constraints=[Constraints;Vm_PQ==M11*PV_P+M12*PV_Q+M13*Inout_temp_to_Rise];
switch Objective_Info.type
    case 'Min Loss'
        M21=M_Incompelet(1+length(Pos_Info.pq),1:length(Pos_Info.Pos_P_in_Inventer));
        M22=M_Incompelet(1+length(Pos_Info.pq),1+length(Pos_Info.Pos_P_in_Inventer):length(Pos_Info.Pos_P_in_Inventer)*2);
        M23=M_Incompelet(1+length(Pos_Info.pq),1+length(Pos_Info.Pos_P_in_Inventer)*2:length(Input_temp));
        Constraints=[Constraints;P_Loss==M21*PV_P+M22*PV_Q+M23*Inout_temp_to_Rise];
    case 'Hybrid'
        M21=M_Incompelet(1+length(Pos_Info.pq),1:length(Pos_Info.Pos_P_in_Inventer));
        M22=M_Incompelet(1+length(Pos_Info.pq),1+length(Pos_Info.Pos_P_in_Inventer):length(Pos_Info.Pos_P_in_Inventer)*2);
        M23=M_Incompelet(1+length(Pos_Info.pq),1+length(Pos_Info.Pos_P_in_Inventer)*2:length(Input_temp));
        Constraints=[Constraints;P_Loss==M21*PV_P+M22*PV_Q+M23*Inout_temp_to_Rise];
end
Constraints=[Constraints;ones(length(Pos_Info.pq),1)*Voltage.min<=Vm_PQ <=ones(length(Pos_Info.pq),1)*Voltage.max];

%% (2)PV Inverter Output Constraint
PV_Q_Limit_Rate=1;
PVinverter_P=Input(Pos_Info.Pos_P_in_Inventer);
for i=1:size(PV_P,1)
%         Constraints=[Constraints; 0<=PV_P(i,1);PV_P(i,1)<=PVinverter_P(i,1)];  %PV inverter Active Power Up limint
    Constraints=[Constraints; PV_P(i,1)==PVinverter_P(i,1)];  %PV inverter Active Power Up limint
    Constraints=[Constraints; norm([PV_P(i,1);PV_Q(i,1)])<=INclude_PV_S(i,1)];  %PV inverter Active Power Up limint
    %     Constraints=[Constraints; PV_Q(i,1)==0];  %PV inverter Active Power Up limint
    Constraints=[Constraints; abs(PV_Q(i,1))<=INclude_PV_S(i,1)*PV_Q_Limit_Rate];  %PV inverter Active Power Up limint
    
end
%% Objective

Objective_Info.Hybrid_Index=[1,1];
switch Objective_Info.type
    case 'Min Loss'
        objective=P_Loss;
    case  'Min Adjustment'
        objective=sum(abs(PV_Q));
    case 'Hybrid'
        objective=Objective_Info.Hybrid_Index(1)*P_Loss+Objective_Info.Hybrid_Index(2)*sum(abs(PV_Q));
end

varargout=optimize(Constraints,objective);
varargout.info
%% Output
Result_OPT_KPM.PV_P=value(PV_P);
Result_OPT_KPM.PV_Q=value(PV_Q);
Result_OPT_KPM.Vm_PQ=value(Vm_PQ);
Result_OPT_KPM.P_Loss=value(P_Loss);
%% Check

end

