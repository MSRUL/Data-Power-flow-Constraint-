function [ref,pv, pq,pv_pos,ref_pos,pv_total] = Case_Info(case_name)
%UNTITLED4 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);

pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);
end

