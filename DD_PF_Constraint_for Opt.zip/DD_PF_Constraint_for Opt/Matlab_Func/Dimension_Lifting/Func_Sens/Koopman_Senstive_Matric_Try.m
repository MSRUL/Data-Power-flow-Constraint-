function [Senstive_M_Koopman] = Koopman_Senstive_Matric_Try(Input,rbf_type,cent_input,M_item,adjust_step,Sensi_Range)
%UNTITLED3 Try Every input test range to get the Sensitive Matrix ��Simulation method����NOT Analytical method��
%   �˴���ʾ��ϸ˵��

%% Init the Senstive Matrix
    Senstive_M_Koopman=zeros(size(M_item,1),size(Input,1));
    %%
    Input_Lifted=Lift_Dem_Fun_Tradi(Input,rbf_type,cent_input);
    KPM_Output_OR=M_item*Input_Lifted;

    for i=1:length(Sensi_Range)
        Input_Adj=Input;
        Input_Adj(Sensi_Range(i),1)=Input_Adj(Sensi_Range(i),1)+adjust_step;
        Adj_Input_Lifted=Lift_Dem_Fun_Tradi(Input_Adj,rbf_type,cent_input);
        KPM_Output_Adj=M_item*Adj_Input_Lifted;
        
        Output_Changed=KPM_Output_Adj-KPM_Output_OR;
        Senstive_M_Koopman(:,Sensi_Range(i))=Output_Changed;
    end
    Senstive_M_Koopman=Senstive_M_Koopman/adjust_step;
end

