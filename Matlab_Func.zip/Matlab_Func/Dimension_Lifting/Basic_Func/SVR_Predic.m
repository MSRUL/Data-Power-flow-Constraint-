function [F_o] = SVR_Predic(X,Alpha,kernel_type)
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
num_output=size(Alpha,2);
N=size(X,1);
F_o=zeros(N,num_output);
% x=X;
for i_in_Y=1:num_output
    alpha=Alpha(:,i_in_Y);
    for j=1:N
        fx1(j,:)=alpha(j)*kernel(X,X(j,:),kernel_type)';
    end
    fx=sum(fx1)';
    F_o(:,i_in_Y)=fx;
end


end

