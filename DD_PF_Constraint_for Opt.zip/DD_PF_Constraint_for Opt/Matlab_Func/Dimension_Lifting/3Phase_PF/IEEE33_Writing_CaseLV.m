function [] = IEEE33_Writing_CaseLV(Path,Load)
%UNTITLED2 此处提供此函数的摘要
%   此处提供详细说明
fid=fopen(Path,'w');

fprintf(fid,'** IEEE 13 bus test system with 1 tie switch\n');
fprintf(fid,'** 20220808 ZYX TPS-IDL Responce\n');
fprintf(fid,'** The Transformer Paramenters may not accurate\n');
fprintf(fid,'END/ TITLE\n');
fprintf(fid,'TEST, 200\n');
fprintf(fid,'10000.0 \n');
fprintf(fid,'END/ PARAMS\n');
fprintf(fid,'1	  BUS_632 	4.16	ABC	2.75	4.74	4	1	0	0	SS_12.66_K 	\n');
fprintf(fid,'2	  BUS_633	  4.16	ABC	2.75	4.74	4	1	0	0	SS_12.66_K 	\n');
fprintf(fid,'3	  BUS_634	  0.48	ABC	2.75	4.74	4	1	0	0	SS_12.66_K 	\n');
fprintf(fid,'4	  BUS_645	  4.16	BC	2.75	4.74	4	1	0	0	SS_12.66_K 	\n');
fprintf(fid,'5	  BUS_646	  4.16	BC	2.75	4.74	4	1	0	0	SS_12.66_K 	\n');
fprintf(fid,'6	  BUS_671	  4.16	ABC	2.75	4.74	4	1	0	0	SS_12.66_K 	\n');
fprintf(fid,'7	  BUS_680	  4.16	ABC	2.75	4.74	4	1	0	0	SS_12.66_K 	\n');
fprintf(fid,'8	  BUS_692	  4.16	ABC	2.75	4.74	4	1	0	0	SS_12.66_K  \n');
fprintf(fid,'9	  BUS_675	  4.16	ABC	2.75	4.74	4	1	0	0	SS_12.66_K  \n');
fprintf(fid,'10	BUS_684		4.16	AC	2.75	4.74	4	1	0	0	SS_12.66_K  \n');
fprintf(fid,'11	BUS_611		4.16	C		2.75	4.74	4	1	0	0	SS_12.66_K  \n');
fprintf(fid,'12	BUS_652		4.16	A		2.75	4.74	4	1	0	0	SS_12.66_K  \n');
fprintf(fid,'END/ NODES  \n');
fprintf(fid,'END/ DCBUS  \n');
fprintf(fid,'1  1  ‘ACS’  4.16   0.00 0.00 0.00 0.00  1 1.021 -2.49 1.0420 -121.72 1.0174 117.83 1  \n');
fprintf(fid,'END/ SOURCE  \n');
fprintf(fid,'END/ PQSOURCE  \n');
fprintf(fid,'END/ PVSOURCE  \n');
fprintf(fid,'END/ PISOURCE  \n');
fprintf(fid,'END/ PQVSOURCE  \n');
fprintf(fid,'1	  2	  Line_1			L		1		ABC		 	L602		0.094697   \n');
fprintf(fid,'1	  4	  Line_4			L		1		BC		 	L603		0.094697   \n');
fprintf(fid,'4	  5	  Line_5			L		1		BC		 	L603		0.0568182   \n');
fprintf(fid,'1	  6	  Line_6			L		1		ABC		 	L601		0.3787879  \n');
fprintf(fid,'6	  7	  Line_7			L		1		ABC	 	 	L601		0.1893939  \n');
fprintf(fid,'6	  8		Line_8			L		1		ABC		 	SWCH	    0.042614   \n');
fprintf(fid,'8	  9	  Line_9			L		1		ABC		 	L606		0.094697   \n');
fprintf(fid,'6	  10	Line_10			L		1		AC	 		L604		0.0568182   \n');
fprintf(fid,'10	11	Line_11			L		1		C		 		L605		0.0568182   \n');
fprintf(fid,'10	12	Line_12			L		1		A		 		L607		0.1515152  \n');  
fprintf(fid,'END/ BRANCH    \n');
fprintf(fid,'2	3	XFMR_1		  T		1		ABC	XFMR1		1  \n');
fprintf(fid,'END/ TRANSF  \n');
fprintf(fid,'END/ REG   \n');
fprintf(fid,'1		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(1,1),Load(1,2),Load(1,3),Load(1,4),Load(1,5),Load(1,6));	
fprintf(fid,'2		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(2,1),Load(2,2),Load(2,3),Load(2,4),Load(2,5),Load(2,6));	
fprintf(fid,'3		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(3,1),Load(3,2),Load(3,3),Load(3,4),Load(3,5),Load(3,6));	
fprintf(fid,'4		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(4,1),Load(4,2),Load(4,3),Load(4,4),Load(4,5),Load(4,6));	
fprintf(fid,'5		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(5,1),Load(5,2),Load(5,3),Load(5,4),Load(5,5),Load(5,6));	
fprintf(fid,'6		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(6,1),Load(6,2),Load(6,3),Load(6,4),Load(6,5),Load(6,6));	
fprintf(fid,'7		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(7,1),Load(7,2),Load(7,3),Load(7,4),Load(7,5),Load(7,6));	
fprintf(fid,'8		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(8,1),Load(8,2),Load(8,3),Load(8,4),Load(8,5),Load(8,6));	
fprintf(fid,'9		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(9,1),Load(9,2),Load(9,3),Load(9,4),Load(9,5),Load(9,6));	
fprintf(fid,'10		1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(10,1),Load(10,2),Load(10,3),Load(10,4),Load(10,5),Load(10,6));	
fprintf(fid,'11 	1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(11,1),Load(11,2),Load(11,3),Load(11,4),Load(11,5),Load(11,6));	
fprintf(fid,'12 	1	‘A’	1		1   %f  %f   %f  %f   %f  %f\n',Load(12,1),Load(12,2),Load(12,3),Load(12,4),Load(12,5),Load(12,6));	
fprintf(fid,'END/ LOADS\n');   
fprintf(fid,'END/PWMCVT\n');   
fprintf(fid,'END/ IDC SOURCE\n');
fprintf(fid,'END/ CAPACITOR\n');
fprintf(fid,'END/ CONSUM');


fclose(fid);
end