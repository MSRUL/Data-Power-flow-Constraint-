function [outputArg1] = Lift_Dem_Fun_QS_2n(inputArg1)

    outputArg1=( [ inputArg1 ; inputArg1.*inputArg1 ]  ) ;
end

