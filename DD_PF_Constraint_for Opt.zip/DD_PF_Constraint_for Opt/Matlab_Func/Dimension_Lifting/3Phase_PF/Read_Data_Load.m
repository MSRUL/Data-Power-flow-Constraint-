function [Data_Check1] = Read_Data_Load(path_txt,Idex)

Bus_Num2=Idex.Bus_Num2;
Bus_Num=Idex.Bus_Num;
A_data_No0=Idex.A_data_No0;
B_data_No0=Idex.B_data_No0;
C_data_No0=Idex.C_data_No0;
A_data=Idex.A_data;
B_data=Idex.B_data;
C_data=Idex.C_data;


data_Check_in = importdata(path_txt);
Data_Check1.Input=[];
Data_Check1.Output=[];
for i =1:size(data_Check_in,1)/Bus_Num2
    P_temp=[data_Check_in((i-1)*Bus_Num2+Bus_Num+A_data_No0,1);data_Check_in((i-1)*Bus_Num2+Bus_Num+B_data_No0,3);data_Check_in((i-1)*Bus_Num2+Bus_Num+C_data_No0,5)];
    Q_temp=[data_Check_in((i-1)*Bus_Num2+Bus_Num+A_data_No0,2);data_Check_in((i-1)*Bus_Num2+Bus_Num+B_data_No0,4);data_Check_in((i-1)*Bus_Num2+Bus_Num+C_data_No0,6)];
    V_PQ=[data_Check_in((i-1)*Bus_Num2+A_data(2:end),1);data_Check_in((i-1)*Bus_Num2+B_data(2:end),3);data_Check_in((i-1)*Bus_Num2+C_data(2:end),5)];
    V_Ref=[data_Check_in((i-1)*Bus_Num2+A_data(1),1);data_Check_in((i-1)*Bus_Num2+B_data(1),3);data_Check_in((i-1)*Bus_Num2+C_data(1),5)];
    Data_Check1.Input=[Data_Check1.Input,[P_temp;Q_temp;ones(1,size(V_Ref,2))]];% PQLoad and Voltage Magnitude of Refference Bus
    Data_Check1.Output=[Data_Check1.Output,V_PQ];% Voltage Magnitude of PQ Load Bus

end
end