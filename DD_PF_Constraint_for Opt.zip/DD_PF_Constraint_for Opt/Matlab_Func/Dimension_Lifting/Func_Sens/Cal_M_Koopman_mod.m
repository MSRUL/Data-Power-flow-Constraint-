function [M,M_Inverse] = Cal_M_Koopman_mod(inputData,OutputData,rbf_type,rbf_type_Inverse,cent_input,cent_output,Using_M)
%UNTITLED 姝ゅ鏄剧ず鏈夊叧姝ゅ嚱鏁扮殑鎽樿

%% Lift the Input
Xp = Lift_Vector_Complete(inputData,rbf_type,cent_input);

%% Lift the Output
Yp = Lift_Vector_Complete(OutputData,rbf_type_Inverse,cent_output);

%%

if Using_M==1
    W = Xp*Xp';
    V = OutputData*Xp';
    M = V*pinv(W);
    
    W = Yp*Yp';
    V = inputData*Yp';
    M_Inverse = V*pinv(W);
else
    M=OutputData*pinv(Xp);
    M_Inverse=inputData*pinv(Yp);
end
%% ---------time cost test--------------
% tic
% Xp = Lift_Vector_Complete(inputData,rbf_type,cent_input);
% W = Xp*Xp';
% V = OutputData*Xp';
% M = V*pinv(W);
% toc
% % ---------time cost test--------------
end

