function [A1] = Anylise_Error_Max(inputArg1,inputArg2,index,num_test,case_name,type,pq,pv)
%UNTITLED3 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
Putout_complete=2;  % 1���������Ľڵ�ţ�  2��������б��n����n��pq�ڵ�\��n��pv�ڵ�\��n����·��

pos_temp= find(abs((inputArg1-inputArg2))>=index);
pos_temp1=ceil(pos_temp);
time=pos_temp-(pos_temp1-1)*num_test;

if Putout_complete==2
    A=pos_temp1;
    % A1=unique(Line_node);
    pos_same=[];
    for i=2:size(A,1)
        if A(i,:)==A(i-1,:)
            pos_same=[pos_same;i];
        end
    end
    A(pos_same,:)=[];
    A1=A;
end
if Putout_complete==1
    if type==1  %��·
        
        F_node=case_name.branch(pos_temp1,1);
        T_node=case_name.branch(pos_temp1,2);
        Line_node=[F_node,T_node];
        A1=Line_node;
        % A1=unique(Line_node);
        pos_same=[];
        for i=2:size(A1,1)
            if A1(i,:)==A1(i-1,:)
                pos_same=[pos_same;i];
            end
        end
        A1(pos_same,:)=[];
        
    end
    if type==2  %PQ�ڵ�
        A=pos_temp1;
        % A1=unique(Line_node);
        pos_same=[];
        for i=2:size(A,1)
            if A(i,:)==A(i-1,:)
                pos_same=[pos_same;i];
            end
        end
        A(pos_same,:)=[];
        A1=pq(A);
    end
    if type==3  %PQ�ڵ�
        A=pos_temp1;
        % A1=unique(Line_node);
        pos_same=[];
        for i=2:size(A,1)
            if A(i,:)==A(i-1,:)
                pos_same=[pos_same;i];
            end
        end
        A(pos_same,:)=[];
        A1=pv(A);
    end
end
end

