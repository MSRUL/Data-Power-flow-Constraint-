function [Zbus] = makeZbus_self_build(baseMVA, bus, branch)
%UNTITLED5 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[PQ, PV, REF, NONE, BUS_I, BUS_TYPE, PD, QD, GS, BS, BUS_AREA, VM, ...
    VA, BASE_KV, ZONE, VMAX, VMIN, LAM_P, LAM_Q, MU_VMAX, MU_VMIN] = idx_bus;
[F_BUS, T_BUS, BR_R, BR_X, BR_B, RATE_A, RATE_B, RATE_C, ...
    TAP, SHIFT, BR_STATUS, PF, QF, PT, QT, MU_SF, MU_ST, ...
    ANGMIN, ANGMAX, MU_ANGMIN, MU_ANGMAX] = idx_brch;

Zbus=zeros(size(bus,1),size(bus,1));

for i=1:size(branch,1)
    if  branch(i, BR_STATUS)
        Zbus(branch(i, 1),branch(i, 2))=(branch(i, 3)+1j*branch(i, 4));
        Zbus(branch(i, 2),branch(i, 1))=(branch(i, 3)+1j*branch(i, 4));
    end
end

end

