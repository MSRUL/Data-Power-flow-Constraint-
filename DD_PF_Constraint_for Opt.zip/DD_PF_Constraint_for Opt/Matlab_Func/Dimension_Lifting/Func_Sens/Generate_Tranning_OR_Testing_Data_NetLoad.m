function [Input_Net,Output] = Generate_Tranning_OR_Testing_Data_NetLoad(num_inpuit,Tranning_Range,Device_Info,case_name,case_name_or_simp,Range,TestItem)
%Generate_Tranning_OR_Testing_Data_NetLoad 
% Generate the Koopman tranning or testing data in the net load
%manner



%%
input_Cbank=Device_Info.input_Cbank;
Transformer_Tab=Device_Info.Transformer_Tab;
INclude_PV_node_Pos=Device_Info.INclude_PV_node_Pos;
INclude_PV_S=Device_Info.INclude_PV_S;
%%

[ref,pv, pq] = bustypes(case_name.bus, case_name.gen);
pv_pos=zeros(length(pv),2);
pv_total=[];
for i=1:length(pv)
    temp_pos=find(case_name.gen(:,1)==pv(i,1));
    if isempty(temp_pos)
        ;
    else
        pv_pos(i,1)=min(temp_pos);
        pv_pos(i,2)=max(temp_pos);
    end
    pv_total=[pv_total;temp_pos];
end
ref_pos=find(case_name.gen(:,1)==ref);

pos_num_pq_pq=3:4;
pos_gen_p=2;
pos_gen_v=6;

line_active=find(case_name.branch(:,11)==1);
Branch_Num=size(line_active,1);
%%
% input_Cbank=temp_range_input_Cbank/1000;
temp_range_input_Cbank_num=length(input_Cbank);
temp_range_input_TransTab_num=length(Transformer_Tab);

%%
IPT_pqNet_p=zeros(length(pq),num_inpuit);
IPT_pqNet_q=zeros(length(pq),num_inpuit);
IPT_pv_p=zeros(length(pv),num_inpuit);
IPT_pv_v=zeros(length(pv),num_inpuit);
temp_iptref_v=zeros(1,num_inpuit);
if length(INclude_PV_S)>0
    temp_ipt_PhotoVoltaic_P=zeros(length(INclude_PV_S),num_inpuit);
    temp_ipt_PhotoVoltaic_Q=zeros(length(INclude_PV_S),num_inpuit);
end
if Device_Info.input_Cbank_state
    temp_Cbank=zeros(1,num_inpuit);
end
if Device_Info.Transformer_Tab_state
    temp_Trans_Tab=zeros(1,num_inpuit);
end
%%   新加的输入向量
% Input_Net=zeros(input_num,num_inpuit);
num=num_inpuit;
IPT_pqNet_p=(rand(length(pq),num)*Tranning_Range.PQ_P_M+Tranning_Range.PQ_P_B).*case_name_or_simp.bus(pq,3);
IPT_pqNet_q=(rand(length(pq),num)*Tranning_Range.PQ_Q_M+Tranning_Range.PQ_Q_B).*IPT_pqNet_p;

if length(INclude_PV_node_Pos)>0
    %%
    temp_PV_P_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_P_M+Tranning_Range.PhotoVoltake_P_B).*INclude_PV_S';
    temp_S=ones(size(temp_PV_P_Out)).*INclude_PV_S';
    max_temp_PV_Q_Out=sqrt(temp_S.^2-temp_PV_P_Out.^2);
    temp_PV_Q_Out=(rand(length(INclude_PV_S),num)*Tranning_Range.PhotoVoltake_Q_M+Tranning_Range.PhotoVoltake_Q_B).*INclude_PV_S';
    temp_PV_Q_Out=min(temp_PV_Q_Out,max_temp_PV_Q_Out); % limit the Inverter Q power to fit the total S limit
    %%
    IPT_pqNet_p(INclude_PV_node_Pos,:)=IPT_pqNet_p(INclude_PV_node_Pos,:)-temp_PV_P_Out;
    IPT_pqNet_q(INclude_PV_node_Pos,:)=IPT_pqNet_q(INclude_PV_node_Pos,:)-temp_PV_Q_Out;
end
Input_Net=[IPT_pqNet_p;IPT_pqNet_q];
for i=1:length(pv)
    IPT_pv_p(i,:)=(rand(1,num)*Tranning_Range.PV_P_M+Tranning_Range.PV_P_B)*sum(case_name_or_simp.gen( pv_pos(i,1): pv_pos(i,2),2));  %叠加PV节点上的有功功率 （因为一个PV节点上会有多个发电机，这里相当于将所有发电机的输出功率加和）
    %         Input(2*length(pq)+length(pv)+i,:)=(rand()*0.04-0.02+1)*case_name_or.gen( pv_pos(i,1),6);
    IPT_pv_v(i,:)=case_name_or_simp.gen( pv_pos(i,1),6)*(rand(1,num)*Tranning_Range.PV_V_M+Tranning_Range.PV_V_B);
end
Input_Net=[Input_Net;IPT_pv_p;IPT_pv_v];
IPT_ref_v=case_name_or_simp.gen( ref_pos,6)*(rand(1,num)*Tranning_Range.REF_V_M+Tranning_Range.REF_V_B);
Input_Net=[Input_Net;IPT_ref_v];
temp_C_bank=ceil(rand(1,num)*temp_range_input_Cbank_num);
if Device_Info.input_Cbank_state
    temp_Cbank=-input_Cbank(temp_C_bank);
    Input_Net=[Input_Net;temp_Cbank];
end
temp_TransTab=ceil(rand(1,num)*temp_range_input_TransTab_num);
if Device_Info.Transformer_Tab_state
    temp_Trans_Tab=Transformer_Tab(temp_TransTab);
    Input_Net=[Input_Net;temp_Trans_Tab];
end
%%
SS=[];
for i=1:num
    %%
    case_name.bus(pq,pos_num_pq_pq)=[IPT_pqNet_p(:,i),IPT_pqNet_q(:,i)];
    for j=1:length(pv)
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_p)=IPT_pv_p(j,i)/(pv_pos(j,2)-pv_pos(j,1)+1);
        case_name.gen(pv_pos(j,1):pv_pos(j,2),pos_gen_v)=IPT_pv_v(j,i);
    end
    case_name.gen(ref_pos,6)=IPT_ref_v(1,i);
    
    if Device_Info.input_Cbank_state
        temp_C_bank=temp_Cbank(1,i);
    case_name.bus(ref,4)=temp_C_bank;
    end
    if Device_Info.Transformer_Tab_state
        temp_TranTab=temp_Trans_Tab(1,i);
        case_name.branch(1,9)=temp_TranTab;
    end

    %%
    [result,sccuess]=runpf(case_name);
    if sccuess
        SS=[SS,i];
    end
    output1=result.bus(pq,8);
    output2=result.branch(line_active,14);
    output3=result.branch(line_active,15);
    output4=result.bus(pq,9);
    output5=result.bus(pv,9);
    output_PLOSS=sum(abs(result.branch(line_active,14)+result.branch(line_active,16)));
    
    %     Output(:,i)=[output1;output2;output3;output4;output5;output_PLOSS];
    %     Output(:,i)=[output1;output_PLOSS];

    if TestItem.PQ_Vm
        Output(:,i)=[output1];
    end
    if TestItem.Va
        Output(:,i)=[output4;output5];
    end
    if TestItem.LP
        Output(:,i)=[output2];
    end
    if TestItem.LQ
        Output(:,i)=[output3];
    end
    if TestItem.PLoss
        Output(:,i)=[output_PLOSS];
    end
end

Input_Net=Input_Net(:,SS);

Output=Output(:,SS);
end

