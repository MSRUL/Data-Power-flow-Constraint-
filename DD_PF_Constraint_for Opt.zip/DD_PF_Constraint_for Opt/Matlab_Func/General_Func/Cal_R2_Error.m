function [R2] = Cal_R2_Error(input_Test,input_Standard)
% ZYX 20220527
%Calculate the R-squre Error

Mean_inputArg2=mean(input_Standard(:));

temp=(input_Test-Mean_inputArg2).^2;
SSR=mean(temp(:));

temp=(input_Standard-Mean_inputArg2).^2;
SST=mean(temp(:));

R2=1-SSR/SST;

end