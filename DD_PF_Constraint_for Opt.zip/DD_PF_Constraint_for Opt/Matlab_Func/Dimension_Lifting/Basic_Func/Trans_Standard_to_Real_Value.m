function [casefile] = Trans_Standard_to_Real_Value(casefile_matpower)
%Convert the standard unit value into a Real value
% ZYX 2021.10
%   For the case33bw file
%%
casefile=casefile_matpower;
%%
Vbase = casefile_matpower.bus(1, 10) * 1e3;      %% in Volts
Sbase = casefile_matpower.baseMVA * 1e6;              %% in VA
casefile.branch(:, [3 4]) = casefile_matpower.branch(:, [3 4]) * (Vbase^2 / Sbase);
%% convert loads from MW to kW
casefile.bus(:, [3, 4]) = casefile_matpower.bus(:, [3, 4]) * 1e3;
end

