function [M_Opt_Full,Error] = Mmatrix_Opti2(Xp,Y,Options,IDL_Peremeters)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
%%
M_OR_LS=Y*pinv(Xp);
%%
Pos_Tmep_ALL=1:size(Xp,1);
Opt_Var_Type=Options.Opt_Var_Type;  %'Qua_Part'  'Qua_All'
switch IDL_Peremeters.type
    case 'IDL_QuaModified' % 'IDL_QuaModified_withSM_3Np1';  % 'IDL'  'IDL_withSM'  'IDL_QuaModified'  'IDL_QuaModified_withSM'  'IDL_QuaModified_withSM_3Np1'
        switch Opt_Var_Type
            case 'Qua_Part'
                Pos_Opt=length(Options.Pos_OR_VarOpt)+1:2*length(Options.Pos_OR_VarOpt)+1;
            case 'Qua_All'
                Pos_Opt=1:2*length(Options.Pos_OR_VarOpt)+1;
        end
    case 'IDL_QuaModified_withSM_3Np1'
        switch Opt_Var_Type
            case 'Qua_Part'
                fprint('\n\n\n\n\n\nWRONG , only "Qua_All" in  3Np1  !!!\n\n\n\n\n\n')
            case 'Qua_All'
                Pos_Opt=1:3*length(Options.Pos_OR_VarOpt)+1;
        end
end
Pos_No_Opt=Pos_Tmep_ALL;
Pos_No_Opt(Pos_Opt)=[];

switch IDL_Peremeters.type
    case 'IDL_QuaModified' % 'IDL_QuaModified_withSM_3Np1';  % 'IDL'  'IDL_withSM'  'IDL_QuaModified'  'IDL_QuaModified_withSM'  'IDL_QuaModified_withSM_3Np1'
        Pos_Qua=length(Options.Pos_OR_VarOpt)+1:2*length(Options.Pos_OR_VarOpt);
    case 'IDL_QuaModified_withSM_3Np1'
        Pos_Qua=length(Options.Pos_OR_VarOpt)+1:3*length(Options.Pos_OR_VarOpt);
end
%%
num_x=size(Xp,1);
num_y=size(Y,1);
num_data=size(Xp,2);
Var_M= sdpvar(num_y,length(Pos_Opt));


%% Constraints
Constraints=[];
% The coefficient of quadratic Parts are set as postive
if Options.Cons.Qua_Postive
    for i=1:num_y
        for j=1:length(Pos_Qua)
            Constraints=[Constraints;Var_M(i,Pos_Qua(j))<=0];
        end
    end
end

% First-order sensitivity is included in the optimization objective function
if Options.Cons.Sens_in_Obj
    Var_M_Sens= sdpvar(num_y,length(Options.Pos_OR_VarOpt),num_data);
    Var_Y_delta= sdpvar(num_y,num_data);

    Delta_X=circshift(Xp,[0,-1])-Xp;
    Delta_X_Lm=(Xp+circshift(Xp,[0,-1]))/2;
    Delta_Y=circshift(Y,[0,-1])-Y;

    switch IDL_Peremeters.type
        case 'IDL_QuaModified' % 'IDL_QuaModified_withSM_3Np1';  % 'IDL'  'IDL_withSM'  'IDL_QuaModified'  'IDL_QuaModified_withSM'  'IDL_QuaModified_withSM_3Np1'
            for k=1:num_data
                %                 MS_temp=zeros(num_y,length(Options.Pos_OR_VarOpt));
                for i =1:size(Var_M_Sens,1)
                    for j=1:size(Var_M_Sens,2)
                        Constraints=[Constraints;Var_M_Sens(i,j,k)==Var_M(i,j)+Var_M(i,j+length(Options.Pos_OR_VarOpt)+1)*2*Delta_X_Lm(Options.Pos_OR_VarOpt(j),k)];
                    end
                end
            end

        case 'IDL_QuaModified_withSM_3Np1'
            for k=1:num_data
                for i =1:size(Var_M_Sens,1)
                    for j=1:size(Var_M_Sens,2)
                        %% Determine the position of the multiplication terms of different variables (the j_temp of which xj_temp is multiplied by xj)
                        if j==1
                            j_temp=[2;size(Var_M_Sens,2)];
                        else 
                            j_temp=[j-1;j+1];
                        end
                        if j== size(Var_M_Sens,2)
                            j_temp=[j-1;1];
                        end
                        %%
                        Constraints=[Constraints;   Var_M_Sens(i,j,k)==Var_M(i,j)+Var_M(i,j_temp(1)+length(Options.Pos_OR_VarOpt)+1 )*Delta_X_Lm(Options.Pos_OR_VarOpt(j_temp(1)),k)+Var_M(i,j_temp(2)+length(Options.Pos_OR_VarOpt)+1)*Delta_X_Lm(Options.Pos_OR_VarOpt(j_temp(2)),k)+2*Var_M(i,j + 2 * length(Options.Pos_OR_VarOpt) + 1)*Delta_X_Lm(Options.Pos_OR_VarOpt(j),k) ];
                    end
                end
            end


    end

    for k=1:num_data
        for i =1:size(Var_M_Sens,1)
            for j=1:size(Var_M_Sens,2)
                Constraints=[Constraints;Var_Y_delta(:,k)==Var_M_Sens(:,:,k)*Delta_X(Options.Pos_OR_VarOpt,k)];
            end
        end
    end
end
%%
Delta_Y__XParts=M_OR_LS(:,Pos_No_Opt)*(Delta_X(Pos_No_Opt,:));

%% Objective
temp_Var1=M_OR_LS(:,Pos_No_Opt)*Xp(Pos_No_Opt,:);
temp_Var=temp_Var1-Y;
alph=Options.Cons.alph;

for alph=0.2:0.1:1

if  Options.Cons.Sens_in_Obj
    objective=sum(sum(  ( temp_Var+Var_M*Xp(Pos_Opt,:) ).^2  ))+alph*sum(sum(  ( Var_Y_delta-Delta_Y__XParts-Delta_Y ).^2  ));
else
    objective=sum(sum(  ( temp_Var+Var_M*Xp(Pos_Opt,:) ).^2  ));
    %     objective=sum(sum(  abs( temp_Var+Var_M*Xp(Pos_Opt,:) )  ));
end
%%

ops = sdpsettings('solver',Options.solver,'showprogress',1);
varargout=optimize(Constraints,objective,ops);
varargout.info
%%
M_opt=value(Var_M);
y2=M_opt*Xp(Pos_Opt,:)+temp_Var1;

Error.mean=mean(mean(abs(y2-Y)));
Error.max=max(max(abs(y2-Y)));
%%
Y_temp=M_OR_LS*Xp;
Error.mean_temp=mean(mean(abs(Y-Y_temp)));
Error.max_temp=max(max(abs(Y-Y_temp)));
%%
M_Opt_Full=zeros(num_y,num_x);
M_Opt_Full(:,Pos_Opt)=M_opt;
M_Opt_Full(:,Pos_No_Opt)=M_OR_LS(:,Pos_No_Opt);

dataname='M_Opt_withSens__Alpf_is_';
dataname=strcat(dataname,num2str(alph),'.mat');
save(strcat('C:\Users\ZhangYX\Desktop\',dataname),'M_Opt_Full');
end

thisisend=1;
thisisend=2;
thisisend=3;
thisisend=4;
end




