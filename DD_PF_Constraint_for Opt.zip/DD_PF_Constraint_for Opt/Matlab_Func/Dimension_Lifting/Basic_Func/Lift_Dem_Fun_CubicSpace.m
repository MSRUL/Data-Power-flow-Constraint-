function [outputArg1] = Lift_Dem_Fun_CubicSpace(inputArg1)
%UNTITLED3 此处显示有关此函数的摘要
%   此处显示详细说明
%     cent = rand(size(inputArg1,1),Nrbf1)*2;
    % Lifting mapping - RBFs + the state itself
    outputArg1=( [ inputArg1 ; ones(1,size(inputArg1,2)) ; inputArg1.*inputArg1; inputArg1.*inputArg1.*inputArg1 ]  ) ;
end
